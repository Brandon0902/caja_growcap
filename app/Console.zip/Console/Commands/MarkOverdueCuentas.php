<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Models\CuentaPorPagarDetalle;
use Carbon\Carbon;

class MarkOverdueCuentas extends Command
{
    // nombre con el que lo ejecutarás
    protected $signature = 'cuentas:marcar-vencidos';

    protected $description = 'Marca como VENCIDO todo abono PENDIENTE cuya fecha_pago ya pasó';

    public function handle(): int
    {
        // usa la TZ de config/app.php; si no existe, usa UTC
        $hoy = Carbon::now(config('app.timezone', 'UTC'))->toDateString();

        $actualizados = CuentaPorPagarDetalle::query()
            ->where('estado', 'pendiente')
            ->whereDate('fecha_pago', '<', $hoy)
            ->update(['estado' => 'vencido']);

        $this->info("Abonos marcados como vencido: {$actualizados}");
        return Command::SUCCESS;
    }
}
