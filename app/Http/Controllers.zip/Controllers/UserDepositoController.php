<?php

namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\UserDeposito;
use App\Models\Caja;
use App\Models\MovimientoCaja;
use App\Models\CategoriaIngreso;
use App\Services\ProveedorResolver; // ← servicio reutilizable
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class UserDepositoController extends Controller
{
    /** @var ProveedorResolver */
    protected $proveedorResolver;

    public function __construct(ProveedorResolver $proveedorResolver)
    {
        $this->proveedorResolver = $proveedorResolver;
    }

    /** INDEX GENERAL */
    public function index(Request $request)
    {
        $search = trim($request->input('search', ''));
        $status = $request->input('status'); // 0=Pendiente,1=Aprobado,2=Rechazado o null
        $desde  = $request->input('desde');  // Y-m-d o null
        $hasta  = $request->input('hasta');  // Y-m-d o null
        $orden  = $request->input('orden', 'fecha_desc'); // fecha_desc|fecha_asc|monto_desc|monto_asc

        $query = UserDeposito::query()
            ->with(['cliente:id,nombre,apellido,email', 'caja:id_caja,nombre'])
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->whereHas('cliente', function ($qc) use ($search) {
                        $qc->where('nombre', 'like', "%{$search}%")
                           ->orWhere('apellido', 'like', "%{$search}%")
                           ->orWhere('email', 'like', "%{$search}%");
                    })
                    ->orWhere('id', $search)
                    ->orWhere('cantidad', 'like', "%{$search}%")
                    ->orWhere('nota', 'like', "%{$search}%");
                });
            })
            ->when(in_array($status, ['0','1','2'], true), fn($q) => $q->where('status', (int)$status))
            ->when($desde, fn($q) => $q->whereDate('fecha_deposito', '>=', $desde))
            ->when($hasta, fn($q) => $q->whereDate('fecha_deposito', '<=', $hasta));

        $query = match ($orden) {
            'monto_asc' => $query->orderBy('cantidad', 'asc'),
            'monto_desc'=> $query->orderBy('cantidad', 'desc'),
            'fecha_asc' => $query->orderBy('fecha_deposito', 'asc'),
            'fecha_desc'=> $query->orderBy('fecha_deposito', 'desc'),
            default     => $query->orderBy('fecha_deposito', 'desc'),
        };

        $depositos = $query->paginate(15)->withQueryString();

        $statusOptions = [
            null => 'Todos',
            0    => 'Pendiente',
            1    => 'Aprobado',
            2    => 'Rechazado',
        ];

        return view('depositos.index', compact('depositos', 'search', 'status', 'statusOptions', 'desde', 'hasta', 'orden'));
    }

    /** SHOW */
    public function show(UserDeposito $deposito)
    {
        $deposito->load(['cliente', 'caja']);

        $statusOptions = [
            0 => 'Pendiente',
            1 => 'Aprobado',
            2 => 'Rechazado',
        ];

        return view('depositos.show', compact('deposito', 'statusOptions'));
    }

    /** CREATE */
    public function create()
    {
        return view('depositos.create', [
            'clientes' => Cliente::where('status',1)->orderBy('nombre')->get(),
            'cajas'    => Caja::where('estado','abierta')->get(),
        ]);
    }

    /** STORE */
    public function store(Request $request)
    {
        $data = $request->validate([
            'id_cliente'     => 'required|exists:clientes,id',
            'cantidad'       => 'required|numeric|min:0.01',
            'fecha_deposito' => 'required|date',
            'nota'           => 'nullable|string',
            'id_caja'        => 'required|exists:cajas,id_caja',
        ]);

        return DB::transaction(function () use ($data) {
            $deposito = UserDeposito::create([
                'id_cliente'     => $data['id_cliente'],
                'cantidad'       => $data['cantidad'],
                'fecha_deposito' => $data['fecha_deposito'],
                'nota'           => $data['nota'] ?? null,
                'status'         => 1,              // 1 = Aprobado
                'id_usuario'     => Auth::id(),
                'id_caja'        => $data['id_caja'],
            ]);

            $this->ingresarPagoEnCaja($deposito);

            return redirect()
                ->route('depositos.index')
                ->with('success', 'Depósito registrado y cargado en caja.');
        });
    }

    /** UPDATE (solo status) */
    public function update(Request $request, UserDeposito $deposito)
    {
        $data = $request->validate([
            'status' => 'required|in:0,1,2',
            'nota'   => 'nullable|string',
        ]);

        $deposito->update([
            'status' => (int)$data['status'],
            'nota'   => $data['nota'] ?? $deposito->nota,
        ]);

        return back()->with('success', 'Status de depósito actualizado.');
    }

    /**
     * Crea un movimiento de ingreso en la caja asociada
     * y rellena: tipo, categoría 'Depósitos', proveedor_id (cliente como proveedor), origen_id (depósito).
     */
    protected function ingresarPagoEnCaja(UserDeposito $deposito): void
    {
        $caja = Caja::findOrFail($deposito->id_caja);

        // Saldo anterior / posterior
        $last    = $caja->movimientos()->latest('fecha')->first();
        $antes   = $last ? $last->monto_posterior : $caja->saldo_inicial;
        $monto   = $deposito->cantidad;
        $despues = $antes + $monto;

        // Categoría de Ingreso: "Depósitos" (crea si no existe)
        $catDepositos = CategoriaIngreso::firstOrCreate(
            ['nombre' => 'Depósitos'],
            ['id_usuario' => 1] // o Auth::id() si quieres registrar al creador
        );

        // Proveedor: garantizarlo desde el cliente (crea si no existe)
        $proveedorId = $this->proveedorResolver->ensureFromCliente($deposito->id_cliente);

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Ingreso',
            'id_cat_ing'      => $catDepositos->id_cat_ing, // categoría automática
            'id_sub_ing'      => null,                      // si tienes subcategorías, colócalas aquí
            'id_cat_gasto'    => null,
            'id_sub_gasto'    => null,

            'proveedor_id'    => $proveedorId,              // proveedor real (desde cliente)
            'origen_id'       => $deposito->id,             // id del depósito

            'monto'           => $monto,
            'fecha'           => $deposito->fecha_deposito, // usa la fecha del depósito
            'descripcion'     => "Depósito #{$deposito->id}",
            'monto_anterior'  => $antes,
            'monto_posterior' => $despues,
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $despues]);
    }
}
