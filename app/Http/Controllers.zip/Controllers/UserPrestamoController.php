<?php

namespace App\Http\Controllers;

use App\Models\Caja;
use App\Models\CategoriaGasto;
use App\Models\CategoriaIngreso;
use App\Models\Cliente;
use App\Models\Prestamo;
use App\Models\UserAbono;
use App\Models\UserPrestamo;
use App\Models\MovimientoCaja;
use App\Services\ProveedorResolver; // ← servicio reutilizable
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class UserPrestamoController extends Controller
{
    /** @var ProveedorResolver */
    protected $proveedorResolver;

    public function __construct(ProveedorResolver $proveedorResolver)
    {
        $this->proveedorResolver = $proveedorResolver;
    }

    /** INDEX GENERAL */
    public function index(Request $request)
    {
        $search = trim($request->input('search', ''));
        $status = $request->input('status'); // 1..6 o null
        $desde  = $request->input('desde');  // Y-m-d o null
        $hasta  = $request->input('hasta');  // Y-m-d o null
        $orden  = $request->input('orden', 'fecha_desc'); // fecha_asc|fecha_desc|monto_asc|monto_desc

        $query = UserPrestamo::query()
            ->with([
                'cliente:id,nombre,apellido,email',
                'caja:id_caja,nombre',
            ])
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->whereHas('cliente', function ($qc) use ($search) {
                        $qc->where('nombre','like',"%{$search}%")
                           ->orWhere('apellido','like',"%{$search}%")
                           ->orWhere('email','like',"%{$search}%");
                    })
                    ->orWhere('id', $search)
                    ->orWhere('cantidad','like',"%{$search}%");
                });
            })
            ->when(in_array($status, ['1','2','3','4','5','6'], true),
                fn($q) => $q->where('status', (int)$status))
            ->when($desde, fn($q) => $q->whereDate('fecha_inicio','>=',$desde))
            ->when($hasta, fn($q) => $q->whereDate('fecha_inicio','<=',$hasta));

        $query = match ($orden) {
            'monto_asc'  => $query->orderBy('cantidad','asc'),
            'monto_desc' => $query->orderBy('cantidad','desc'),
            'fecha_asc'  => $query->orderBy('fecha_inicio','asc'),
            'fecha_desc' => $query->orderBy('fecha_inicio','desc'),
            default      => $query->orderBy('fecha_inicio','desc'),
        };

        $prestamos = $query->paginate(15)->withQueryString();

        $statusOptions = [
            null => 'Todos',
            1 => 'Autorizado',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazado',
            5 => 'Pagado',
            6 => 'Terminado',
        ];

        return view('adminuserprestamos.index', compact(
            'prestamos','search','status','statusOptions','desde','hasta','orden'
        ));
    }

    /** SHOW */
    public function show(UserPrestamo $prestamo)
    {
        $prestamo->load(['cliente','caja','aval','abonos']);

        $statusOptions = [
            1 => 'Autorizado',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazado',
            5 => 'Pagado',
            6 => 'Terminado',
        ];

        return view('adminuserprestamos.show', compact('prestamo','statusOptions'));
    }

    /** CREATE */
    public function create()
    {
        $clientes = Cliente::orderBy('nombre')->get();
        $planes   = Prestamo::where('status', 1)->get();
        $cajas    = Caja::where('estado', 'abierta')->get();

        return view('adminuserprestamos.create', compact('clientes','planes','cajas'));
    }

    /** STORE */
    public function store(Request $request)
    {
        $request->validate([
            'id_cliente'   => ['required','exists:clientes,id', function($attr,$value,$fail) {
                if (UserPrestamo::where('id_cliente',$value)->whereIn('status',[2,3])->exists()) {
                    $fail('Ya tienes una solicitud pendiente o en revisión.');
                }
            }],
            'id_activo'    => 'required|exists:prestamos,id_prestamo',
            'fecha_inicio' => 'required|date',
            'cantidad'     => 'required|numeric|min:0',
            'id_caja'      => 'required|exists:cajas,id_caja',
            'codigo_aval'  => 'nullable|string|exists:clientes,codigo_cliente|max:50',
            'doc_solicitud_aval'        => 'required_without:codigo_aval|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'doc_comprobante_domicilio' => 'required_without:codigo_aval|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'doc_ine_frente'            => 'required_without:codigo_aval|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'doc_ine_reverso'           => 'required_without:codigo_aval|file|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);

        $data = $request->only('id_cliente','id_activo','fecha_inicio','cantidad','codigo_aval','id_caja');
        $plan = Prestamo::findOrFail($data['id_activo']); // asumiendo primaryKey = id_prestamo en el modelo

        $prestamo = new UserPrestamo([
            'id_cliente'       => $data['id_cliente'],
            'id_activo'        => $data['id_activo'],
            'fecha_solicitud'  => now(),
            'fecha_inicio'     => $data['fecha_inicio'],
            'cantidad'         => $data['cantidad'],
            'tipo_prestamo'    => $plan->periodo,
            'semanas'          => $plan->semanas,
            'interes'          => $plan->interes,
            'interes_generado' => $data['cantidad'] * $plan->interes / 100,
            'status'           => 3,
            'aval_status'      => 2,
            'id_usuario'       => Auth::id(),
            'abonos_echos'     => 0,
            'num_atrasos'      => 0,
            'mora_acumulada'   => 0.00,
            'id_caja'          => $data['id_caja'],
        ]);

        if (!empty($data['codigo_aval'])) {
            $aval = Cliente::where('codigo_cliente',$data['codigo_aval'])->first();
            $prestamo->aval_id = $aval?->id;
        } else {
            foreach ([
                'doc_solicitud_aval',
                'doc_comprobante_domicilio',
                'doc_ine_frente',
                'doc_ine_reverso',
            ] as $field) {
                if ($request->hasFile($field)) {
                    $prestamo->{$field} = $request->file($field)->store('prestamos/aval','public');
                }
            }
        }

        $prestamo->save();

        // ===================== Generar plan de pagos =====================
        $fechaInicio = Carbon::parse($prestamo->fecha_inicio);
        $montoTotal  = $prestamo->cantidad + $prestamo->interes_generado;
        $pagoMinimo  = $montoTotal / max(1, $plan->semanas);

        for ($i = 1; $i <= $plan->semanas; $i++) {
            $fechaVto  = $fechaInicio->copy()->addWeeks($i)->toDateString();
            $pagado    = $pagoMinimo * ($i - 1);
            $saldoRest = max(0, $montoTotal - $pagado);

            UserAbono::create([
                // 🔴 Usar la FK que esperan tus relaciones/controladores:
                'user_prestamo_id'  => $prestamo->id,
                'id_cliente'        => $prestamo->id_cliente,

                // Monto pagado real aún no realizado
                'cantidad'          => 0,

                'tipo_abono'        => 'pendiente',
                'num_pago'          => $i,
                'mora_generada'     => 0,
                'saldo_restante'    => $saldoRest,

                // Fecha programada del pago
                'fecha'             => $fechaVto,
                'fecha_vencimiento' => $fechaVto,

                // 0 = Pendiente
                'status'            => 0,
            ]);
        }

        return redirect()->route('user_prestamos.index')
            ->with('success','Préstamo creado correctamente y abonos generados.');
    }

    public function edit(UserPrestamo $prestamo)
    {
        $statusOptions = [
            1 => 'Autorizado',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazado',
            5 => 'Pagado',
            6 => 'Terminado',
        ];
        $cajas = Caja::where('estado','abierta')->get();

        return view('adminuserprestamos.edit', compact('prestamo','statusOptions','cajas'));
    }

    public function update(Request $request, UserPrestamo $prestamo)
    {
        $data = $request->validate([
            'status'   => 'required|in:1,2,3,4,5,6',
            'nota'     => 'nullable|string',
            'id_caja'  => 'required|exists:cajas,id_caja',
        ]);

        $newStatus = (int) $data['status'];
        $oldStatus = (int) $prestamo->status;

        $prestamo->update([
            'status'            => $newStatus,
            'nota'              => $data['nota'] ?? null,
            'aval_responded_at' => now(),
            'id_caja'           => $data['id_caja'],
        ]);

        // 5 => Pagado: egreso (desembolso)
        if ($oldStatus !== 5 && $newStatus === 5) {
            $this->descontarDeCaja($prestamo);
        }

        // 6 => Terminado: ingreso (capital + intereses)
        if ($oldStatus !== 6 && $newStatus === 6) {
            $this->ingresarPagoEnCaja($prestamo);
        }

        return redirect()->route('user_prestamos.index')
            ->with('success','Préstamo actualizado correctamente.');
    }

    /** Egreso al desembolsar — Categoría Gasto: "Préstamos", proveedor=cliente (o creado), origen=préstamo */
    protected function descontarDeCaja(UserPrestamo $prestamo)
    {
        $caja = Caja::find($prestamo->id_caja);
        if (!$caja) { throw new \RuntimeException('Caja no encontrada.'); }

        $ultimoMov     = $caja->movimientos()->latest('fecha')->first();
        $saldoAnterior = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $monto         = $prestamo->cantidad;
        $saldoPosterior= $saldoAnterior - $monto;

        // Categoría Gasto "Préstamos"
        $catGasto = CategoriaGasto::firstOrCreate(
            ['nombre' => 'Préstamos'],
            ['id_usuario' => 1]
        );

        // Proveedor: garantizarlo desde el cliente
        $proveedorId = $this->proveedorResolver->ensureFromCliente($prestamo->id_cliente);

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Egreso',
            'id_cat_gasto'    => $catGasto->id_cat_gasto,
            'id_sub_gasto'    => null,

            'proveedor_id'    => $proveedorId,          // ← ya es proveedor real
            'origen_id'       => $prestamo->id,

            'monto'           => $monto,
            'fecha'           => $prestamo->fecha_inicio ?? now(),
            'descripcion'     => "Desembolso préstamo #{$prestamo->id}",
            'monto_anterior'  => $saldoAnterior,
            'monto_posterior' => $saldoPosterior,
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldoPosterior]);
    }

    /** Ingreso al terminar — Categoría Ingreso: "Préstamos", proveedor=cliente (o creado), origen=préstamo */
    protected function ingresarPagoEnCaja(UserPrestamo $prestamo)
    {
        $caja = Caja::find($prestamo->id_caja);
        if (!$caja) { throw new \RuntimeException('Caja no encontrada.'); }

        $ultimoMov     = $caja->movimientos()->latest('fecha')->first();
        $saldoAnterior = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;

        $monto         = $prestamo->cantidad + $prestamo->interes_generado;
        $saldoPosterior= $saldoAnterior + $monto;

        // Categoría Ingreso "Préstamos"
        $catIng = CategoriaIngreso::firstOrCreate(
            ['nombre' => 'Préstamos'],
            ['id_usuario' => 1]
        );

        // Proveedor: garantizarlo desde el cliente
        $proveedorId = $this->proveedorResolver->ensureFromCliente($prestamo->id_cliente);

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Ingreso',
            'id_cat_ing'      => $catIng->id_cat_ing,
            'id_sub_ing'      => null,

            'proveedor_id'    => $proveedorId,          // ← ya es proveedor real
            'origen_id'       => $prestamo->id,

            'monto'           => $monto,
            'fecha'           => now(),
            'descripcion'     => "Cobro préstamo #{$prestamo->id}",
            'monto_anterior'  => $saldoAnterior,
            'monto_posterior' => $saldoPosterior,
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldoPosterior]);
    }
}
