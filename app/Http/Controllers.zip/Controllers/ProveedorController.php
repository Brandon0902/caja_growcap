<?php

namespace App\Http\Controllers;

use App\Models\Proveedor;
use Illuminate\Http\Request;

class ProveedorController extends Controller
{
    public function index(Request $request)
    {
        $search = trim($request->input('search', ''));
        $estado = $request->input('estado'); // 'activo' | 'inactivo' | null
        $orden  = $request->input('orden', 'recientes'); // 'recientes' | 'antiguos' | 'nombre_asc' | 'nombre_desc'

        $query = Proveedor::query()
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('nombre', 'like', "%{$search}%")
                       ->orWhere('email', 'like', "%{$search}%")
                       ->orWhere('telefono', 'like', "%{$search}%")
                       ->orWhere('contacto', 'like', "%{$search}%")
                       ->orWhere('direccion', 'like', "%{$search}%");
                });
            })
            ->when(in_array($estado, ['activo','inactivo'], true), fn($q) => $q->where('estado', $estado));

        $query = match ($orden) {
            'antiguos'     => $query->orderBy('id_proveedor', 'asc'),
            'nombre_asc'   => $query->orderBy('nombre', 'asc'),
            'nombre_desc'  => $query->orderBy('nombre', 'desc'),
            default        => $query->orderBy('id_proveedor', 'desc'), // recientes
        };

        $proveedores = $query->paginate(15)->withQueryString();

        return view('proveedores.index', [
            'proveedores' => $proveedores,
            'search'      => $search,
            'estado'      => $estado,
            'orden'       => $orden,
        ]);
    }

    public function create()
    {
        return view('proveedores.create');
    }

   public function store(Request $request)
    {
        $data = $request->validate([
            'nombre'    => 'required|string|max:255',
            'email'     => 'nullable|email|max:255',
            'telefono'  => 'nullable|string|max:50',
            'contacto'  => 'nullable|string|max:255',
            'direccion' => 'nullable|string|max:500',
            'estado'    => 'required|in:activo,inactivo', // <-- aquí
        ]);

        $proveedor = Proveedor::create($data);

        if ($request->filled('back')) {
            return redirect($request->input('back'))
                ->with('nuevo_proveedor_id', $proveedor->id_proveedor)
                ->with('success', 'Proveedor creado correctamente.');
        }

        return redirect()->route('proveedores.index')
            ->with('success', 'Proveedor creado correctamente.');
    }

    public function edit(Proveedor $proveedore) // ¡OJO! por el plural, Laravel usa $proveedore
    {
        return view('proveedores.edit', ['proveedor' => $proveedore]);
    }

   public function update(Request $request, Proveedor $proveedore)
    {
        $data = $request->validate([
            'nombre'    => 'required|string|max:255',
            'email'     => 'nullable|email|max:255',
            'telefono'  => 'nullable|string|max:50',
            'contacto'  => 'nullable|string|max:255',
            'direccion' => 'nullable|string|max:500',
            'estado'    => 'required|in:activo,inactivo', // <-- aquí
        ]);

        $proveedore->update($data);

        if ($request->filled('back')) {
            return redirect($request->input('back'))
                ->with('nuevo_proveedor_id', $proveedore->id_proveedor)
                ->with('success', 'Proveedor actualizado correctamente.');
        }

        return redirect()->route('proveedores.index')
            ->with('success', 'Proveedor actualizado correctamente.');
    }

    /** Activar / Inactivar rápido */
    public function toggle(Proveedor $proveedore)
    {
        $proveedore->update([
            'estado' => $proveedore->estado === 'activo' ? 'inactivo' : 'activo',
        ]);

        return back()->with('success', 'Estado actualizado.');
    }
}
