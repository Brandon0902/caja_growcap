<?php

namespace App\Http\Controllers;

use App\Models\Caja;
use App\Models\CategoriaGasto;
use App\Models\CategoriaIngreso;
use App\Models\Cliente;
use App\Models\Inversion;
use App\Models\UserInversion;
use App\Models\MovimientoCaja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserInversionController extends Controller
{
    /**
     * INDEX GENERAL: lista TODAS las inversiones con filtros
     */
    public function index(Request $request)
    {
        $search = trim($request->input('search', ''));
        $status = $request->input('status'); // 1..6 o null
        $desde  = $request->input('desde');  // Y-m-d o null
        $hasta  = $request->input('hasta');  // Y-m-d o null
        $orden  = $request->input('orden', 'fecha_inicio_desc');

        $query = UserInversion::query()
            ->with([
                'cliente:id,nombre,apellido,email',
                // Tomamos periodo y rendimiento desde la tabla inversiones (PK = id)
                'plan:id,periodo,rendimiento',
            ])
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->whereHas('cliente', function ($qc) use ($search) {
                        $qc->where('nombre', 'like', "%{$search}%")
                           ->orWhere('apellido', 'like', "%{$search}%")
                           ->orWhere('email', 'like', "%{$search}%");
                    })
                    ->orWhere('id', $search) // permitir buscar por #
                    ->orWhere('cantidad', 'like', "%{$search}%");
                });
            })
            ->when(in_array($status, ['1','2','3','4','5','6'], true), function ($q) use ($status) {
                $q->where('status', (int) $status);
            })
            ->when($desde, function ($q) use ($desde) {
                $q->whereDate('fecha_inicio', '>=', $desde);
            })
            ->when($hasta, function ($q) use ($hasta) {
                $q->whereDate('fecha_inicio', '<=', $hasta);
            });

        // Ordenamiento
        $query = match ($orden) {
            'monto_asc'         => $query->orderBy('cantidad', 'asc'),
            'monto_desc'        => $query->orderBy('cantidad', 'desc'),
            'fecha_inicio_asc'  => $query->orderBy('fecha_inicio', 'asc'),
            'fecha_inicio_desc' => $query->orderBy('fecha_inicio', 'desc'),
            default             => $query->orderBy('fecha_inicio', 'desc'),
        };

        $inversiones = $query->paginate(15)->withQueryString();

        $statusOptions = [
            null => 'Todos',
            1 => 'Autorizada',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazada',
            5 => 'Invertida',
            6 => 'Finalizada',
        ];

        return view('adminuserinversiones.index', compact(
            'inversiones', 'search', 'status', 'statusOptions', 'desde', 'hasta', 'orden'
        ));
    }

    /**
     * SHOW: detalle de UNA inversión (ya no por cliente)
     */
    public function show(UserInversion $inversion)
    {
        $inversion->load(['cliente', 'plan', 'caja']);

        $statusOptions = [
            1 => 'Autorizada',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazada',
            5 => 'Invertida',  // Egreso de caja
            6 => 'Finalizada', // Ingreso de caja
        ];

        return view('adminuserinversiones.show', compact('inversion', 'statusOptions'));
    }

    /**
     * FORMULARIO DE CREACIÓN
     */
    public function create()
    {
        $clientes = Cliente::orderBy('nombre')->get();
        $planes   = Inversion::where('status', 1)->get();
        $cajas    = Caja::where('estado', 'abierta')->get();

        return view('adminuserinversiones.create', compact('clientes', 'planes', 'cajas'));
    }

    /**
     * STORE: tras crear, redirige al index general
     */
    public function store(Request $request)
    {
        $request->validate([
            'id_cliente'   => 'required|exists:clientes,id',
            'id_activo'    => 'required|exists:inversiones,id', // PK = id
            'fecha_inicio' => 'required|date',
            'cantidad'     => 'required|numeric|min:0.01',
            'id_caja'      => 'required|exists:cajas,id_caja',
        ]);

        $data = $request->only('id_cliente','id_activo','fecha_inicio','cantidad','id_caja');

        $plan = Inversion::findOrFail($data['id_activo']); // inversiones.id
        $tasa = $plan->rendimiento ?? 0;

        $inversion = new UserInversion([
            'id_cliente'           => $data['id_cliente'],
            'id_activo'            => $data['id_activo'],
            'fecha_solicitud'      => now(),
            'fecha_inicio'         => $data['fecha_inicio'],
            'cantidad'             => $data['cantidad'],
            'rendimiento'          => $tasa, // guardamos la tasa en user_inversiones
            'rendimiento_generado' => $data['cantidad'] * $tasa / 100,
            'status'               => 2,  // Pendiente
            'id_usuario'           => Auth::id(),
            'id_caja'              => $data['id_caja'],
        ]);

        $inversion->save();

        return redirect()
            ->route('user_inversiones.index')
            ->with('success', 'Solicitud de inversión creada correctamente.');
    }

    /**
     * EDIT
     */
    public function edit(UserInversion $inversion)
    {
        $statusOptions = [
            1 => 'Autorizada',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazada',
            5 => 'Invertida',
            6 => 'Finalizada',
        ];
        $cajas = Caja::where('estado','abierta')->get();

        return view('adminuserinversiones.edit', compact('inversion','statusOptions','cajas'));
    }

    /**
     * UPDATE: maneja estado/caja y movimientos
     */
    public function update(Request $request, UserInversion $inversion)
    {
        // Validamos, pero hacemos id_caja obligatorio sólo si va a 5/6
        $data = $request->validate([
            'status'   => 'required|in:1,2,3,4,5,6',
            'nota'     => 'nullable|string',
            'id_caja'  => 'nullable|exists:cajas,id_caja',
        ]);

        $newStatus = (int) $data['status'];
        $oldStatus = (int) $inversion->status;

        // Si va a 5 o 6 y no tenemos caja (ni en request ni en el registro), error
        if (in_array($newStatus, [5, 6], true) && empty($data['id_caja']) && empty($inversion->id_caja)) {
            return back()
                ->withErrors(['id_caja' => 'Debes seleccionar una caja para marcar la inversión como Invertida o Finalizada.'])
                ->withInput();
        }

        // Actualizamos, preservando la caja previa si no se envió una nueva
        $inversion->update([
            'status'          => $newStatus,
            'nota'            => $data['nota'] ?? null,
            'fecha_respuesta' => now(),
            'id_caja'         => $data['id_caja'] ?? $inversion->id_caja,
        ]);

        // Refrescamos el modelo
        $inversion->refresh();

        // 5 => Invertida: egreso de caja
        if ($oldStatus !== 5 && $newStatus === 5) {
            $this->descontarDeCaja($inversion);
        }

        // 6 => Finalizada: ingreso de caja (monto + intereses)
        if ($oldStatus !== 6 && $newStatus === 6) {
            $this->ingresarRendimientoEnCaja($inversion);
        }

        return redirect()
            ->route('user_inversiones.index')
            ->with('success','Inversión actualizada correctamente.');
    }

    /**
     * Egreso al marcar como Invertida
     */
    protected function descontarDeCaja(UserInversion $inversion)
    {
        // Buscar por id para evitar null en la relación
        $caja = Caja::find($inversion->id_caja);
        if (!$caja) {
            throw new \RuntimeException('No se encontró la caja asociada a la inversión.');
        }

        $ultimoMov      = $caja->movimientos()->latest('fecha')->first();
        $saldoAnterior  = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $monto          = $inversion->cantidad;
        $saldoPosterior = $saldoAnterior - $monto;
        $cat            = CategoriaGasto::firstWhere('nombre','Inversiones');

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Egreso',
            'id_cat_gasto'    => $cat->id_cat_gasto ?? null,
            'monto'           => $monto,
            'fecha'           => now(),
            'descripcion'     => "Desembolso inversión #{$inversion->id}",
            'monto_anterior'  => $saldoAnterior,
            'monto_posterior' => $saldoPosterior,
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldoPosterior]);
    }

    /**
     * Ingreso al marcar como Finalizada (capital + intereses)
     */
    protected function ingresarRendimientoEnCaja(UserInversion $inversion)
    {
        $caja = Caja::find($inversion->id_caja);
        if (!$caja) {
            throw new \RuntimeException('No se encontró la caja asociada a la inversión.');
        }

        $ultimoMov      = $caja->movimientos()->latest('fecha')->first();
        $saldoAnterior  = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $monto          = $inversion->cantidad + $inversion->rendimiento_generado;
        $saldoPosterior = $saldoAnterior + $monto;
        $cat            = CategoriaIngreso::firstWhere('nombre','Inversiones');

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Ingreso',
            'id_cat_ing'      => $cat->id_cat_ing ?? null,
            'monto'           => $monto,
            'fecha'           => now(),
            'descripcion'     => "Cobro inversión #{$inversion->id}",
            'monto_anterior'  => $saldoAnterior,
            'monto_posterior' => $saldoPosterior,
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldoPosterior]);
    }
}
