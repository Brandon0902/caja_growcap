<?php

namespace App\Http\Controllers;

use App\Models\MovimientoFinanciero;
use App\Models\Cliente;
use App\Models\Presupuesto;
use Illuminate\Http\Request;

class ContabilidadController extends Controller
{
    protected array $meses = [
        1  => 'Enero',
        2  => 'Febrero',
        3  => 'Marzo',
        4  => 'Abril',
        5  => 'Mayo',
        6  => 'Junio',
        7  => 'Julio',
        8  => 'Agosto',
        9  => 'Septiembre',
        10 => 'Octubre',
        11 => 'Noviembre',
        12 => 'Diciembre',
    ];

    protected array $fuentes = [
        'Movimientos Caja',
        'Depósitos',
        'Retiros',
        'Ahorros',
        'Inversiones',
        'Préstamos',
        'Abonos',
    ];

    /**
     * Mostrar formulario inicial con listas de meses, años, fuentes y clientes.
     */
    public function index()
    {
        $años         = range(now()->year, now()->year - 5);
        $clientes     = Cliente::orderBy('nombre')->pluck('nombre', 'id');
        $presupuestos = collect(); // Vacío hasta filtrar

        return view('contabilidad.index', [
            'meses'        => $this->meses,
            'años'         => $años,
            'fuentes'      => $this->fuentes,
            'clientes'     => $clientes,
            'presupuestos' => $presupuestos,
        ]);
    }

    /**
     * Filtrar movimientos según criterios y cargar presupuestos del mes/año.
     */
    public function filtrar(Request $request)
    {
        $data = $request->validate([
            'mes'        => 'required|integer|min:1|max:12',
            'año'        => 'required|integer',
            'tipo'       => 'nullable|in:ingreso,egreso',
            'fuente'     => 'nullable|string',
            'cliente_id' => 'nullable|integer|exists:clientes,id',
        ]);

        $mes        = $data['mes'];
        $año        = $data['año'];
        $tipo       = $data['tipo']       ?? null;
        $fuente     = $data['fuente']     ?? null;
        $cliente_id = $data['cliente_id'] ?? null;

        // Consulta de movimientos
        $movs = MovimientoFinanciero::query()
            ->whereYear('fecha', $año)
            ->whereMonth('fecha', $mes)
            ->when($tipo,       fn($q) => $q->where('tipo',       $tipo))
            ->when($fuente,     fn($q) => $q->where('fuente',     $fuente))
            ->when($cliente_id, fn($q) => $q->where('cliente_id', $cliente_id))
            ->orderBy('fecha')
            ->get();

        // Total neto
        $total = $movs->sum('monto');

        // Recargar listas
        $años     = range(now()->year, now()->year - 5);
        $clientes = Cliente::orderBy('nombre')->pluck('nombre','id');

        // Cargar presupuestos para este mes/año, keyed by fuente
        $presupuestos = Presupuesto::where('mes', $mes)
            ->where('año', $año)
            ->get()
            ->keyBy('fuente');

        return view('contabilidad.index', [
            'meses'        => $this->meses,
            'años'         => $años,
            'fuentes'      => $this->fuentes,
            'clientes'     => $clientes,
            'movs'         => $movs,
            'total'        => $total,
            'mes'          => $mes,
            'año'          => $año,
            'tipo'         => $tipo,
            'fuente'       => $fuente,
            'cliente_id'   => $cliente_id,
            'presupuestos' => $presupuestos,
        ]);
    }
}
