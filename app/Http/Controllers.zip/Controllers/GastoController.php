<?php

namespace App\Http\Controllers;

use App\Models\Gasto;
use App\Models\Caja;
use Illuminate\Http\Request;

class GastoController extends Controller
{
    public function index()
    {
        // opcionalmente cargamos relaciones para mostrarlas en la tabla
        $gastos = Gasto::with('cajaOrigen', 'cajaDestino')
                       ->latest()
                       ->paginate(15);

        return view('gastos.index', compact('gastos'));
    }

    public function create()
    {
        // traemos todas las cajas para el <select>
        $cajas = Caja::orderBy('nombre')->get();

        return view('gastos.create', compact('cajas'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'caja_id'           => 'required|exists:cajas,id_caja',
            'destino_caja_id'   => 'nullable|exists:cajas,id_caja',
            'tipo'              => 'required|string|max:50',
            'cantidad'          => 'required|numeric|min:0',
            'concepto'          => 'nullable|string',
        ]);

        Gasto::create($data);

        return redirect()
            ->route('gastos.index')
            ->with('success', 'Gasto creado correctamente.');
    }

    public function show(Gasto $gasto)
    {
        // cargar relaciones para poder hacer $gasto->cajaOrigen->nombre etc
        $gasto->load('cajaOrigen', 'cajaDestino');

        return view('gastos.show', compact('gasto'));
    }

    public function edit(Gasto $gasto)
    {
        $cajas = Caja::orderBy('nombre')->get();

        return view('gastos.edit', compact('gasto', 'cajas'));
    }

    public function update(Request $request, Gasto $gasto)
    {
        $data = $request->validate([
            'caja_id'           => 'required|exists:cajas,id_caja',
            'destino_caja_id'   => 'nullable|exists:cajas,id_caja',
            'tipo'              => 'required|string|max:50',
            'cantidad'          => 'required|numeric|min:0',
            'concepto'          => 'nullable|string',
        ]);

        $gasto->update($data);

        return redirect()
            ->route('gastos.index')
            ->with('success', 'Gasto actualizado correctamente.');
    }

    public function destroy(Gasto $gasto)
    {
        $gasto->delete();

        return back()->with('success', 'Gasto eliminado.');
    }
}
