<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index(Request $request)
    {
        $year   = (int) $request->input('year', now()->year);
        $months = collect((array) $request->input('months', []))
                    ->map(fn($m)=>(int)$m)->filter()->values()->all();

        // Rango por año o por meses seleccionados
        $start = Carbon::create($year, 1, 1)->startOfYear();
        $end   = Carbon::create($year, 12, 31)->endOfYear();
        if (!empty($months)) {
            $start = Carbon::create($year, min($months), 1)->startOfMonth();
            $end   = Carbon::create($year, max($months), 1)->endOfMonth();
        }

        // ---------- KPIs ----------
        $totalSociosActivos = DB::table('clientes')->where('status', 1)->count();

        $depositos = DB::table('vw_depositos_clean')
            ->whereBetween('fecha', [$start, $end])
            ->when(DB::getSchemaBuilder()->hasColumn('user_depositos','status'), fn($q)=>$q->where('status', 1))
            ->sum('monto');

        $retiros = DB::table('vw_retiros_union')
            ->whereBetween('fecha', [$start, $end])
            ->sum('monto');

        $ingresosCaja = DB::table('movimientos_caja')
            ->whereBetween('fecha', [$start, $end])
            ->where('tipo_mov','Ingreso')
            ->sum('monto');

        $egresosCaja = DB::table('movimientos_caja')
            ->whereBetween('fecha', [$start, $end])
            ->where('tipo_mov','Egreso')
            ->sum('monto');

        // KPIs de inversiones (desde user_inversiones)
        $totalInvertido = DB::table('vw_user_inversiones_clean')
            ->whereBetween('fecha', [$start, $end])
            ->when(DB::getSchemaBuilder()->hasColumn('user_inversiones','status'), fn($q)=>$q->where('status', 1))
            ->sum('monto');

        $numInversiones = DB::table('vw_user_inversiones_clean')
            ->whereBetween('fecha', [$start, $end])
            ->when(DB::getSchemaBuilder()->hasColumn('user_inversiones','status'), fn($q)=>$q->where('status', 1))
            ->count();

        // ---------- Series mensuales ----------
        $labels = ['enero','febrero','marzo','abril','mayo','junio','julio','agosto','septiembre','octubre','noviembre','diciembre'];

        $depMes = DB::table('vw_depositos_clean')
            ->selectRaw('MONTH(fecha) m, SUM(monto) total')
            ->whereYear('fecha', $year)
            ->when(!empty($months), fn($q)=>$q->whereIn(DB::raw('MONTH(fecha)'), $months))
            ->groupBy('m')->orderBy('m')->pluck('total','m');

        $retMes = DB::table('vw_retiros_union')
            ->selectRaw('MONTH(fecha) m, SUM(monto) total')
            ->whereYear('fecha', $year)
            ->when(!empty($months), fn($q)=>$q->whereIn(DB::raw('MONTH(fecha)'), $months))
            ->groupBy('m')->orderBy('m')->pluck('total','m');

        $ingMes = DB::table('movimientos_caja')
            ->selectRaw('MONTH(fecha) m, SUM(monto) total')
            ->whereYear('fecha', $year)
            ->where('tipo_mov', 'Ingreso')
            ->when(!empty($months), fn($q)=>$q->whereIn(DB::raw('MONTH(fecha)'), $months))
            ->groupBy('m')->orderBy('m')->pluck('total','m');

        $egrMes = DB::table('movimientos_caja')
            ->selectRaw('MONTH(fecha) m, SUM(monto) total')
            ->whereYear('fecha', $year)
            ->where('tipo_mov', 'Egreso')
            ->when(!empty($months), fn($q)=>$q->whereIn(DB::raw('MONTH(fecha)'), $months))
            ->groupBy('m')->orderBy('m')->pluck('total','m');

        // Inversión mensual (user_inversiones)
        $invMes = DB::table('vw_user_inversiones_clean')
            ->selectRaw('MONTH(fecha) m, SUM(monto) total')
            ->whereYear('fecha', $year)
            ->when(!empty($months), fn($q)=>$q->whereIn(DB::raw('MONTH(fecha)'), $months))
            ->when(DB::getSchemaBuilder()->hasColumn('user_inversiones','status'), fn($q)=>$q->where('status', 1))
            ->groupBy('m')->orderBy('m')->pluck('total','m');

        $serieDepositos = [];
        $serieRetiros   = [];
        $serieIngresos  = [];
        $serieEgresos   = [];
        $serieInvMensual= [];
        for ($i=1; $i<=12; $i++) {
            if (!empty($months) && !in_array($i, $months)) {
                $serieDepositos[] = 0; $serieRetiros[] = 0; $serieIngresos[] = 0; $serieEgresos[] = 0; $serieInvMensual[] = 0; 
                continue;
            }
            $serieDepositos[] = (float)($depMes[$i] ?? 0);
            $serieRetiros[]   = (float)($retMes[$i] ?? 0);
            $serieIngresos[]  = (float)($ingMes[$i] ?? 0);
            $serieEgresos[]   = (float)($egrMes[$i] ?? 0);
            $serieInvMensual[]= (float)($invMes[$i] ?? 0);
        }

        // ---------- Series anuales (línea) ----------
        $yearsSet = collect()
            ->merge(DB::table('vw_depositos_clean')->selectRaw('DISTINCT YEAR(fecha) y')->pluck('y'))
            ->merge(DB::table('vw_retiros_union')->selectRaw('DISTINCT YEAR(fecha) y')->pluck('y'))
            ->merge(DB::table('vw_user_inversiones_clean')->selectRaw('DISTINCT YEAR(fecha) y')->pluck('y'))
            ->unique()->sort()->values();

        $depYear = DB::table('vw_depositos_clean')
            ->selectRaw('YEAR(fecha) y, SUM(monto) total')->groupBy('y')->pluck('total','y');

        $retYear = DB::table('vw_retiros_union')
            ->selectRaw('YEAR(fecha) y, SUM(monto) total')->groupBy('y')->pluck('total','y');

        $invYear = DB::table('vw_user_inversiones_clean')
            ->selectRaw('YEAR(fecha) y, SUM(monto) total')
            ->when(DB::getSchemaBuilder()->hasColumn('user_inversiones','status'), fn($q)=>$q->where('status', 1))
            ->groupBy('y')->pluck('total','y');

        $labelsYears  = $yearsSet->all();
        $serieDepYear = [];
        $serieRetYear = [];
        $serieInvYear = [];
        foreach ($labelsYears as $y) {
            $serieDepYear[] = (float)($depYear[$y] ?? 0);
            $serieRetYear[] = (float)($retYear[$y] ?? 0);
            $serieInvYear[] = (float)($invYear[$y] ?? 0);
        }

        return view('dashboard.index', [
            'year'               => $year,
            'months'             => $months,
            'start'              => $start,
            'end'                => $end,
            'totalSociosActivos' => $totalSociosActivos,
            'depositos'          => $depositos,
            'retiros'            => $retiros,
            'ingresos'           => $ingresosCaja,
            'egresos'            => $egresosCaja,

            // KPIs inversiones
            'totalInvertido'     => $totalInvertido,
            'numInversiones'     => $numInversiones,

            // Barras mensuales
            'labels'             => $labels,
            'serieDepositos'     => $serieDepositos,
            'serieRetiros'       => $serieRetiros,
            'serieIngresos'      => $serieIngresos,
            'serieEgresos'       => $serieEgresos,

            // Línea mensual (dep/INV/ret)
            'serieInvMensual'    => $serieInvMensual,

            // Línea anual (dep/INV/ret)
            'labelsYears'        => $labelsYears,
            'serieDepYear'       => $serieDepYear,
            'serieInvYear'       => $serieInvYear,
            'serieRetYear'       => $serieRetYear,
        ]);
    }
}
