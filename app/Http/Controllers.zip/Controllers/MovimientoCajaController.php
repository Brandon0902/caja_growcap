<?php

namespace App\Http\Controllers;

use App\Models\MovimientoCaja;
use App\Models\Caja;
use App\Models\CategoriaIngreso;
use App\Models\SubcategoriaIngreso;
use App\Models\CategoriaGasto;
use App\Models\SubcategoriaGasto;
use App\Models\Proveedor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class MovimientoCajaController extends Controller
{
    public function index()
    {
        $movimientos = MovimientoCaja::with([
                'caja:id_caja,nombre',
                'usuario:id_usuario,name', // <- aquí estaba el problema (antes: id)
                'categoriaIngreso:id_cat_ing,nombre',
                'subcategoriaIngreso:id_sub_ingreso,nombre',
                'categoriaGasto:id_cat_gasto,nombre',
                'subcategoriaGasto:id_sub_gasto,nombre',
                'proveedor:id_proveedor,nombre',
            ])
            ->orderBy('fecha', 'desc')
            ->paginate(20);

        return view('movimientos-caja.index', compact('movimientos'));
    }

    public function create()
    {
        $cajas       = Caja::orderBy('nombre')->get();
        $catsIngreso = CategoriaIngreso::orderBy('nombre')->get();
        $subsIngreso = SubcategoriaIngreso::orderBy('nombre')->get();
        $catsGasto   = CategoriaGasto::orderBy('nombre')->get();
        $subsGasto   = SubcategoriaGasto::orderBy('nombre')->get();

        // Solo proveedores con estado 'activo'
        $proveedores = Proveedor::where('estado', 'activo')
            ->orderBy('nombre')
            ->get();

        return view('movimientos-caja.create', compact(
            'cajas', 'catsIngreso', 'subsIngreso', 'catsGasto', 'subsGasto', 'proveedores'
        ));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_caja'      => 'required|exists:cajas,id_caja',
            // acepta ingreso/gasto del form o Ingreso/Egreso del enum
            'tipo_mov'     => 'required|in:ingreso,gasto,Ingreso,Egreso',

            // opcionales; si vienen deben existir
            'id_cat_ing'   => ['nullable', Rule::exists((new CategoriaIngreso)->getTable(), 'id_cat_ing')],
            'id_sub_ing'   => ['nullable', Rule::exists((new SubcategoriaIngreso)->getTable(), 'id_sub_ingreso')],
            'id_cat_gasto' => ['nullable', Rule::exists((new CategoriaGasto)->getTable(), 'id_cat_gasto')],
            'id_sub_gasto' => ['nullable', Rule::exists((new SubcategoriaGasto)->getTable(), 'id_sub_gasto')],
            'proveedor_id' => ['nullable', Rule::exists((new Proveedor)->getTable(), 'id_proveedor')],

            // NUEVO: id del registro que originó el movimiento (retiro/depósito/prestamo/etc.)
            'origen_id'    => ['nullable', 'integer', 'min:1'],

            'monto'        => 'required|numeric|min:0.01',
            'fecha'        => 'required|date',
            'descripcion'  => 'nullable|string|max:500',
        ]);

        // normaliza a enum de la BD
        $tipoForm           = strtolower($data['tipo_mov']); // ingreso|gasto
        $esIngreso          = $tipoForm === 'ingreso';
        $data['tipo_mov']   = $esIngreso ? 'Ingreso' : 'Egreso';
        $data['id_usuario'] = Auth::id();

        // --- cálculo de saldos ---
        $caja      = Caja::findOrFail($data['id_caja']);
        $ultimoMov = $caja->movimientos()->latest('fecha')->first();
        $montoPrev = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $montoPost = $esIngreso ? ($montoPrev + $data['monto']) : ($montoPrev - $data['monto']);

        $data['monto_anterior']  = $montoPrev;
        $data['monto_posterior'] = $montoPost;

        MovimientoCaja::create($data);
        $caja->update(['saldo_final' => $montoPost]);

        return redirect()
            ->route('movimientos-caja.index')
            ->with('success', 'Movimiento registrado correctamente.');
    }

    public function edit(MovimientoCaja $movimiento)
    {
        $cajas       = Caja::orderBy('nombre')->get();
        $catsIngreso = CategoriaIngreso::orderBy('nombre')->get();
        $subsIngreso = SubcategoriaIngreso::orderBy('nombre')->get();
        $catsGasto   = CategoriaGasto::orderBy('nombre')->get();
        $subsGasto   = SubcategoriaGasto::orderBy('nombre')->get();

        // Solo proveedores con estado 'activo'
        $proveedores = Proveedor::where('estado', 'activo')
            ->orderBy('nombre')
            ->get();

        return view('movimientos-caja.edit', compact(
            'movimiento', 'cajas', 'catsIngreso', 'subsIngreso', 'catsGasto', 'subsGasto', 'proveedores'
        ));
    }

    public function update(Request $request, MovimientoCaja $movimiento)
    {
        $data = $request->validate([
            'id_caja'      => 'required|exists:cajas,id_caja',
            'tipo_mov'     => 'required|in:ingreso,gasto,Ingreso,Egreso',

            'id_cat_ing'   => ['nullable', Rule::exists((new CategoriaIngreso)->getTable(), 'id_cat_ing')],
            'id_sub_ing'   => ['nullable', Rule::exists((new SubcategoriaIngreso)->getTable(), 'id_sub_ingreso')],
            'id_cat_gasto' => ['nullable', Rule::exists((new CategoriaGasto)->getTable(), 'id_cat_gasto')],
            'id_sub_gasto' => ['nullable', Rule::exists((new SubcategoriaGasto)->getTable(), 'id_sub_gasto')],
            'proveedor_id' => ['nullable', Rule::exists((new Proveedor)->getTable(), 'id_proveedor')],

            // NUEVO
            'origen_id'    => ['nullable', 'integer', 'min:1'],

            'monto'        => 'required|numeric|min:0.01',
            'fecha'        => 'required|date',
            'descripcion'  => 'nullable|string|max:500',
        ]);

        // normaliza a enum de la BD
        $tipoForm           = strtolower($data['tipo_mov']);
        $esIngreso          = $tipoForm === 'ingreso';
        $data['tipo_mov']   = $esIngreso ? 'Ingreso' : 'Egreso';
        $data['id_usuario'] = Auth::id();

        // Recalcular saldo tomando esta caja y excluyendo este movimiento
        $cajaNew  = Caja::findOrFail($data['id_caja']);
        $pkName   = $movimiento->getKeyName(); // 'id_mov'
        $pkValue  = $movimiento->getKey();

        $ultimoMov = $cajaNew->movimientos()
            ->where($pkName, '!=', $pkValue)
            ->latest('fecha')
            ->first();

        $montoPrev = $ultimoMov ? $ultimoMov->monto_posterior : $cajaNew->saldo_inicial;
        $montoPost = $esIngreso ? ($montoPrev + $data['monto']) : ($montoPrev - $data['monto']);

        $data['monto_anterior']  = $montoPrev;
        $data['monto_posterior'] = $montoPost;

        $movimiento->update($data);
        $cajaNew->update(['saldo_final' => $montoPost]);

        return redirect()
            ->route('movimientos-caja.index')
            ->with('success', 'Movimiento actualizado correctamente.');
    }
}
