<?php

namespace App\Http\Controllers;

use App\Models\Ahorro;
use App\Models\Caja;
use App\Models\Cliente;
use App\Models\UserAhorro;
use App\Models\MovimientoCaja;
use App\Models\CategoriaIngreso;
use App\Models\CategoriaGasto;
use App\Services\ProveedorResolver;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserAhorroController extends Controller
{
    private const CAT_INGRESO  = 'Ahorros';
    private const CAT_RETIRO_AH= 'Retiros de ahorro';

    protected ProveedorResolver $proveedorResolver;

    public function __construct(ProveedorResolver $proveedorResolver)
    {
        $this->proveedorResolver = $proveedorResolver;
    }

    public function index(Request $request)
    {
        $search = trim($request->input('search', ''));
        $status = $request->input('status');
        $desde  = $request->input('desde');
        $hasta  = $request->input('hasta');
        $orden  = $request->input('orden', 'fecha_desc');

        $query = UserAhorro::query()
            ->with(['cliente:id,nombre,apellido,email', 'ahorro', 'caja:id_caja,nombre'])
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('id', $search)
                       ->orWhere('monto_ahorro', 'like', "%{$search}%")
                       ->orWhere('tipo', 'like', "%{$search}%")
                       ->orWhereHas('cliente', function ($qc) use ($search) {
                           $qc->where('nombre', 'like', "%{$search}%")
                              ->orWhere('apellido', 'like', "%{$search}%")
                              ->orWhere('email', 'like', "%{$search}%");
                       });
                });
            })
            ->when(in_array($status, ['5','6'], true), fn($q) => $q->where('status', (int)$status))
            ->when($desde, fn($q) => $q->whereDate('fecha_inicio', '>=', $desde))
            ->when($hasta, fn($q) => $q->whereDate('fecha_inicio', '<=', $hasta));

        $query = match ($orden) {
            'monto_asc'  => $query->orderBy('monto_ahorro', 'asc'),
            'monto_desc' => $query->orderBy('monto_ahorro', 'desc'),
            'fecha_asc'  => $query->orderBy('fecha_inicio', 'asc'),
            default      => $query->orderBy('fecha_inicio', 'desc'),
        };

        $ahorros = $query->paginate(15)->withQueryString();

        $statusOptions = [null=>'Todos',5=>'Depositado',6=>'Retirado'];

        return view('adminuserahorros.index', compact('ahorros', 'search', 'status', 'statusOptions', 'desde', 'hasta', 'orden'));
    }

    public function show(UserAhorro $ahorro)
    {
        $ahorro->load(['cliente','ahorro','caja']);
        $statusOptions = [5=>'Depositado',6=>'Retirado'];
        return view('adminuserahorros.show', compact('ahorro','statusOptions'));
    }

    public function create()
    {
        return view('adminuserahorros.create', [
            'clientes' => Cliente::orderBy('nombre')->get(),
            'planes'   => Ahorro::where('status',1)->get(),
            'cajas'    => Caja::where('estado','abierta')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_cliente'   => 'required|exists:clientes,id',
            'ahorro_id'    => 'required|exists:ahorros,id',
            'fecha_inicio' => 'required|date',
            'monto_ahorro' => 'required|numeric|min:0.01',
            'id_caja'      => 'required|exists:cajas,id_caja',
        ]);

        $plan = Ahorro::findOrFail($data['ahorro_id']);
        $tasa = $plan->rendimiento ?? 0;

        $ahorro = UserAhorro::create([
            'id_cliente'           => $data['id_cliente'],
            'ahorro_id'            => $data['ahorro_id'],
            'fecha_solicitud'      => now(),
            'fecha_inicio'         => $data['fecha_inicio'],
            'monto_ahorro'         => $data['monto_ahorro'],
            'rendimiento'          => $tasa,
            'rendimiento_generado' => $data['monto_ahorro'] * $tasa / 100,
            'status'               => 5, // Depositado
            'id_usuario'           => Auth::id(),
            'id_caja'              => $data['id_caja'],
        ]);

        $this->ingresarPagoEnCaja($ahorro);

        return redirect()->route('user_ahorros.index')
            ->with('success','Ahorro depositado y registrado en caja.');
    }

    public function edit(UserAhorro $userAhorro)
    {
        return view('adminuserahorros.edit', [
            'userAhorro'    => $userAhorro->load(['cliente','ahorro','caja']),
            'statusOptions' => [5=>'Depositado',6=>'Retirado'],
            'cajas'         => Caja::where('estado','abierta')->get(),
        ]);
    }

    public function update(Request $request, UserAhorro $userAhorro)
    {
        $data = $request->validate([
            'status'  => 'required|in:5,6',
            'id_caja' => 'nullable|exists:cajas,id_caja',
        ]);

        $old = (int)$userAhorro->status;
        $new = (int)$data['status'];

        if (in_array($new, [5,6], true) && empty($data['id_caja']) && empty($userAhorro->id_caja)) {
            return back()
                ->withErrors(['id_caja' => 'Debes seleccionar una caja para depositar o retirar.'])
                ->withInput();
        }

        $userAhorro->update([
            'status'  => $new,
            'id_caja' => $data['id_caja'] ?? $userAhorro->id_caja,
        ]);
        $userAhorro->refresh();

        if ($old !== 5 && $new === 5) $this->ingresarPagoEnCaja($userAhorro);
        if ($old !== 6 && $new === 6) $this->descontarDeCaja($userAhorro);

        return redirect()->route('user_ahorros.index')->with('success','Ahorro actualizado correctamente.');
    }

    /* ===== Movimientos de caja ===== */

    protected function ingresarPagoEnCaja(UserAhorro $ahorro): void
    {
        // Evita duplicado: Ingreso + cat + origen
        $catIng = CategoriaIngreso::firstOrCreate(
            ['nombre' => self::CAT_INGRESO],
            ['id_usuario' => 1]
        );
        $exists = MovimientoCaja::where('tipo_mov','Ingreso')
            ->where('id_cat_ing', $catIng->id_cat_ing)
            ->where('origen_id', $ahorro->id)
            ->exists();
        if ($exists) return;

        $caja = Caja::findOrFail($ahorro->id_caja);

        $last    = $caja->movimientos()->orderByDesc('fecha')->orderByDesc('id_mov')->first();
        $antes   = $last ? $last->monto_posterior : $caja->saldo_inicial;
        $monto   = (float) $ahorro->monto_ahorro + (float) $ahorro->rendimiento_generado;
        $despues = $antes + $monto;

        // proveedor = cliente
        $proveedorId = $this->proveedorResolver->ensureFromCliente($ahorro->id_cliente);

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Ingreso',
            'id_cat_ing'      => $catIng->id_cat_ing,
            'id_sub_ing'      => null,
            'id_cat_gasto'    => null,
            'id_sub_gasto'    => null,
            'proveedor_id'    => $proveedorId,
            'origen_id'       => $ahorro->id,
            'monto'           => $monto,
            'fecha'           => $ahorro->fecha_inicio ?? now(),
            'descripcion'     => "Depósito ahorro #{$ahorro->id}",
            'monto_anterior'  => $antes,
            'monto_posterior' => $despues,
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final'=>$despues]);
    }

    protected function descontarDeCaja(UserAhorro $ahorro): void
    {
        // Evita duplicado: Egreso + cat + origen
        $catG = CategoriaGasto::firstOrCreate(
            ['nombre' => self::CAT_RETIRO_AH],
            ['id_usuario' => 1]
        );
        $exists = MovimientoCaja::where('tipo_mov','Egreso')
            ->where('id_cat_gasto', $catG->id_cat_gasto)
            ->where('origen_id', $ahorro->id)
            ->exists();
        if ($exists) return;

        $caja = Caja::findOrFail($ahorro->id_caja);

        $last    = $caja->movimientos()->orderByDesc('fecha')->orderByDesc('id_mov')->first();
        $antes   = $last ? $last->monto_posterior : $caja->saldo_inicial;
        $monto   = (float) $ahorro->monto_ahorro;
        $despues = $antes - $monto;

        $proveedorId = $this->proveedorResolver->ensureFromCliente($ahorro->id_cliente);

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Egreso',
            'id_cat_gasto'    => $catG->id_cat_gasto,
            'id_sub_gasto'    => null,
            'id_cat_ing'      => null,
            'id_sub_ing'      => null,
            'proveedor_id'    => $proveedorId,
            'origen_id'       => $ahorro->id,
            'monto'           => $monto,
            'fecha'           => now(),
            'descripcion'     => "Retiro ahorro #{$ahorro->id}",
            'monto_anterior'  => $antes,
            'monto_posterior' => $despues,
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final'=>$despues]);
    }
}
