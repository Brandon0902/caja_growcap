<?php

namespace App\Http\Controllers;

use App\Models\Presupuesto;
use Illuminate\Http\Request;

class PresupuestoController extends Controller
{
    // Mostrar formulario con todos los meses, años y fuentes
    public function index(Request $request)
    {
        $mes   = $request->query('mes', now()->month);
        $año   = $request->query('año', now()->year);
        $fuentes = [
          'Movimientos Caja',
          'Depósitos',
          'Retiros',
          'Ahorros',
          'Inversiones',
          'Préstamos',
          'Abonos',
        ];

        // Cargamos los existentes para ese mes/año
        $presupuestos = Presupuesto::where('mes',$mes)
            ->where('año',$año)
            ->get()
            ->keyBy('fuente');

        return view('presupuestos.index', compact('mes','año','fuentes','presupuestos'));
    }

    // Crear o actualizar presupuestos (masivamente)
    public function store(Request $request)
    {
        $data = $request->validate([
            'mes'     => 'required|integer|min:1|max:12',
            'año'     => 'required|integer',
            'monto'   => 'required|array',
            'monto.*' => 'nullable|numeric',
            'fuente'  => 'required|array',
            'fuente.*'=> 'required|string',
        ]);

        foreach($data['fuente'] as $i => $f){
            $m = $data['monto'][$i] ?? 0;
            Presupuesto::updateOrCreate(
                ['fuente'=>$f,'mes'=>$data['mes'],'año'=>$data['año']],
                ['monto'=>$m]
            );
        }

        return redirect()
            ->route('presupuestos.index', ['mes'=>$data['mes'],'año'=>$data['año']])
            ->with('success','Presupuestos guardados');
    }
}
