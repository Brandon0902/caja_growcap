<?php

namespace App\Http\Controllers;

use App\Models\CuentaPorPagar;
use App\Models\CuentaPorPagarDetalle;
use App\Models\Sucursal;
use App\Models\Caja;
use App\Models\Proveedor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class CuentaPorPagarController extends Controller
{
    public function index()
    {
        $cuentas = CuentaPorPagar::with(['sucursal','caja','proveedor','usuario'])
                        ->orderBy('fecha_vencimiento','asc')
                        ->paginate(15);

        return view('cuentas_por_pagar.index', compact('cuentas'));
    }

    public function create()
    {
        $sucursales  = Sucursal::all();
        $cajas       = Caja::all();
        $proveedores = Proveedor::all();

        return view('cuentas_por_pagar.create', compact('sucursales','cajas','proveedores'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_sucursal'       => 'required|exists:sucursales,id_sucursal',
            'id_caja'           => 'required|exists:cajas,id_caja',
            'proveedor_id'      => 'nullable|exists:proveedores,id_proveedor',
            'monto_total'       => 'required|numeric|min:0',
            'tasa_anual'        => 'required|numeric|min:0',
            'numero_abonos'     => 'required|integer|min:1',
            'periodo_pago'      => 'required|in:semanal,quincenal,mensual',
            'fecha_emision'     => 'required|date',
            'fecha_vencimiento' => 'required|date|after_or_equal:fecha_emision',
            'estado'            => 'required|in:pendiente,pagado,vencido',
            'descripcion'       => 'nullable|string',
        ]);

        $data['id_usuario'] = Auth::id();

        // 1) Crear cabecera
        $cuenta = CuentaPorPagar::create($data);

        // 2) Generar amortizaciones automáticas
        $this->generateAmortizacion($cuenta);

        return redirect()
            ->route('cuentas-por-pagar.index')
            ->with('success', 'Cuenta por pagar creada correctamente.');
    }

    public function show(CuentaPorPagar $cuentas_por_pagar)
    {
        // Cargar relaciones necesarias
        $cuenta = $cuentas_por_pagar->load([
            'detalles.caja',
            'sucursal',
            'caja',
            'proveedor',
            'usuario',
        ]);

        // Traer todas las cajas para el <select> del modal
        $cajas = Caja::all();

        return view('cuentas_por_pagar.show', compact('cuenta','cajas'));
    }

    public function edit(CuentaPorPagar $cuentas_por_pagar)
    {
        $cuenta      = $cuentas_por_pagar;
        $sucursales  = Sucursal::all();
        $cajas       = Caja::all();
        $proveedores = Proveedor::all();

        return view('cuentas_por_pagar.edit', compact('cuenta','sucursales','cajas','proveedores'));
    }

    public function update(Request $request, CuentaPorPagar $cuentas_por_pagar)
    {
        $data = $request->validate([
            'id_sucursal'       => 'required|exists:sucursales,id_sucursal',
            'id_caja'           => 'required|exists:cajas,id_caja',
            'proveedor_id'      => 'nullable|exists:proveedores,id_proveedor',
            'monto_total'       => 'required|numeric|min:0',
            'tasa_anual'        => 'required|numeric|min:0',
            'numero_abonos'     => 'required|integer|min:1',
            'periodo_pago'      => 'required|in:semanal,quincenal,mensual',
            'fecha_emision'     => 'required|date',
            'fecha_vencimiento' => 'required|date|after_or_equal:fecha_emision',
            'estado'            => 'required|in:pendiente,pagado,vencido',
            'descripcion'       => 'nullable|string',
        ]);

        $data['id_usuario'] = Auth::id();

        // 1) Actualizar cabecera
        $cuentas_por_pagar->update($data);

        // 2) Regenerar amortizaciones
        $cuentas_por_pagar->detalles()->delete();
        $this->generateAmortizacion($cuentas_por_pagar);

        return redirect()
            ->route('cuentas-por-pagar.index')
            ->with('success', 'Cuenta por pagar actualizada correctamente.');
    }

    public function destroy(CuentaPorPagar $cuentas_por_pagar)
    {
        $cuentas_por_pagar->delete();

        return redirect()
            ->route('cuentas-por-pagar.index')
            ->with('success', 'Cuenta por pagar eliminada correctamente.');
    }

    /**
     * Genera el cronograma de amortización según tasa, número de abonos y periodo.
     */
    protected function generateAmortizacion(CuentaPorPagar $cuenta)
    {
        $n       = $cuenta->numero_abonos;
        $saldo   = $cuenta->monto_total;
        $tasa    = $cuenta->tasa_anual / 100;
        $periodo = $cuenta->periodo_pago;
        $fecha   = Carbon::parse($cuenta->fecha_emision);

        $pagosPorAno = match($periodo) {
            'semanal'   => 52,
            'quincenal' => 26,
            'mensual'   => 12,
        };

        $i = $tasa / $pagosPorAno;

        if ($i == 0) {
            $M = round($saldo / $n, 2);
        } else {
            $den = pow(1 + $i, $n) - 1;
            $M   = round($saldo * ($i * pow(1 + $i, $n)) / $den, 2);
        }

        DB::transaction(function() use($n, $M, $i, &$saldo, &$fecha, $periodo, $cuenta) {
            for ($k = 1; $k <= $n; $k++) {
                $interes    = round($saldo * $i, 2);
                $amortiza   = round($M - $interes, 2);
                $nuevoSaldo = round($saldo - $amortiza, 2);

                $fecha = match($periodo) {
                    'semanal'   => $fecha->addWeek(),
                    'quincenal' => $fecha->addWeeks(2),
                    'mensual'   => $fecha->addMonth(),
                };

                CuentaPorPagarDetalle::create([
                    'cuenta_id'        => $cuenta->id_cuentas_por_pagar,
                    'numero_pago'      => $k,
                    'fecha_pago'       => $fecha->toDateString(),
                    'saldo_inicial'    => $saldo,
                    'amortizacion_cap' => $amortiza,
                    'pago_interes'     => $interes,
                    'monto_pago'       => $M,
                    'saldo_restante'   => max($nuevoSaldo, 0),
                    'estado'           => 'pendiente',
                    'caja_id'          => null,
                    'semana'           => null,
                ]);

                $saldo = $nuevoSaldo;
            }
        });
    }
}
