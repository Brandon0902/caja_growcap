<?php

namespace App\Http\Controllers;

use App\Models\Caja;
use App\Models\Cliente;
use App\Models\Retiro;
use App\Models\RetiroAhorro;
use App\Models\MovimientoCaja;
use App\Models\CategoriaGasto;
use App\Services\ProveedorResolver;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class RetiroController extends Controller
{
    /** Categorías “oficiales” para evitar typos */
    private const CAT_RETIROS_INV = 'Retiros de inversión';
    private const CAT_RETIROS_AH  = 'Retiros de ahorro';

    protected ProveedorResolver $proveedorResolver;

    public function __construct(ProveedorResolver $proveedorResolver)
    {
        $this->proveedorResolver = $proveedorResolver;
    }

    /**
     * Listado general de retiros (Inversión y Ahorro)
     */
    public function index(Request $request)
    {
        $search = trim($request->input('search', ''));
        $tab    = $request->input('tab', 'inv'); // inv | ahorro

        $tClientes = (new Cliente)->getTable();
        $tInv      = (new Retiro)->getTable();
        $tAhorro   = (new RetiroAhorro)->getTable();

        $retirosInv = Retiro::query()
            ->from("$tInv as r")
            ->leftJoin("$tClientes as c", 'c.id', '=', 'r.id_cliente')
            ->selectRaw('r.*, c.id as cliente_id, c.nombre as cliente_nombre, c.apellido as cliente_apellido, c.email as cliente_email')
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('c.nombre', 'like', "%{$search}%")
                       ->orWhere('c.apellido', 'like', "%{$search}%")
                       ->orWhere('c.email', 'like', "%{$search}%")
                       ->orWhere('r.id', 'like', "%{$search}%")
                       ->orWhere('r.tipo', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('r.fecha_solicitud')
            ->paginate(15, ['*'], 'page_inv');

        $retirosAh = RetiroAhorro::query()
            ->from("$tAhorro as a")
            ->leftJoin("$tClientes as c", 'c.id', '=', 'a.id_cliente')
            ->selectRaw('a.*, c.id as cliente_id, c.nombre as cliente_nombre, c.apellido as cliente_apellido, c.email as cliente_email')
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('c.nombre', 'like', "%{$search}%")
                       ->orWhere('c.apellido', 'like', "%{$search}%")
                       ->orWhere('c.email', 'like', "%{$search}%")
                       ->orWhere('a.id', 'like', "%{$search}%")
                       ->orWhere('a.tipo', 'like', "%{$search}%");
                });
            })
            ->orderByDesc('a.fecha_solicitud')
            ->paginate(15, ['*'], 'page_ah');

        $retirosInv->appends(['search' => $search, 'tab' => 'inv']);
        $retirosAh->appends(['search' => $search, 'tab' => 'ahorro']);

        return view('retiros.index', compact('retirosInv', 'retirosAh', 'search', 'tab'));
    }

    public function show(Cliente $cliente)
    {
        $retirosInv = Retiro::where('id_cliente', $cliente->id)->get();
        $retirosAh  = RetiroAhorro::where('id_cliente', $cliente->id)->get();

        return view('retiros.show', compact('cliente','retirosInv','retirosAh'));
    }

    /**
     * Actualiza un retiro de Inversión.
     * Si pasa a status=1 (Aprobado) crea el movimiento de caja.
     */
    public function updateInversion(Request $request, Retiro $retiro)
    {
        $data = $request->validate([
            'tipo'     => 'required|string',
            'cantidad' => 'required|numeric',
            'status'   => 'required|in:0,1,2,3',
        ]);

        $oldStatus = (int) $retiro->status;
        $newStatus = (int) $data['status'];

        $retiro->update([
            'tipo'     => $data['tipo'],
            'cantidad' => $data['cantidad'],
            'status'   => $newStatus,
        ]);

        if ($oldStatus !== 1 && $newStatus === 1) {
            $this->registrarEgresoRetiroInversion($retiro);
        }

        return back()->with('success', 'Retiro de inversión actualizado.');
    }

    /**
     * Actualiza un retiro de Ahorro.
     * Si pasa a status=1 (Aprobado) crea el movimiento de caja.
     */
    public function updateAhorro(Request $request, RetiroAhorro $retiroAhorro)
    {
        $data = $request->validate([
            'tipo'     => 'required|string',
            'cantidad' => 'required|numeric',
            'status'   => 'required|in:0,1,2,3',
        ]);

        $oldStatus = (int) $retiroAhorro->status;
        $newStatus = (int) $data['status'];

        $retiroAhorro->update([
            'tipo'     => $data['tipo'],
            'cantidad' => $data['cantidad'],
            'status'   => $newStatus,
        ]);

        if ($oldStatus !== 1 && $newStatus === 1) {
            $this->registrarEgresoRetiroAhorro($retiroAhorro);
        }

        return back()->with('success', 'Retiro de ahorro actualizado.');
    }

    /* =========================
       Helpers de movimientos
       ========================= */

    /** Egreso por Retiro de INVERSIÓN */
    protected function registrarEgresoRetiroInversion(Retiro $retiro): void
    {
        $cat = $this->getOrCreateGastoCategoria(self::CAT_RETIROS_INV);

        // Evitar duplicado POR tipo + categoría + origen
        $exists = MovimientoCaja::where('tipo_mov', 'Egreso')
            ->where('id_cat_gasto', $cat->id_cat_gasto)
            ->where('origen_id', $retiro->id)
            ->exists();
        if ($exists) return;

        $caja = $this->resolveCaja($retiro->id_caja);
        $saldos = $this->calcSaldos($caja, -1 * (float) $retiro->cantidad);

        $proveedorId = $this->proveedorResolver->ensureFromCliente($retiro->id_cliente);

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Egreso',
            'id_cat_gasto'    => $cat->id_cat_gasto,
            'id_sub_gasto'    => null,
            'id_cat_ing'      => null,
            'id_sub_ing'      => null,
            'proveedor_id'    => $proveedorId,
            'origen_id'       => $retiro->id,
            'monto'           => (float) $retiro->cantidad,
            'fecha'           => $retiro->fecha_solicitud ?? now(),
            'descripcion'     => "Retiro inversión #{$retiro->id}",
            'monto_anterior'  => $saldos['antes'],
            'monto_posterior' => $saldos['despues'],
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldos['despues']]);
    }

    /** Egreso por Retiro de AHORRO */
    protected function registrarEgresoRetiroAhorro(RetiroAhorro $retiroAhorro): void
    {
        $cat = $this->getOrCreateGastoCategoria(self::CAT_RETIROS_AH);

        // Evitar duplicado POR tipo + categoría + origen
        $exists = MovimientoCaja::where('tipo_mov', 'Egreso')
            ->where('id_cat_gasto', $cat->id_cat_gasto)
            ->where('origen_id', $retiroAhorro->id)
            ->exists();
        if ($exists) return;

        $caja   = $this->resolveCaja($retiroAhorro->id_caja);
        $saldos = $this->calcSaldos($caja, -1 * (float) $retiroAhorro->cantidad);

        $proveedorId = $this->proveedorResolver->ensureFromCliente($retiroAhorro->id_cliente);

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Egreso',
            'id_cat_gasto'    => $cat->id_cat_gasto,
            'id_sub_gasto'    => null,
            'id_cat_ing'      => null,
            'id_sub_ing'      => null,
            'proveedor_id'    => $proveedorId,
            'origen_id'       => $retiroAhorro->id,
            'monto'           => (float) $retiroAhorro->cantidad,
            'fecha'           => $retiroAhorro->fecha_solicitud ?? now(),
            'descripcion'     => "Retiro ahorro #{$retiroAhorro->id}",
            'monto_anterior'  => $saldos['antes'],
            'monto_posterior' => $saldos['despues'],
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldos['despues']]);
    }

    /* =========================
       Utilidades internas
       ========================= */

    /** Crea/recupera la categoría de gasto por nombre (evita errores si no existe). */
    private function getOrCreateGastoCategoria(string $nombre): CategoriaGasto
    {
        return CategoriaGasto::firstOrCreate(
            ['nombre' => $nombre],
            ['id_usuario' => 1] // o Auth::id() si quieres registrar al creador
        );
    }

    /** Resuelve la caja preferida; fallback: abierta -> primera */
    private function resolveCaja(?int $preferId): Caja
    {
        if ($preferId && ($caja = Caja::find($preferId))) {
            return $caja;
        }
        if ($caja = Caja::where('estado', 'abierta')->first()) {
            return $caja;
        }
        $caja = Caja::first();
        if (!$caja) {
            throw new \RuntimeException('No hay cajas registradas.');
        }
        return $caja;
    }

    /** Calcula saldo anterior/posterior dada una variación (delta) */
    private function calcSaldos(Caja $caja, float $delta): array
    {
        $ultimo = $caja->movimientos()->orderByDesc('fecha')->orderByDesc('id_mov')->first();
        $antes  = $ultimo ? $ultimo->monto_posterior : ($caja->saldo_inicial ?? 0);
        $despues = $antes + $delta;

        return ['antes' => $antes, 'despues' => $despues];
    }
}
