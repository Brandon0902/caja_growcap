<?php

namespace App\Http\Controllers;

use App\Models\Caja;
use App\Models\MovimientoCaja;
use App\Models\CuentaPorPagar;
use App\Models\CuentaPorPagarDetalle;
use Illuminate\Http\Request;

class CuentaPorPagarDetalleController extends Controller
{
    public function create(CuentaPorPagar $cuentas_por_pagar)
    {
        $cajas = Caja::all();

        return view(
            'cuentas_por_pagar.detalles.create',
            compact('cuentas_por_pagar', 'cajas')
        );
    }

    public function store(Request $request, CuentaPorPagar $cuentas_por_pagar)
    {
        $data = $request->validate([
            'numero_pago'      => 'required|integer|min:1',
            'fecha_pago'       => 'required|date',
            'saldo_inicial'    => 'required|numeric|min:0',
            'amortizacion_cap' => 'required|numeric|min:0',
            'pago_interes'     => 'required|numeric|min:0',
            'monto_pago'       => 'required|numeric|min:0',
            'saldo_restante'   => 'required|numeric|min:0',
            'estado'           => 'required|in:pendiente,pagado,vencido',
            'caja_id'          => 'nullable|exists:cajas,id_caja',
            'comentario'       => 'nullable|string|max:255',
            'semana'           => 'nullable|integer|min:1',
        ]);

        // 1) Crear el detalle
        $data['cuenta_id'] = $cuentas_por_pagar->id_cuentas_por_pagar;
        $detalle = CuentaPorPagarDetalle::create($data);

        // 2) Si lo marcó como pagado y eligió caja, descontar y registrar movimiento
        if ($data['estado'] === 'pagado' && $data['caja_id']) {
            $caja = Caja::findOrFail($data['caja_id']);

            // monto anterior (antes de restar)
            $montoAnterior = $caja->saldo_final;

            // resta en la caja
            $caja->decrement('saldo_final', $data['monto_pago']);

            // monto posterior (después de restar)
            $montoPosterior = $montoAnterior - $data['monto_pago'];

            // crear movimiento
            MovimientoCaja::create([
                'id_caja'        => $caja->id_caja,
                'tipo_mov'       => 'Egreso',  // asegúrate de usar el enum correcto
                'monto'          => $data['monto_pago'],
                'fecha'          => now(),
                'descripcion'    => "Pago abono #{$detalle->numero_pago} de cuenta {$cuentas_por_pagar->id_cuentas_por_pagar}",
                'monto_anterior' => $montoAnterior,
                'monto_posterior'=> $montoPosterior,
                'id_usuario'     => auth()->id(),
            ]);
        }

        return redirect()
            ->route('cuentas-por-pagar.show', $cuentas_por_pagar)
            ->with('success', 'Pago agregado correctamente.');
    }

    public function edit(CuentaPorPagarDetalle $detalle)
    {
        $cajas = Caja::all();

        return view(
            'cuentas_por_pagar.detalles.edit',
            compact('detalle', 'cajas')
        );
    }

    public function update(Request $request, CuentaPorPagarDetalle $detalle)
    {
        $data = $request->validate([
            'numero_pago'      => 'required|integer|min:1',
            'fecha_pago'       => 'required|date',
            'saldo_inicial'    => 'required|numeric|min:0',
            'amortizacion_cap' => 'required|numeric|min:0',
            'pago_interes'     => 'required|numeric|min:0',
            'monto_pago'       => 'required|numeric|min:0',
            'saldo_restante'   => 'required|numeric|min:0',
            'estado'           => 'required|in:pendiente,pagado,vencido',
            'caja_id'          => 'nullable|exists:cajas,id_caja',
            'comentario'       => 'nullable|string|max:255',
            'semana'           => 'nullable|integer|min:1',
        ]);

        $detalle->update($data);

        if ($data['estado'] === 'pagado' && $data['caja_id']) {
            $caja = Caja::findOrFail($data['caja_id']);

            $montoAnterior = $caja->saldo_final;
            $caja->decrement('saldo_final', $data['monto_pago']);
            $montoPosterior = $montoAnterior - $data['monto_pago'];

            MovimientoCaja::create([
                'id_caja'        => $caja->id_caja,
                'tipo_mov'       => 'Egreso',
                'monto'          => $data['monto_pago'],
                'fecha'          => now(),
                'descripcion'    => "Pago abono #{$detalle->numero_pago} de cuenta {$detalle->cuenta_id}",
                'monto_anterior' => $montoAnterior,
                'monto_posterior'=> $montoPosterior,
                'id_usuario'     => auth()->id(),
            ]);
        }

        return redirect()
            ->route('cuentas-por-pagar.show', $detalle->cuenta)
            ->with('success', 'Pago actualizado correctamente.');
    }

    public function destroy(CuentaPorPagarDetalle $detalle)
    {
        $cuenta = $detalle->cuenta;
        $detalle->delete();

        return redirect()
            ->route('cuentas-por-pagar.show', $cuenta)
            ->with('success', 'Pago eliminado correctamente.');
    }
}
