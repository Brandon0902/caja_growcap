<?php

namespace App\Http\Controllers;

use App\Models\Caja;
use App\Models\Cliente;
use App\Models\UserAbono;
use App\Models\UserPrestamo;
use App\Models\MovimientoCaja;
use App\Models\CategoriaIngreso;
use App\Services\ProveedorResolver;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserAbonoController extends Controller
{
    /** Categoría de ingreso para movimientos de abonos */
    private const CAT_ABONO_PRESTAMO = 'Abonos de préstamo';

    protected ProveedorResolver $proveedorResolver;

    public function __construct(ProveedorResolver $proveedorResolver)
    {
        $this->proveedorResolver = $proveedorResolver;
    }

    /* ===================== 1) Listado de clientes ===================== */
    public function index(Request $request)
    {
        $search = $request->input('search', '');

        $clientes = Cliente::when($search, fn ($q) =>
                            $q->where('nombre', 'like', "%{$search}%")
                              ->orWhere('apellido', 'like', "%{$search}%")
                         )
                         ->orderBy('nombre')
                         ->paginate(15)
                         ->withQueryString();

        return view('adminuserabonos.clientes.index', compact('clientes', 'search'));
    }

    /* ============== 2) Listado de préstamos por cliente ============== */
    public function showPrestamos($clienteId)
    {
        $cliente = Cliente::findOrFail($clienteId);

        $prestamos = UserPrestamo::where('id_cliente', $clienteId)
                         ->orderByDesc('fecha_inicio')
                         ->paginate(15);

        return view('adminuserabonos.prestamos.index', compact('cliente', 'prestamos'));
    }

    /* ============== 3) Listado de abonos de un préstamo ============== */
    public function showAbonos($userPrestamoId)
    {
        $prestamo = UserPrestamo::findOrFail($userPrestamoId);

        $abonos = UserAbono::where('user_prestamo_id', $prestamo->id)
                    ->orderBy('num_pago')
                    ->get();

        return view('adminuserabonos.abonos.index', compact('prestamo', 'abonos'));
    }

    /* ============== 4) Cambio rápido de status de un abono ============== */
    public function updateStatus(Request $request, $abonoId)
    {
        $data = $request->validate([
            'status' => 'required|in:0,1,2', // 0=Pendiente,1=Pagado,2=Vencido
        ]);

        $abono = UserAbono::with('userPrestamo')->findOrFail($abonoId);
        $old   = (int) $abono->status;
        $new   = (int) $data['status'];

        $abono->status = $new;
        $abono->save();

        // Sincroniza el movimiento en caja con el nuevo estado
        $this->syncMovimientoCajaAbono($abono, $old, $new);

        return back()->with('success', 'Status actualizado.');
    }

    /* ============== 5) Render del modal de edición ===================== */
    public function edit(Request $request, $abonoId)
    {
        $abono = UserAbono::findOrFail($abonoId);

        $isAjax = $request->ajax() || $request->header('X-Requested-With') === 'XMLHttpRequest';
        if (!$isAjax) {
            return redirect()
                ->route('adminuserabonos.abonos.general')
                ->with('openEditId', $abono->id);
        }

        return view('adminuserabonos.abonos.edit_modal', compact('abono'));
    }

    /* ============== 6) Guardar edición completa ======================== */
    public function update(Request $request, $abonoId)
    {
        $data = $request->validate([
            'tipo_abono'        => 'nullable|string|max:50',
            'fecha_vencimiento' => 'nullable|date',
            'num_pago'          => 'nullable|integer',
            'cantidad'          => 'nullable|numeric',
            'saldo_restante'    => 'nullable|numeric',
            'mora_generada'     => 'nullable|numeric',
            'fecha'             => 'nullable|date',
            'status'            => 'required|in:0,1,2',
        ]);

        $abono = UserAbono::with('userPrestamo')->findOrFail($abonoId);
        $old   = (int) $abono->status;

        $abono->update($data);
        $abono->refresh();

        $new = (int) $abono->status;

        // Sincroniza el movimiento en caja si cambió el estado o monto/fecha
        $this->syncMovimientoCajaAbono($abono, $old, $new, true);

        return back()->with('success', 'Abono actualizado correctamente.');
    }

    /* ============== 7) Listado general de abonos ======================= */
    public function generalIndex(Request $request)
    {
        $search = trim($request->input('search', ''));
        $status = $request->input('status');      // 0|1|2|null
        $desde  = $request->input('desde');       // Y-m-d
        $hasta  = $request->input('hasta');       // Y-m-d
        $orden  = $request->input('orden', 'recientes'); // recientes|antiguos|monto_asc|monto_desc

        $abonos = UserAbono::query()
            ->with([
                'userPrestamo:id,id_cliente',
                'userPrestamo.cliente:id,nombre,apellido,email',
            ])
            ->when($search !== '', function ($q) use ($search) {
                $q->where(function ($qq) use ($search) {
                    $qq->where('id', $search)
                       ->orWhere('user_prestamo_id', $search)
                       ->orWhere('cantidad', 'like', "%{$search}%")
                       ->orWhereHas('userPrestamo.cliente', function ($qc) use ($search) {
                           $qc->where('nombre',  'like', "%{$search}%")
                              ->orWhere('apellido','like', "%{$search}%")
                              ->orWhere('email',   'like', "%{$search}%");
                       });
                });
            })
            ->when(in_array($status, ['0','1','2'], true), fn($q) => $q->where('status', (int)$status))
            ->when($desde, fn($q) => $q->whereDate('fecha', '>=', $desde))
            ->when($hasta, fn($q) => $q->whereDate('fecha', '<=', $hasta));

        $abonos = match ($orden) {
            'antiguos'   => $abonos->orderBy('fecha', 'asc'),
            'monto_asc'  => $abonos->orderBy('cantidad', 'asc'),
            'monto_desc' => $abonos->orderBy('cantidad', 'desc'),
            default      => $abonos->orderBy('fecha', 'desc'),
        };

        $abonos = $abonos->paginate(15)->withQueryString();

        $statusOptions = [
            ''  => 'Todos',
            '0' => 'Pendiente',
            '1' => 'Pagado',
            '2' => 'Vencido',
        ];

        return view('adminuserabonos.abonos.general_index', compact(
            'abonos', 'search', 'status', 'statusOptions', 'desde', 'hasta', 'orden'
        ));
    }

    /* ===================== Helpers de movimientos ====================== */

    /**
     * Crea/actualiza o elimina el movimiento en caja para un abono,
     * según transición de estado.
     *
     * @param  UserAbono $abono  (con userPrestamo cargado)
     * @param  int $oldStatus
     * @param  int $newStatus
     * @param  bool $forceUpdate Si true, reescribe monto/fecha/desc si ya existe
     */
    protected function syncMovimientoCajaAbono(UserAbono $abono, int $oldStatus, int $newStatus, bool $forceUpdate = false): void
    {
        // Solo genera movimiento cuando el abono está PAGADO
        if ($newStatus === 1) {
            $this->registrarAbonoEnCaja($abono, $forceUpdate);
            return;
        }

        // Si estaba pagado y cambió a pendiente/vencido → elimina movimiento
        if ($oldStatus === 1 && in_array($newStatus, [0, 2], true)) {
            $this->eliminarMovimientoDeAbono($abono);
        }
    }

    /**
     * Inserta o actualiza (si $forceUpdate) el movimiento de Ingreso por abono.
     */
    protected function registrarAbonoEnCaja(UserAbono $abono, bool $forceUpdate = false): void
    {
        // 1) Categoría
        $catIng = CategoriaIngreso::firstOrCreate(
            ['nombre' => self::CAT_ABONO_PRESTAMO],
            ['id_usuario' => 1]
        );

        // 2) Caja destino
        $cajaId = $this->resolveCajaId($abono);

        // 3) ¿Existe ya el movimiento?
        $movQuery = MovimientoCaja::where('tipo_mov', 'Ingreso')
            ->where('id_cat_ing', $catIng->id_cat_ing)
            ->where('origen_id', $abono->id);

        $existe = $movQuery->exists();
        if ($existe && !$forceUpdate) {
            return; // ya registrado
        }

        // 4) Saldos
        $caja = Caja::findOrFail($cajaId);
        $last = $caja->movimientos()->orderByDesc('fecha')->orderByDesc('id_mov')->first();
        $antes = $last ? $last->monto_posterior : $caja->saldo_inicial;

        // Monto del movimiento: cantidad + (opcional) mora
        $monto = (float) $abono->cantidad + (float) ($abono->mora_generada ?? 0);
        $fecha = $abono->fecha ?: now();
        $desc  = "Abono préstamo #{$abono->user_prestamo_id} (abono #{$abono->id})";

        $despues = $antes + $monto;

        // 5) Proveedor = Cliente del préstamo
        $prestamo = $abono->relationLoaded('userPrestamo') ? $abono->userPrestamo : $abono->userPrestamo()->first();
        $proveedorId = $this->proveedorResolver->ensureFromCliente($prestamo->id_cliente);

        // 6) Insertar / actualizar movimiento
        if ($existe) {
            $mov = $movQuery->first();
            // reajustar saldos: para simplicidad, eliminamos y reinsertamos recalculando saldos
            // (si prefieres, puedes recalcular diferencialmente)
            $mov->delete();
        }

        // Recalcular "antes" por si se eliminó el previo
        $last = $caja->movimientos()->orderByDesc('fecha')->orderByDesc('id_mov')->first();
        $antes = $last ? $last->monto_posterior : $caja->saldo_inicial;
        $despues = $antes + $monto;

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Ingreso',
            'id_cat_ing'      => $catIng->id_cat_ing,
            'id_sub_ing'      => null,
            'id_cat_gasto'    => null,
            'id_sub_gasto'    => null,
            'proveedor_id'    => $proveedorId,
            'origen_id'       => $abono->id,        // <-- origen = abono
            'monto'           => $monto,
            'fecha'           => $fecha,
            'descripcion'     => $desc,
            'monto_anterior'  => $antes,
            'monto_posterior' => $despues,
            'id_usuario'      => Auth::id(),
        ]);

        // 7) Actualizar saldo final
        $caja->update(['saldo_final' => $despues]);
    }

    /**
     * Elimina el movimiento asociado a un abono (si existe) y
     * reajusta el saldo_final de la caja a partir del último movimiento.
     */
    protected function eliminarMovimientoDeAbono(UserAbono $abono): void
    {
        $catIng = CategoriaIngreso::where('nombre', self::CAT_ABONO_PRESTAMO)->first();
        if (!$catIng) return;

        $mov = MovimientoCaja::where('tipo_mov', 'Ingreso')
            ->where('id_cat_ing', $catIng->id_cat_ing)
            ->where('origen_id', $abono->id)
            ->first();

        if (!$mov) return;

        $caja = Caja::find($mov->id_caja);
        $mov->delete();

        if ($caja) {
            $ultimo = $caja->movimientos()->orderByDesc('fecha')->orderByDesc('id_mov')->first();
            $nuevoSaldoFinal = $ultimo ? $ultimo->monto_posterior : $caja->saldo_inicial;
            $caja->update(['saldo_final' => $nuevoSaldoFinal]);
        }
    }

    /**
     * Resuelve la caja destino para el abono.
     * - Si el préstamo tiene `id_caja`, lo usa.
     * - Si el abono tiene `id_caja` (si existiera en tu esquema), lo usa.
     * - Si no, toma una caja abierta; si no hay, toma cualquiera.
     */
    protected function resolveCajaId(UserAbono $abono): int
    {
        $prestamo = $abono->relationLoaded('userPrestamo') ? $abono->userPrestamo : $abono->userPrestamo()->first();
        if (!empty($prestamo->id_caja)) {
            return (int) $prestamo->id_caja;
        }

        // Si en tu esquema UserAbono tuviera columna id_caja, podrías:
        // if (!empty($abono->id_caja)) return (int) $abono->id_caja;

        return (int) (
            Caja::where('estado', 'abierta')->value('id_caja')
            ?? Caja::value('id_caja')
            ?? Caja::create([
                'nombre'        => 'Caja Principal',
                'estado'        => 'abierta',
                'saldo_inicial' => 0,
                'saldo_final'   => 0,
            ])->id_caja
        );
    }
}
