<?php

namespace App\Services;

use App\Models\Cliente;
use App\Models\Proveedor;

class ProveedorResolver
{
    /**
     * Devuelve el id_proveedor correspondiente a un cliente.
     * Si no existe, lo crea a partir de los datos del cliente.
     */
    public function ensureFromCliente(int $clienteId): int
    {
        $cli = Cliente::findOrFail($clienteId);

        $nombreCompleto = trim(($cli->nombre ?? '').' '.($cli->apellido ?? ''));
        $tel   = (string) ($cli->telefono ?? '');
        $email = $cli->email ?: null;

        // 1) Intentar localizar proveedor existente
        $prov = null;
        if ($email) {
            $prov = Proveedor::where('email', $email)->first();
        }
        if (!$prov) {
            $prov = Proveedor::where('nombre', $nombreCompleto)
                ->where('telefono', $tel)
                ->first();
        }

        // 2) Si no existe, crearlo (ajusta fillable en el modelo Proveedor)
        if (!$prov) {
            $prov = Proveedor::create([
                'nombre'    => $nombreCompleto !== '' ? $nombreCompleto : ($cli->nombre ?? 'Cliente'),
                'direccion' => null,          // ya lo dejaste NULLABLE
                'telefono'  => $tel,          // si es NOT NULL en tu schema, asegúrate de mandar al menos ''
                'email'     => $email ?? '',  // idem arriba
                'contacto'  => $nombreCompleto ?: 'Contacto',
                'estado'    => 'activo',
            ]);
        }

        return $prov->id_proveedor;
    }
}
