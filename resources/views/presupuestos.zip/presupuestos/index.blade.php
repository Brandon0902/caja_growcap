<x-app-layout>
  <x-slot name="header">
    <h2>Gestión de Presupuestos</h2>
  </x-slot>

  <div class="p-6 space-y-6">
    <form action="{{ route('presupuestos.store') }}" method="POST" class="space-y-4">
      @csrf

      {{-- Selección Mes/Año --}}
      <div class="flex gap-4">
        <div>
          <label>Mes</label>
          <select name="mes" class="border rounded px-2 py-1">
            @foreach(range(1,12) as $m)
              <option value="{{ $m }}" @selected($m==$mes)>{{ $meses[$m] ?? $m }}</option>
            @endforeach
          </select>
        </div>
        <div>
          <label>Año</label>
          <select name="año" class="border rounded px-2 py-1">
            @foreach(range(now()->year, now()->year-5) as $y)
              <option value="{{ $y }}" @selected($y==$año)>{{ $y }}</option>
            @endforeach
          </select>
        </div>
      </div>

      {{-- Inputs por Fuente --}}
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        @foreach($fuentes as $f)
          <div>
            <label class="font-medium">{{ $f }}</label>
            <input 
              type="hidden" 
              name="fuente[]" 
              value="{{ $f }}"
            />
            <input 
              type="number" 
              step="0.01"
              name="monto[]" 
              value="{{ $presupuestos[$f]->monto ?? '' }}"
              placeholder="0.00"
              class="block w-full border rounded px-2 py-1"
            />
          </div>
        @endforeach
      </div>

      <div>
        <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded">
          Guardar Presupuestos
        </button>
      </div>
    </form>
  </div>
</x-app-layout>
