<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-white leading-tight">
      {{ __('Ahorros (todos)') }}
    </h2>
  </x-slot>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{
         search: '{{ $search ?? '' }}',
         status: '{{ $status ?? '' }}',
         desde:  '{{ $desde  ?? '' }}',
         hasta:  '{{ $hasta  ?? '' }}',
         orden:  '{{ $orden  ?? 'fecha_desc' }}'
       }">
    @if(session('success'))
      <div class="mb-4 rounded-lg bg-green-100 dark:bg-green-900 p-4 text-green-800 dark:text-green-200">
        {{ session('success') }}
      </div>
    @endif

    {{-- Filtros --}}
    <div class="mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-sm">
      <input type="text" x-model="search" placeholder="{{ __('Buscar por cliente / # / nota / monto / tipo…') }}"
             class="px-2 py-1 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500
                    bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="status"
              class="px-2 py-1 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        @foreach($statusOptions as $key => $label)
          <option value="{{ $key }}" @selected((string)($status ?? '') === (string)($key ?? ''))>{{ $label }}</option>
        @endforeach
      </select>

      <input type="date" x-model="desde"
             class="px-2 py-1 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />
      <input type="date" x-model="hasta"
             class="px-2 py-1 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="orden"
              class="px-2 py-1 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="fecha_desc">{{ __('Más recientes') }}</option>
        <option value="fecha_asc">{{ __('Más antiguos') }}</option>
        <option value="monto_desc">{{ __('Monto ↓') }}</option>
        <option value="monto_asc">{{ __('Monto ↑') }}</option>
      </select>

      <button
        @click="window.location = '{{ route('user_ahorros.index') }}'
          + `?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status ?? '')}
              &desde=${encodeURIComponent(desde ?? '')}&hasta=${encodeURIComponent(hasta ?? '')}
              &orden=${encodeURIComponent(orden)}`"
        class="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-md shadow text-sm">
        {{ __('Filtrar') }}
      </button>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg">
      <div class="overflow-x-auto max-w-full">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap text-sm">
          <thead class="bg-purple-700 dark:bg-purple-900 text-xs">
            <tr>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">#</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Cliente</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Tipo</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Monto</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">% Rend.</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Rend. Gen.</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Fecha</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Status</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Caja</th>
              <th class="px-3 py-2 text-right font-medium text-white uppercase">Acciones</th>
            </tr>
          </thead>

          <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            @forelse($ahorros as $a)
              <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">{{ str_pad($a->id, 3, '0', STR_PAD_LEFT) }}</td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200 truncate max-w-[150px]" title="{{ optional($a->cliente)->email }}">
                  {{ optional($a->cliente)->nombre }} {{ optional($a->cliente)->apellido }}
                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  {{ $a->tipo ?? '—' }}
                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  ${{ number_format($a->monto_ahorro, 2) }}
                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  {{ number_format($a->rendimiento, 2) }}%
                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  ${{ number_format($a->rendimiento_generado, 2) }}
                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  {{ \Carbon\Carbon::parse($a->fecha_inicio)->format('Y-m-d') }}
                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  {{ [5=>'Depositado',6=>'Retirado'][$a->status] ?? '—' }}
                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  {{ optional($a->caja)->nombre ?? '—' }}
                </td>

                <td class="px-3 py-2 text-right">
                  <a href="{{ route('user_ahorros.show', $a->id) }}"
                     class="px-2 py-1 bg-yellow-500 hover:bg-yellow-600 text-white rounded text-xs">
                    {{ __('Ver') }}
                  </a>
                </td>
              </tr>
            @empty
              <tr>
                <td colspan="10" class="px-3 py-4 text-center text-gray-500 dark:text-gray-400 text-sm">
                  {{ __('No hay ahorros registrados.') }}
                </td>
              </tr>
            @endforelse
          </tbody>
        </table>
      </div>

      <div class="px-3 py-2 text-right bg-gray-50 dark:bg-gray-700 sm:px-4 text-sm">
        {{ $ahorros->links() }}
      </div>
    </div>
  </div>
</x-app-layout>
