<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-white leading-tight">
      {{ __('Inversiones') }}
    </h2>
  </x-slot>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{
         search: '{{ $search }}',
         status: '{{ $status }}',
         desde: '{{ $desde }}',
         hasta: '{{ $hasta }}',
         orden: '{{ $orden }}'
       }">

    @if(session('success'))
      <div class="mb-4 rounded-lg bg-green-100 dark:bg-green-900 p-4 text-green-800 dark:text-green-200">
        {{ session('success') }}
      </div>
    @endif

    {{-- Filtros --}}
    <div class="mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
      <input type="text" x-model="search" placeholder="{{ __('Buscar por cliente / # / monto…') }}"
             class="px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500
                    bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="status"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        @foreach($statusOptions as $key=>$label)
          <option value="{{ $key }}" @selected((string)($status ?? '') === (string)($key ?? ''))>{{ $label }}</option>
        @endforeach
      </select>

      <input type="date" x-model="desde"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />
      <input type="date" x-model="hasta"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="orden"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="fecha_inicio_desc">{{ __('Más recientes') }}</option>
        <option value="fecha_inicio_asc">{{ __('Más antiguas') }}</option>
        <option value="monto_desc">{{ __('Monto ↓') }}</option>
        <option value="monto_asc">{{ __('Monto ↑') }}</option>
      </select>

      <button
        @click="window.location = '{{ route('user_inversiones.index') }}'
          + `?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status ?? '')}
              &desde=${encodeURIComponent(desde ?? '')}&hasta=${encodeURIComponent(hasta ?? '')}
              &orden=${encodeURIComponent(orden)}`"
        class="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-md shadow">
        {{ __('Filtrar') }}
      </button>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg">
      <div class="overflow-x-auto">
        <table class="table-auto min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
          <thead class="bg-purple-700 dark:bg-purple-900">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">#</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Cliente</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Plan</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Interés</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Monto</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Fecha inicio</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Estatus</th>
              <th class="px-6 py-3 text-right text-xs font-medium text-white uppercase">Acciones</th>
            </tr>
          </thead>
          <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            @forelse($inversiones as $inv)
              <tr>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  {{ str_pad($inv->id, 3, '0', STR_PAD_LEFT) }}
                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  {{ optional($inv->cliente)->nombre }} {{ optional($inv->cliente)->apellido }}
                  <div class="text-xs text-gray-500 dark:text-gray-400">
                    {{ optional($inv->cliente)->email }}
                  </div>
                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  {{ optional($inv->plan)->periodo }} {{ __('meses') }}
                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  {{ number_format($inv->interes, 2) }}%
                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">${{ number_format($inv->cantidad, 2) }}</td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  {{ \Carbon\Carbon::parse($inv->fecha_inicio)->format('Y-m-d') }}
                </td>
                <td class="px-6 py-4">
                  @php
                    $badgeClasses = [
                      1 => 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
                      2 => 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
                      3 => 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
                      4 => 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
                      5 => 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
                      6 => 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200',
                    ];
                  @endphp
                  <span class="px-2 py-1 rounded text-xs font-semibold {{ $badgeClasses[$inv->status] ?? 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200' }}">
                    {{ [1=>'Autorizada',2=>'Pendiente',3=>'En revisión',4=>'Rechazada',5=>'Invertida',6=>'Finalizada'][$inv->status] ?? '—' }}
                  </span>
                </td>
                <td class="px-6 py-4 text-right">
                  <a href="{{ route('user_inversiones.show', $inv) }}"
                     class="inline-flex items-center px-3 py-2 bg-yellow-500 hover:bg-yellow-600
                            text-white text-sm font-medium rounded-md shadow-sm focus:outline-none
                            focus:ring-2 focus:ring-offset-2 focus:ring-yellow-400">
                    {{ __('Ver') }}
                  </a>
                  <a href="{{ route('user_inversiones.edit', $inv) }}"
                     class="inline-flex items-center px-3 py-2 bg-indigo-600 hover:bg-indigo-700
                            text-white text-sm font-medium rounded-md shadow-sm focus:outline-none
                            focus:ring-2 focus:ring-offset-2 focus:ring-indigo-400 ml-2">
                    {{ __('Editar') }}
                  </a>
                </td>
              </tr>
            @empty
              <tr>
                <td colspan="8" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                  {{ __('No hay inversiones registradas.') }}
                </td>
              </tr>
            @endforelse
          </tbody>
        </table>
      </div>

      <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right sm:px-6">
        {{ $inversiones->links() }}
      </div>
    </div>
  </div>
</x-app-layout>
