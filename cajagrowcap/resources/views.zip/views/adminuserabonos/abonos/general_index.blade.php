<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-white leading-tight">
      {{ __('Abonos (Todos)') }}
    </h2>
  </x-slot>

  {{-- Oculta hasta que Alpine monte --}}
  <style>[x-cloak]{ display:none !important; }</style>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="page()"
       x-init="onLoad({{ json_encode(session('openEditId')) }})">

    {{-- ===== Filtros ===== --}}
    <div class="mb-4 grid grid-cols-1 md:grid-cols-6 gap-3">
      <input type="text" x-model="search"
             placeholder="{{ __('Buscar por cliente/email/ID/importe…') }}"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"/>

      <select x-model="status"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        @foreach($statusOptions as $v => $label)
          <option value="{{ $v }}" @selected((string)$status === (string)$v)>{{ $label }}</option>
        @endforeach
      </select>

      <input type="date" x-model="desde"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"/>
      <input type="date" x-model="hasta"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"/>

      <select x-model="orden"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="recientes">{{ __('Más recientes') }}</option>
        <option value="antiguos">{{ __('Más antiguos') }}</option>
        <option value="monto_desc">{{ __('Monto ↓') }}</option>
        <option value="monto_asc">{{ __('Monto ↑') }}</option>
      </select>

      <button
        @click="aplicarFiltros()"
        class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md">
        {{ __('Filtrar') }}
      </button>
    </div>

    {{-- ===== Tabla ===== --}}
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 table-auto whitespace-nowrap">
        <thead class="bg-green-700 dark:bg-green-900">
          <tr>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">#</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('Cliente') }}</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('Préstamo') }}</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('# Pago') }}</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('Cantidad') }}</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('Fecha') }}</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('Vence') }}</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('Mora') }}</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('Saldo') }}</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">{{ __('Status') }}</th>
            <th class="px-4 py-3 text-right text-xs font-medium text-white uppercase">{{ __('Acciones') }}</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          @forelse($abonos as $a)
            @php
              // Relación correcta: userPrestamo -> cliente
              $cliente = optional(optional($a->userPrestamo)->cliente);
            @endphp
            <tr>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">{{ $a->id }}</td>

              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">
                {{ $cliente?->nombre }} {{ $cliente?->apellido }}
                <div class="text-xs text-gray-500 dark:text-gray-400">{{ $cliente?->email }}</div>
              </td>

              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">#{{ $a->user_prestamo_id }}</td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">{{ $a->num_pago }}</td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">${{ number_format((float)$a->cantidad, 2) }}</td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">{{ optional($a->fecha)->format('Y-m-d') }}</td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">{{ optional($a->fecha_vencimiento)->format('Y-m-d') }}</td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">${{ number_format((float)$a->mora_generada, 2) }}</td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">${{ number_format((float)$a->saldo_restante, 2) }}</td>

              <td class="px-4 py-3">
                <form action="{{ route('adminuserabonos.abonos.updateStatus', $a->id) }}" method="POST">
                  @csrf
                  <select name="status" onchange="this.form.submit()"
                          class="border-gray-300 rounded dark:bg-gray-700 dark:text-gray-200">
                    <option value="0" @selected($a->status==0)>Pendiente</option>
                    <option value="1" @selected($a->status==1)>Pagado</option>
                    <option value="2" @selected($a->status==2)>Vencido</option>
                  </select>
                </form>
              </td>

              <td class="px-4 py-3 text-right">
                {{-- Evita navegación y abre modal por AJAX (href queda como fallback) --}}
                <a href="{{ route('adminuserabonos.abonos.edit', $a->id) }}"
                   @click.prevent="openEdit({{ $a->id }})"
                   class="inline-flex items-center px-3 py-2 bg-indigo-500 hover:bg-indigo-600 text-white text-sm rounded-md">
                  {{ __('Editar') }}
                </a>
              </td>
            </tr>
          @empty
            <tr>
              <td colspan="11" class="px-4 py-6 text-center text-gray-500 dark:text-gray-400">
                {{ __('No se encontraron abonos.') }}
              </td>
            </tr>
          @endforelse
        </tbody>
      </table>

      <div class="px-4 py-3 bg-gray-50 dark:bg-gray-700 text-right">
        {{ $abonos->links() }}
      </div>
    </div>

    {{-- ===== Modal de edición (con scroll interno) ===== --}}
    <div x-cloak x-show="showEdit" x-transition.opacity
         class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
         @keydown.escape.window="closeModal()">
      <div class="w-full max-w-3xl bg-white dark:bg-gray-800 rounded-2xl shadow-2xl overflow-hidden relative flex flex-col">
        <button @click="closeModal()"
                class="absolute top-3 right-3 inline-flex items-center justify-center w-9 h-9 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                aria-label="Cerrar">✕</button>

        <div class="p-6 max-h-[80vh] overflow-y-auto" x-html="editHtml"></div>
      </div>
    </div>

  </div>

  {{-- ===== Alpine state/logic ===== --}}
  <script>
    function page() {
      return {
        // Estado de filtros desde servidor
        search: @json($search ?? ''),
        status: @json((string)($status ?? '')),
        desde:  @json($desde ?? ''),
        hasta:  @json($hasta ?? ''),
        orden:  @json($orden ?? 'recientes'),

        // Estado modal
        showEdit: false,
        editHtml: '',

        aplicarFiltros() {
          const base = @json(route('adminuserabonos.abonos.general'));
          const qs = new URLSearchParams({
            search: this.search ?? '',
            status: this.status ?? '',
            desde:  this.desde  ?? '',
            hasta:  this.hasta  ?? '',
            orden:  this.orden  ?? 'recientes',
          }).toString();
          window.location = `${base}?${qs}`;
        },

        async openEdit(id) {
          try {
            const url = @json(route('adminuserabonos.abonos.edit', '__ID__')).replace('__ID__', id);
            const res = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }});
            if (!res.ok) throw new Error('HTTP ' + res.status);
            this.editHtml = await res.text();
            this.showEdit = true;
          } catch (err) {
            console.error(err);
            alert('No se pudo cargar el formulario de edición.');
          }
        },

        closeModal() {
          this.showEdit = false;
          this.editHtml = '';
        },

        onLoad(openId) {
          // Si venimos de /edit por navegación directa, abre aquí automáticamente
          if (openId) {
            this.openEdit(openId);
          }
        }
      }
    }
  </script>
</x-app-layout>
