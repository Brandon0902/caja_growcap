{{-- resources/views/contabilidad/index.blade.php --}}
<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200">
      {{ __('Contabilidad Profunda') }}
    </h2>
  </x-slot>

  <div class="px-4 py-6 space-y-6">

    {{-- KPI Cards: presupuesto vs gasto por fuente --}}
    @isset($movs)
      <div class="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-6 gap-4 mb-6">
        @foreach($fuentes as $f)
          @php
            $gasto = $movs->where('fuente', $f)
                          ->sum(fn($m) => $m->tipo === 'egreso' ? $m->monto : 0);
            $pres = $presupuestos->has($f)
                  ? $presupuestos[$f]->monto
                  : 0;
            $pct = $pres > 0 ? min(100, round($gasto * 100 / $pres)) : null;
          @endphp

          <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-lg">
            <h3 class="text-sm font-medium text-gray-500 dark:text-gray-300">{{ $f }}</h3>
            <div class="mt-2 text-xl font-bold text-red-600 dark:text-red-400">
              {{ number_format($gasto, 2) }}
            </div>
            <div class="text-xs text-gray-500 dark:text-gray-400">
              / {{ number_format($pres, 2) }} presupuestado
            </div>
            @if(!is_null($pct))
              <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-2 overflow-hidden">
                <div class="h-2 {{ $pct >= 100 ? 'bg-red-500' : 'bg-green-500' }}"
                     style="width: {{ $pct }}%"></div>
              </div>
              <div class="text-xs text-gray-500 dark:text-gray-400 mt-1">
                {{ $pct }}% usado
              </div>
            @endif
          </div>
        @endforeach
      </div>
    @endisset

    {{-- Formulario de filtros (sin filtro de cliente) --}}
    <form
      action="{{ route('contabilidad.filtrar') }}"
      method="GET"
      class="flex flex-wrap gap-4 items-end"
    >
      {{-- Mes --}}
      <div>
        <label for="mes" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Mes</label>
        <select id="mes" name="mes" class="block border rounded px-2 py-1">
          @foreach($meses as $n => $nombre)
            <option value="{{ $n }}" @selected(isset($mes) && $mes == $n)>{{ $nombre }}</option>
          @endforeach
        </select>
      </div>

      {{-- Año --}}
      <div>
        <label for="año" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Año</label>
        <select id="año" name="año" class="block border rounded px-2 py-1">
          @foreach($años as $y)
            <option value="{{ $y }}" @selected(isset($año) && $año == $y)>{{ $y }}</option>
          @endforeach
        </select>
      </div>

      {{-- Tipo --}}
      <div>
        <label for="tipo" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Tipo</label>
        <select id="tipo" name="tipo" class="block border rounded px-2 py-1">
          <option value="">— Ambos —</option>
          <option value="ingreso" @selected(isset($tipo) && $tipo == 'ingreso')>Ingresos</option>
          <option value="egreso"  @selected(isset($tipo) && $tipo == 'egreso')>Egresos</option>
        </select>
      </div>

      {{-- Fuente --}}
      <div>
        <label for="fuente" class="block text-sm font-medium text-gray-700 dark:text-gray-300">Operación</label>
        <select id="fuente" name="fuente" class="block border rounded px-2 py-1">
          <option value="">— Todas —</option>
          @foreach($fuentes as $f)
            <option value="{{ $f }}" @selected(isset($fuente) && $fuente === $f)>{{ $f }}</option>
          @endforeach
        </select>
      </div>

      {{-- Botón Filtrar --}}
      <div>
        <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
          Filtrar
        </button>
      </div>
    </form>

    {{-- Tabla de resultados --}}
    @isset($movs)
      <div class="overflow-x-auto bg-white dark:bg-gray-800 shadow sm:rounded-lg p-4">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead class="bg-gray-50 dark:bg-gray-700">
            <tr>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Fecha</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Fuente</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Cliente</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Descripción</th>
              <th class="px-4 py-2 text-right text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Monto</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-500 dark:text-gray-300 uppercase">Tipo</th>
            </tr>
          </thead>
          <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            @foreach($movs as $m)
              <tr class="@if($m->tipo == 'egreso') bg-red-50 dark:bg-red-900 @else bg-green-50 dark:bg-green-900 @endif">
                <td class="px-4 py-2 whitespace-nowrap">{{ \Carbon\Carbon::parse($m->fecha)->format('d-m-Y') }}</td>
                <td class="px-4 py-2 whitespace-nowrap">{{ $m->fuente }}</td>
                <td class="px-4 py-2 whitespace-nowrap">{{ $m->cliente ? $m->cliente->nombre : '—' }}</td>
                <td class="px-4 py-2">{{ $m->descripcion }}</td>
                <td class="px-4 py-2 text-right whitespace-nowrap">{{ number_format($m->monto, 2) }}</td>
                <td class="px-4 py-2 capitalize whitespace-nowrap">{{ $m->tipo }}</td>
              </tr>
            @endforeach
          </tbody>
          <tfoot class="bg-gray-50 dark:bg-gray-700">
            <tr class="font-semibold">
              <td colspan="4" class="px-4 py-2 text-right">
                Total {{ $tipo ?: 'General' }} {{ $fuente ? "({$fuente})" : '' }}:
              </td>
              <td class="px-4 py-2 text-right">{{ number_format($total, 2) }}</td>
              <td></td>
            </tr>
          </tfoot>
        </table>
      </div>
    @endisset

  </div>
</x-app-layout>
