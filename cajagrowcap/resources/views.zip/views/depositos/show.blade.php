<x-app-layout>
  <x-slot name="header">
    <div class="flex items-center justify-between">
      <h2 class="font-semibold text-xl text-white leading-tight">
        {{ __('Depósito #') }}{{ str_pad($deposito->id, 3, '0', STR_PAD_LEFT) }}
      </h2>
      <a href="{{ route('depositos.index') }}"
         class="inline-flex items-center px-3 py-2 bg-gray-500 hover:bg-gray-600
                text-white text-sm font-medium rounded-md shadow-sm">
        {{ __('← Volver al listado') }}
      </a>
    </div>
  </x-slot>

  <div class="py-6 mx-auto max-w-4xl px-4 sm:px-6 lg:px-8">
    @if(session('success'))
      <div class="mb-4 rounded-lg bg-green-100 dark:bg-green-900 p-4 text-green-800 dark:text-green-200">
        {{ session('success') }}
      </div>
    @endif
    @if ($errors->any())
      <div class="mb-4 rounded-lg border border-red-200 bg-red-50 p-4 text-red-700 dark:border-red-800 dark:bg-red-900/40 dark:text-red-200">
        <div class="font-semibold mb-1">{{ __('Hay errores en el formulario:') }}</div>
        <ul class="list-disc ml-5 text-sm">
          @foreach ($errors->all() as $error)
            <li>{{ $error }}</li>
          @endforeach
        </ul>
      </div>
    @endif

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-6">
      <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div>
          <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400">{{ __('Cliente') }}</h3>
          <p class="text-base text-gray-800 dark:text-gray-100">
            {{ optional($deposito->cliente)->nombre }} {{ optional($deposito->cliente)->apellido }}
          </p>
          <p class="text-xs text-gray-500 dark:text-gray-400">{{ optional($deposito->cliente)->email }}</p>
        </div>

        <div>
          <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400">{{ __('Monto') }}</h3>
          <p class="text-base text-gray-800 dark:text-gray-100">${{ number_format($deposito->cantidad,2) }}</p>
        </div>

        <div>
          <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400">{{ __('Fecha de depósito') }}</h3>
          <p class="text-base text-gray-800 dark:text-gray-100">{{ \Carbon\Carbon::parse($deposito->fecha_deposito)->format('Y-m-d') }}</p>
        </div>

        <div>
          <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400">{{ __('Caja asociada') }}</h3>
          <p class="text-base text-gray-800 dark:text-gray-100">{{ optional($deposito->caja)->nombre ?? '—' }}</p>
        </div>

        <div class="md:col-span-2">
          <h3 class="text-sm font-semibold text-gray-500 dark:text-gray-400">{{ __('Nota') }}</h3>
          <p class="text-base text-gray-800 dark:text-gray-100">{{ $deposito->nota ?: '—' }}</p>
        </div>
      </div>

      <hr class="border-gray-200 dark:border-gray-700">

      {{-- Actualizar status (igual que tu controlador) --}}
      <form method="POST" action="{{ route('depositos.update', $deposito) }}" class="grid grid-cols-1 md:grid-cols-3 gap-4">
        @csrf
        @method('PATCH')

        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            {{ __('Status') }}
          </label>
          <select name="status"
                  class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600
                         bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm
                         focus:border-green-500 focus:ring-green-500">
            @foreach($statusOptions as $value => $label)
              <option value="{{ $value }}" @selected(old('status', $deposito->status) == $value)>{{ $label }}</option>
            @endforeach
          </select>
        </div>

        <div class="md:col-span-2">
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            {{ __('Nota (opcional)') }}
          </label>
          <input type="text" name="nota" value="{{ old('nota', $deposito->nota) }}"
                 class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600
                        bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm
                        focus:border-green-500 focus:ring-green-500" />
        </div>

        <div class="md:col-span-3 flex justify-end">
          <button type="submit"
                  class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md">
            {{ __('Guardar cambios') }}
          </button>
        </div>
      </form>
    </div>
  </div>
</x-app-layout>
