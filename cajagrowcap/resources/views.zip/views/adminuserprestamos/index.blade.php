<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-white leading-tight">
      {{ __('Préstamos (todos)') }}
    </h2>
  </x-slot>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{
         search: '{{ $search ?? '' }}',
         status: '{{ $status ?? '' }}',
         desde:  '{{ $desde  ?? '' }}',
         hasta:  '{{ $hasta  ?? '' }}',
         orden:  '{{ $orden  ?? 'fecha_desc' }}'
       }">

    @if(session('success'))
      <div class="mb-4 rounded bg-green-100 p-3 text-green-800 dark:bg-green-900 dark:text-green-200">
        {{ session('success') }}
      </div>
    @endif

    {{-- Filtros --}}
    <div class="mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
      <input type="text" x-model="search" placeholder="{{ __('Buscar cliente / # / monto…') }}"
             class="px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500
                    bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="status"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        @foreach($statusOptions as $key => $label)
          <option value="{{ $key }}" @selected((string)($status ?? '') === (string)($key ?? ''))>{{ $label }}</option>
        @endforeach
      </select>

      <input type="date" x-model="desde"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />
      <input type="date" x-model="hasta"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="orden"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="fecha_desc">{{ __('Más recientes') }}</option>
        <option value="fecha_asc">{{ __('Más antiguos') }}</option>
        <option value="monto_desc">{{ __('Monto ↓') }}</option>
        <option value="monto_asc">{{ __('Monto ↑') }}</option>
      </select>

      <button
        @click="window.location = '{{ route('user_prestamos.index') }}'
          + `?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status ?? '')}
              &desde=${encodeURIComponent(desde ?? '')}&hasta=${encodeURIComponent(hasta ?? '')}
              &orden=${encodeURIComponent(orden)}`"
        class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md shadow">
        {{ __('Filtrar') }}
      </button>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
        <thead class="bg-green-700 dark:bg-green-900">
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">#</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Cliente</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Tipo</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Monto</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">% Interés</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Int. generado</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Inicio</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Status</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Caja</th>
            <th class="px-6 py-3 text-right text-xs font-medium text-white uppercase">Acciones</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          @forelse($prestamos as $p)
            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">{{ str_pad($p->id, 3, '0', STR_PAD_LEFT) }}</td>

              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                {{ optional($p->cliente)->nombre }} {{ optional($p->cliente)->apellido }}
                <div class="text-xs text-gray-500 dark:text-gray-400">{{ optional($p->cliente)->email }}</div>
              </td>

              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">{{ $p->tipo_prestamo }}</td>

              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">${{ number_format($p->cantidad,2) }}</td>

              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">{{ number_format($p->interes,2) }}%</td>

              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">${{ number_format($p->interes_generado,2) }}</td>

              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                {{ \Carbon\Carbon::parse($p->fecha_inicio)->format('Y-m-d') }}
              </td>

              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                {{ [1=>'Autorizado',2=>'Pendiente',3=>'En revisión',4=>'Rechazado',5=>'Pagado',6=>'Terminado'][$p->status] ?? '—' }}
              </td>

              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">{{ optional($p->caja)->nombre ?? '—' }}</td>

              <td class="px-6 py-4 text-right">
                <a href="{{ route('user_prestamos.show', $p) }}"
                   class="inline-flex items-center px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md">
                  {{ __('Ver') }}
                </a>
              </td>
            </tr>
          @empty
            <tr>
              <td colspan="10" class="px-6 py-6 text-center text-gray-500 dark:text-gray-400">
                {{ __('No hay préstamos registrados.') }}
              </td>
            </tr>
          @endforelse
        </tbody>
      </table>

      <div class="px-4 py-3 text-right bg-gray-50 dark:bg-gray-700 sm:px-6">
        {{ $prestamos->links() }}
      </div>
    </div>
  </div>
</x-app-layout>
