<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-white leading-tight">
      {{ __('Editar Gasto') }}
    </h2>
  </x-slot>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    <x-validation-errors class="mb-4" />

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
      <form action="{{ route('gastos.update', $gasto) }}" method="POST">
        @csrf @method('PUT')

        {{-- TIPO --}}
        <div class="mb-4">
          <x-label for="tipo" value="Tipo" />
          <x-input id="tipo"
                   name="tipo"
                   type="text"
                   :value="old('tipo', $gasto->tipo)"
                   required
                   autofocus />
        </div>

        {{-- CAJA ORIGEN --}}
        <div class="mb-4">
          <x-label for="caja_id" value="Caja Origen" />
          <select id="caja_id"
                  name="caja_id"
                  class="mt-1 block w-full border rounded px-3 py-2
                         bg-white dark:bg-gray-700 dark:text-gray-200
                         focus:outline-none focus:ring-2 focus:ring-purple-500">
            <option value="">{{ __('— Seleccionar caja —') }}</option>
            @foreach($cajas as $c)
              <option value="{{ $c->id_caja }}"
                {{ old('caja_id', $gasto->caja_id) == $c->id_caja ? 'selected' : '' }}>
                {{ $c->nombre }} ({{ optional($c->sucursal)->nombre }})
              </option>
            @endforeach
          </select>
          @error('caja_id')<p class="text-red-600">{{ $message }}</p>@enderror
        </div>

        {{-- CAJA DESTINO --}}
        <div class="mb-4">
          <x-label for="destino_caja_id" value="Caja Destino (opcional)" />
          <select id="destino_caja_id"
                  name="destino_caja_id"
                  class="mt-1 block w-full border rounded px-3 py-2
                         bg-white dark:bg-gray-700 dark:text-gray-200
                         focus:outline-none focus:ring-2 focus:ring-purple-500">
            <option value="">{{ __('— Ninguna —') }}</option>
            @foreach($cajas as $c)
              <option value="{{ $c->id_caja }}"
                {{ old('destino_caja_id', $gasto->destino_caja_id) == $c->id_caja ? 'selected' : '' }}>
                {{ $c->nombre }} ({{ optional($c->sucursal)->nombre }})
              </option>
            @endforeach
          </select>
          @error('destino_caja_id')<p class="text-red-600">{{ $message }}</p>@enderror
        </div>

        {{-- CANTIDAD --}}
        <div class="mb-4">
          <x-label for="cantidad" value="Cantidad" />
          <x-input id="cantidad"
                   name="cantidad"
                   type="number"
                   step="0.01"
                   :value="old('cantidad', $gasto->cantidad)"
                   required />
        </div>

        {{-- CONCEPTO --}}
        <div class="mb-6">
          <x-label for="concepto" value="Concepto" />
          <textarea id="concepto"
                    name="concepto"
                    rows="3"
                    class="mt-1 block w-full border rounded px-3 py-2
                           bg-white dark:bg-gray-700 dark:text-gray-200
                           focus:outline-none focus:ring-2 focus:ring-purple-500">{{ old('concepto', $gasto->concepto) }}</textarea>
        </div>

        {{-- BOTONES --}}
        <div class="flex justify-end space-x-3">
          <a href="{{ route('gastos.index') }}"
             class="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md
                    text-gray-700 bg-white hover:bg-gray-100 focus:outline-none
                    focus:ring-2 focus:ring-offset-2 focus:ring-gray-300
                    dark:border-gray-600 dark:text-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 dark:focus:ring-gray-500">
            {{ __('Cancelar') }}
          </a>

          <x-button type="submit">
            {{ __('Actualizar gasto') }}
          </x-button>
        </div>
      </form>
    </div>
  </div>
</x-app-layout>
