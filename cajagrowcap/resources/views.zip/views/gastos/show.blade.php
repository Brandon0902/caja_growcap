<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-white leading-tight">
      {{ __('Ver Gasto') }}
    </h2>
  </x-slot>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 space-y-4">

      {{-- Tipo --}}
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Tipo</h3>
        <p class="text-gray-700 dark:text-gray-300">{{ $gasto->tipo }}</p>
      </div>

      {{-- Caja Origen --}}
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Caja Origen</h3>
        <p class="text-gray-700 dark:text-gray-300">
          {{ optional($gasto->cajaOrigen)->nombre ?? '-' }}
        </p>
      </div>

      {{-- Caja Destino --}}
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Caja Destino</h3>
        <p class="text-gray-700 dark:text-gray-300">
          {{ optional($gasto->cajaDestino)->nombre ?? '-' }}
        </p>
      </div>

      {{-- Cantidad --}}
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Cantidad</h3>
        <p class="text-gray-700 dark:text-gray-300">
          {{ number_format($gasto->cantidad, 2) }}
        </p>
      </div>

      {{-- Concepto --}}
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Concepto</h3>
        <p class="text-gray-700 dark:text-gray-300">{{ $gasto->concepto }}</p>
      </div>

      {{-- Volver --}}
      <div class="flex justify-end">
        <a href="{{ route('gastos.index') }}"
           class="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded">
          {{ __('Volver') }}
        </a>
      </div>

    </div>
  </div>
</x-app-layout>
