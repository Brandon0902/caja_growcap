{{-- resources/views/sucursales/index.blade.php --}}
<x-app-layout>
    <x-slot name="header">
        <div class="flex items-center justify-between">
            <h2 class="font-semibold text-xl text-white leading-tight">
                {{ __('Sucursales') }}
            </h2>
            <a href="{{ route('sucursales.create') }}"
               class="inline-flex items-center px-4 py-2 bg-purple-600 hover:bg-purple-700
                      text-white text-sm font-medium rounded-md shadow-sm focus:outline-none
                      focus:ring-2 focus:ring-offset-2 focus:ring-purple-500">
                {{ __('Nueva Sucursal') }}
            </a>
        </div>
    </x-slot>

    <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        @if(session('success'))
            <div class="mb-4 rounded-lg bg-green-100 p-4 text-green-800 dark:bg-green-900 dark:text-green-200">
                {{ session('success') }}
            </div>
        @endif

        {{-- Filtro y buscador --}}
        <div class="mb-4 flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
            <form method="GET" action="{{ route('sucursales.index') }}" class="flex w-full sm:w-auto">
                <x-input name="search" type="text" placeholder="Buscar sucursal…"
                         value="{{ request('search') }}"
                         class="flex-1"/>
                <x-button type="submit" class="ml-2">
                    {{ __('Buscar') }}
                </x-button>
            </form>
        </div>

        {{-- Tabla de Sucursales --}}
        <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
                <thead class="bg-gray-50 dark:bg-gray-700">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-200 uppercase tracking-wider">Nombre</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-200 uppercase tracking-wider">Dirección</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-200 uppercase tracking-wider">Teléfono</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-200 uppercase tracking-wider">Gerente</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-200 uppercase tracking-wider">Acceso Activo</th>
                        <th class="px-6 py-3"></th>
                    </tr>
                </thead>
                <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
                    @forelse($sucursales as $sucursal)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-200">{{ $sucursal->nombre }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-200">{{ $sucursal->direccion }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-200">{{ $sucursal->telefono }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-700 dark:text-gray-200">{{ optional($sucursal->gerente)->name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm">
                                @if($sucursal->acceso_activo)
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">Sí</span>
                                @else
                                    <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200">No</span>
                                @endif
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                                <a href="{{ route('sucursales.edit', $sucursal) }}" class="text-indigo-600 hover:text-indigo-900">{{ __('Editar') }}</a>
                                <form action="{{ route('sucursales.destroy', $sucursal) }}" method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-600 hover:text-red-900" onclick="return confirm('¿Eliminar sucursal?');">{{ __('Eliminar') }}</button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="6" class="px-6 py-4 text-center text-sm text-gray-500 dark:text-gray-400">
                                {{ __('No hay sucursales registradas.') }}
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <div class="mt-4">
            {{ $sucursales->links() }}
        </div>
    </div>
</x-app-layout>
