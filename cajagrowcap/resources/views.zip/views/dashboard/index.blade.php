<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
      {{ __('Dashboard') }}
    </h2>
  </x-slot>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-6">

    {{-- ===========================
         Filtros estilo slicer
       =========================== --}}
    @php
      $monthsList = [
        'enero'=>1,'febrero'=>2,'marzo'=>3,'abril'=>4,'mayo'=>5,'junio'=>6,
        'julio'=>7,'agosto'=>8,'septiembre'=>9,'octubre'=>10,'noviembre'=>11,'diciembre'=>12
      ];

      // lee de la query para preseleccionar
      $startYear   = (int) request('start_year', $year);
      $startMonths = collect((array) request('start_months', []))->map(fn($m)=>(int)$m)->all();

      $endYear     = (int) request('end_year', $year);
      $endMonths   = collect((array) request('end_months', []))->map(fn($m)=>(int)$m)->all();

      $invStatus   = request('inv_status', 'todos'); // 'todos' | '1' | '0'
    @endphp

    <form method="GET" class="grid grid-cols-1 lg:grid-cols-12 gap-4 bg-white dark:bg-gray-800 p-4 rounded-xl shadow">

      {{-- Periodo global (alimenta KPIs y gráficas actuales) --}}
      <div class="lg:col-span-3">
        <label class="block text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400 mb-1">
          Periodo global
        </label>
        <div class="grid grid-cols-2 gap-2">
          <select name="year" class="rounded-md dark:bg-gray-900">
            @for($y = now()->year; $y >= now()->year-5; $y--)
              <option value="{{ $y }}" @selected($y==$year)>{{ $y }}</option>
            @endfor
          </select>
          <select name="months[]" multiple class="rounded-md dark:bg-gray-900">
            @foreach($monthsList as $n=>$v)
              <option value="{{ $v }}" @selected(in_array($v, $months ?? []))>{{ ucfirst($n) }}</option>
            @endforeach
          </select>
        </div>
        <p class="text-[11px] text-gray-500 mt-1">Tip: Ctrl/⌘ para multiselección</p>
      </div>

      {{-- Filtro Inicial — Inicio de inversión --}}
      <div class="lg:col-span-4">
        <label class="block text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400 mb-1">
          Filtro Inicial — Inicio de inversión
        </label>
        <div class="grid grid-cols-3 gap-2">
          <select name="start_year" class="col-span-1 rounded-md dark:bg-gray-900">
            @for($y = now()->year; $y >= now()->year-5; $y--)
              <option value="{{ $y }}" @selected($y==$startYear)>{{ $y }}</option>
            @endfor
          </select>
          <div class="col-span-2 flex flex-wrap gap-2">
            @foreach($monthsList as $label=>$val)
              <label class="inline-flex items-center">
                <input type="checkbox" name="start_months[]"
                       class="rounded border-gray-300 dark:bg-gray-900"
                       value="{{ $val }}" {{ in_array($val, $startMonths) ? 'checked' : '' }}>
                <span class="ml-1 text-sm">{{ substr(ucfirst($label),0,3) }}</span>
              </label>
            @endforeach
          </div>
        </div>
      </div>

      {{-- Filtro Final — Fin de inversión --}}
      <div class="lg:col-span-4">
        <label class="block text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400 mb-1">
          Filtro Final — Fin de inversión
        </label>
        <div class="grid grid-cols-3 gap-2">
          <select name="end_year" class="col-span-1 rounded-md dark:bg-gray-900">
            @for($y = now()->year; $y >= now()->year-5; $y--)
              <option value="{{ $y }}" @selected($y==$endYear)>{{ $y }}</option>
            @endfor
          </select>
          <div class="col-span-2 flex flex-wrap gap-2">
            @foreach($monthsList as $label=>$val)
              <label class="inline-flex items-center">
                <input type="checkbox" name="end_months[]"
                       class="rounded border-gray-300 dark:bg-gray-900"
                       value="{{ $val }}" {{ in_array($val, $endMonths) ? 'checked' : '' }}>
                <span class="ml-1 text-sm">{{ substr(ucfirst($label),0,3) }}</span>
              </label>
            @endforeach
          </div>
        </div>
      </div>

      {{-- Status de inversión --}}
      <div class="lg:col-span-1">
        <label class="block text-xs uppercase tracking-wide text-gray-500 dark:text-gray-400 mb-1">
          Status
        </label>
        <select name="inv_status" class="w-full rounded-md dark:bg-gray-900">
          <option value="todos" @selected($invStatus==='todos')>Todos</option>
          <option value="1" @selected($invStatus==='1')>Activo</option>
          <option value="0" @selected($invStatus==='0')>Inactivo</option>
        </select>
      </div>

      {{-- Acciones --}}
      <div class="lg:col-span-12 flex items-end justify-end gap-2">
        <a href="{{ route('dashboard') }}"
           class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200">
          Limpiar
        </a>
        <button class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
          Aplicar
        </button>
      </div>
    </form>

    {{-- ===========================
            KPIs
       =========================== --}}
    <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      <x-kpi-card title="Total socios activos" :value="$totalSociosActivos" icon="👥" />
      <x-kpi-card title="Depósitos ({{ $start->isoFormat('DD/MM') }}—{{ $end->isoFormat('DD/MM') }})" :value="$depositos" money currency="$" icon="💵" />
      <x-kpi-card title="Retiros (periodo)" :value="$retiros" money currency="$" icon="🏧" />
      <x-kpi-card title="Caja neta (ing - egr)" :value="($ingresos - $egresos)" money currency="$" icon="🏦" />
      {{-- Nuevos KPIs de inversiones --}}
      <x-kpi-card title="Inversiones (periodo)" :value="$numInversiones" icon="📈" />
      <x-kpi-card title="Total invertido" :value="$totalInvertido" money currency="$" icon="💼" />
    </div>

    {{-- ===========================
         Barras mensuales
       =========================== --}}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <h3 class="font-semibold mb-4">Distribución mensual — Depósitos</h3>
        <canvas id="chartDepositos"></canvas>
      </div>
      <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <h3 class="font-semibold mb-4">Distribución mensual — Retiros</h3>
        <canvas id="chartRetiros"></canvas>
      </div>
      <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow lg:col-span-2">
        <h3 class="font-semibold mb-4">Caja — Ingresos vs Egresos</h3>
        <canvas id="chartCaja"></canvas>
      </div>
    </div>

    {{-- ===========================
         Líneas mensual y anual
       =========================== --}}
    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <h3 class="font-semibold mb-4">Línea mensual — Depósito / Inversión / Retiro</h3>
        <canvas id="chartLineaMensual"></canvas>
      </div>
      <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
        <h3 class="font-semibold mb-4">Línea anual — Depósito / Inversión / Retiro</h3>
        <canvas id="chartLineaAnual"></canvas>
      </div>
    </div>
  </div>

  @push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4"></script>
    <script>
      // --- datos barras ---
      const labels = @json($labels);
      const dep    = @json($serieDepositos);
      const ret    = @json($serieRetiros);
      const ing    = @json($serieIngresos);
      const egr    = @json($serieEgresos);

      new Chart(document.getElementById('chartDepositos'), {
        type: 'bar',
        data: { labels, datasets: [{ label: 'Depósitos', data: dep }] },
        options: { scales: { y: { beginAtZero: true } } }
      });

      new Chart(document.getElementById('chartRetiros'), {
        type: 'bar',
        data: { labels, datasets: [{ label: 'Retiros', data: ret }] },
        options: { scales: { y: { beginAtZero: true } } }
      });

      new Chart(document.getElementById('chartCaja'), {
        type: 'bar',
        data: {
          labels,
          datasets: [
            { label: 'Ingresos', data: ing },
            { label: 'Egresos', data: egr }
          ]
        },
        options: { scales: { y: { beginAtZero: true } } }
      });

      // --- datos líneas ---
      const invMensual = @json($serieInvMensual);

      // mensual: depósito / inversión / retiro
      new Chart(document.getElementById('chartLineaMensual'), {
        type: 'line',
        data: {
          labels,
          datasets: [
            { label: 'Depósito',  data: dep,        tension: 0.3 },
            { label: 'Inversión', data: invMensual, tension: 0.3 },
            { label: 'Retiro',    data: ret,        tension: 0.3 },
          ]
        },
        options: { scales: { y: { beginAtZero: true } } }
      });

      // anual: depósito / inversión / retiro
      const labelsYears = @json($labelsYears);
      const depYear     = @json($serieDepYear);
      const invYear     = @json($serieInvYear);
      const retYear     = @json($serieRetYear);

      new Chart(document.getElementById('chartLineaAnual'), {
        type: 'line',
        data: {
          labels: labelsYears,
          datasets: [
            { label: 'Depósito',  data: depYear, tension: 0.3 },
            { label: 'Inversión', data: invYear, tension: 0.3 },
            { label: 'Retiro',    data: retYear, tension: 0.3 },
          ]
        },
        options: { scales: { y: { beginAtZero: true } } }
      });
    </script>
  @endpush
</x-app-layout>
