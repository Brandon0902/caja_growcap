<!DOCTYPE html>
<html lang="es">
  <head>
    <meta charset="UTF-8">
    <title>Prueba Growcap</title>
  </head>
  <body>
    <h1>Growcap</h1>
    <p>{{ $mensaje }}</p>
  </body>
</html>