<?php

namespace App\Http\Controllers;

use App\Models\Caja;
use App\Models\CategoriaGasto;
use App\Models\CategoriaIngreso;
use App\Models\Cliente;
use App\Models\Prestamo;
use App\Models\UserAbono;
use App\Models\UserPrestamo;
use App\Models\MovimientoCaja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class UserPrestamoController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search', '');
        $clientes = Cliente::when($search, fn($q) =>
                        $q->where('nombre', 'like', "%{$search}%")
                          ->orWhere('apellido', 'like', "%{$search}%"))
                     ->orderBy('nombre')
                     ->paginate(15)
                     ->withQueryString();

        return view('adminuserprestamos.index', compact('clientes', 'search'));
    }

    public function show($idCliente)
    {
        $cliente   = Cliente::findOrFail($idCliente);
        $prestamos = UserPrestamo::where('id_cliente', $idCliente)
                          ->orderByDesc('fecha_inicio')
                          ->paginate(15);

        $statusOptions = [
            1 => 'Autorizado',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazado',
            5 => 'Pagado',
            6 => 'Terminado',
        ];

        return view('adminuserprestamos.show', compact('cliente','prestamos','statusOptions'));
    }

    public function create()
    {
        $clientes = Cliente::orderBy('nombre')->get();
        $planes   = Prestamo::where('status', 1)->get();
        $cajas    = Caja::where('estado', 'abierta')->get();

        return view('adminuserprestamos.create', compact('clientes','planes','cajas'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_cliente'   => ['required','exists:clientes,id', function($attr,$value,$fail) {
                if (UserPrestamo::where('id_cliente',$value)->whereIn('status',[2,3])->exists()) {
                    $fail('Ya tienes una solicitud pendiente o en revisión.');
                }
            }],
            'id_activo'    => 'required|exists:prestamos,id_prestamo',
            'fecha_inicio' => 'required|date',
            'cantidad'     => 'required|numeric|min:0',
            'id_caja'      => 'required|exists:cajas,id_caja',
            'codigo_aval'  => 'nullable|string|exists:clientes,codigo_cliente|max:50',
            'doc_solicitud_aval'        => 'required_without:codigo_aval|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'doc_comprobante_domicilio' => 'required_without:codigo_aval|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'doc_ine_frente'            => 'required_without:codigo_aval|file|mimes:pdf,jpg,jpeg,png|max:2048',
            'doc_ine_reverso'           => 'required_without:codigo_aval|file|mimes:pdf,jpg,jpeg,png|max:2048',
        ]);

        $data = $request->only('id_cliente','id_activo','fecha_inicio','cantidad','codigo_aval','id_caja');
        $plan = Prestamo::findOrFail($data['id_activo']);

        $prestamo = new UserPrestamo([
            'id_cliente'       => $data['id_cliente'],
            'id_activo'        => $data['id_activo'],
            'fecha_solicitud'  => now(),
            'fecha_inicio'     => $data['fecha_inicio'],
            'cantidad'         => $data['cantidad'],
            'tipo_prestamo'    => $plan->periodo,
            'semanas'          => $plan->semanas,
            'interes'          => $plan->interes,
            'interes_generado' => $data['cantidad'] * $plan->interes / 100,
            'status'           => 3,  // En revisión
            'aval_status'      => 2,  // Pendiente de aval
            'id_usuario'       => Auth::id(),
            'abonos_echos'     => 0,
            'num_atrasos'      => 0,
            'mora_acumulada'   => 0.00,
        ]);

        $prestamo->id_caja = $data['id_caja'];

        if (!empty($data['codigo_aval'])) {
            $aval = Cliente::where('codigo_cliente',$data['codigo_aval'])->first();
            $prestamo->aval_id = $aval->id;
        } else {
            foreach ([
                'doc_solicitud_aval',
                'doc_comprobante_domicilio',
                'doc_ine_frente',
                'doc_ine_reverso',
            ] as $field) {
                if ($request->hasFile($field)) {
                    $prestamo->{$field} = $request->file($field)
                                                  ->store('prestamos/aval','public');
                }
            }
        }

        $prestamo->save();

        $fechaInicio = Carbon::parse($prestamo->fecha_inicio);
        $montoTotal  = $prestamo->cantidad + $prestamo->interes_generado;
        $pagoMinimo  = $montoTotal / max(1, $plan->semanas);

        for ($i = 1; $i <= $plan->semanas; $i++) {
            $fechaVto = $fechaInicio->copy()->addWeeks($i)->toDateString();
            $pagado   = $pagoMinimo * ($i - 1);
            $saldoRest= max(0, $montoTotal - $pagado);

            UserAbono::create([
                'id_prestamo'       => $prestamo->id,
                'id_cliente'        => $prestamo->id_cliente,
                'cantidad'          => 0,
                'tipo_abono'        => 'pendiente',
                'num_pago'          => $i,
                'mora_generada'     => 0,
                'saldo_restante'    => $saldoRest,
                'fecha'             => $fechaVto,
                'fecha_vencimiento' => $fechaVto,
                'status'            => 0,
            ]);
        }

        return redirect()
            ->route('user_prestamos.show', $prestamo->id_cliente)
            ->with('success','Préstamo creado correctamente y abonos generados.');
    }

    public function edit(UserPrestamo $prestamo)
    {
        $statusOptions = [
            1 => 'Autorizado',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazado',
            5 => 'Pagado',
            6 => 'Terminado',
        ];
        $cajas = Caja::where('estado','abierta')->get();

        return view('adminuserprestamos.edit', compact('prestamo','statusOptions','cajas'));
    }

    public function update(Request $request, UserPrestamo $prestamo)
    {
        $data = $request->validate([
            'status'   => 'required|in:1,2,3,4,5,6',
            'nota'     => 'nullable|string',
            'id_caja'  => 'required|exists:cajas,id_caja',
        ]);

        // Convertir a entero
        $newStatus = (int) $data['status'];
        $oldStatus = (int) $prestamo->status;

        $prestamo->update([
            'status'            => $newStatus,
            'nota'              => $data['nota'],  
            'aval_responded_at' => now(),
            'id_caja'           => $data['id_caja'],
        ]);

        // Egreso al autorizar desembolso (status = 5)
        if ($oldStatus !== 5 && $newStatus === 5) {
            $this->descontarDeCaja($prestamo);
        }

        // Ingreso al finalizar préstamo (status = 6)
        if ($oldStatus !== 6 && $newStatus === 6) {
            $this->ingresarPagoEnCaja($prestamo);
        }

        return redirect()
            ->route('user_prestamos.show', $prestamo->id_cliente)
            ->with('success','Préstamo actualizado correctamente.');
    }

    /**
     * Egreso de caja al desembolsar préstamo.
     */
    protected function descontarDeCaja(UserPrestamo $prestamo)
    {
        $caja          = $prestamo->caja;
        $ultimoMov     = $caja->movimientos()->latest('fecha')->first();
        $saldoAnterior = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $monto         = $prestamo->cantidad;
        $saldoPosterior= $saldoAnterior - $monto;
        $cat           = CategoriaGasto::firstWhere('nombre','Préstamos');

        MovimientoCaja::create([
            'id_caja'        => $caja->id_caja,
            'tipo_mov'       => 'Egreso',
            'id_cat_gasto'   => $cat->id_cat_gasto ?? null,
            'id_sub_gasto'   => null,
            'monto'          => $monto,
            'fecha'          => now(),
            'descripcion'    => "Desembolso préstamo #{$prestamo->id}",
            'monto_anterior' => $saldoAnterior,
            'monto_posterior'=> $saldoPosterior,
            'id_usuario'     => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldoPosterior]);
    }

    /**
     * Ingreso de caja al terminar préstamo y cobrar al cliente.
     */
    protected function ingresarPagoEnCaja(UserPrestamo $prestamo)
    {
        $caja          = $prestamo->caja;
        $ultimoMov     = $caja->movimientos()->latest('fecha')->first();
        $saldoAnterior = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $monto         = $prestamo->cantidad + $prestamo->interes_generado;
        $saldoPosterior= $saldoAnterior + $monto;
        $cat           = CategoriaIngreso::firstWhere('nombre','Préstamos');

        MovimientoCaja::create([
            'id_caja'        => $caja->id_caja,
            'tipo_mov'       => 'Ingreso',
            'id_cat_ing'     => $cat->id_cat_ing ?? null,
            'id_sub_ing'     => null,
            'monto'          => $monto,
            'fecha'          => now(),
            'descripcion'    => "Cobro préstamo #{$prestamo->id}",
            'monto_anterior' => $saldoAnterior,
            'monto_posterior'=> $saldoPosterior,
            'id_usuario'     => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldoPosterior]);
    }
}
