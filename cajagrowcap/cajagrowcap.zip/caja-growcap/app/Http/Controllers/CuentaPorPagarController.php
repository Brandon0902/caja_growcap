<?php

namespace App\Http\Controllers;

use App\Models\CuentaPorPagar;
use App\Models\Sucursal;
use App\Models\Caja;
use App\Models\Proveedor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CuentaPorPagarController extends Controller
{
    public function index()
    {
        $cuentas = CuentaPorPagar::with(['sucursal','caja','proveedor','usuario'])
                        ->orderBy('fecha_vencimiento','asc')
                        ->paginate(15);

        return view('cuentas_por_pagar.index', compact('cuentas'));
    }

    public function create()
    {
        $sucursales  = Sucursal::all();
        $cajas       = Caja::all();
        $proveedores = Proveedor::all();

        return view('cuentas_por_pagar.create', compact('sucursales','cajas','proveedores'));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_sucursal'      => 'required|exists:sucursales,id_sucursal',
            'id_caja'          => 'required|exists:cajas,id_caja',
            'proveedor_id'     => 'nullable|exists:proveedores,id_proveedor',
            'monto_total'      => 'required|numeric|min:0',
            'fecha_emision'    => 'required|date',
            'fecha_vencimiento'=> 'required|date|after_or_equal:fecha_emision',
            'estado'           => 'required|in:pendiente,pagado,vencido',
            'descripcion'      => 'nullable|string',
        ]);

        $data['id_usuario'] = Auth::id();

        CuentaPorPagar::create($data);

        return redirect()
            ->route('cuentas-por-pagar.index')
            ->with('success', 'Cuenta por pagar creada correctamente.');
    }

    public function show(CuentaPorPagar $cuentas_por_pagar)
    {
        // cargo también el detalle de amortizaciones
        $cuenta = $cuentas_por_pagar->load('detalles.caja','sucursal','caja','proveedor','usuario');

        return view('cuentas_por_pagar.show', compact('cuenta'));
    }

    public function edit(CuentaPorPagar $cuentas_por_pagar)
    {
        $cuenta      = $cuentas_por_pagar;
        $sucursales  = Sucursal::all();
        $cajas       = Caja::all();
        $proveedores = Proveedor::all();

        return view('cuentas_por_pagar.edit', compact('cuenta','sucursales','cajas','proveedores'));
    }

    public function update(Request $request, CuentaPorPagar $cuentas_por_pagar)
    {
        $data = $request->validate([
            'id_sucursal'      => 'required|exists:sucursales,id_sucursal',
            'id_caja'          => 'required|exists:cajas,id_caja',
            'proveedor_id'     => 'nullable|exists:proveedores,id_proveedor',
            'monto_total'      => 'required|numeric|min:0',
            'fecha_emision'    => 'required|date',
            'fecha_vencimiento'=> 'required|date|after_or_equal:fecha_emision',
            'estado'           => 'required|in:pendiente,pagado,vencido',
            'descripcion'      => 'nullable|string',
        ]);

        $data['id_usuario'] = Auth::id();

        $cuentas_por_pagar->update($data);

        return redirect()
            ->route('cuentas-por-pagar.index')
            ->with('success', 'Cuenta por pagar actualizada correctamente.');
    }

    public function destroy(CuentaPorPagar $cuentas_por_pagar)
    {
        $cuentas_por_pagar->delete();

        return redirect()
            ->route('cuentas-por-pagar.index')
            ->with('success', 'Cuenta por pagar eliminada correctamente.');
    }
}
