<?php
namespace App\Http\Controllers;

use App\Models\Cliente;
use App\Models\UserDeposito;
use App\Models\Caja;
use App\Models\MovimientoCaja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class UserDepositoController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search', '');
        $clientes = Cliente::where('status', 1)
            ->when($search, fn($q) => 
                $q->whereRaw("CONCAT(nombre,' ',apellido) LIKE ?", ["%{$search}%"])
            )
            ->orderByDesc('id')
            ->paginate(15);

        return view('depositos.index', compact('clientes', 'search'));
    }

    public function show(Cliente $cliente)
    {
        $depositos = UserDeposito::where('id_cliente', $cliente->id)
            ->orderByDesc('fecha_deposito')
            ->paginate(15);

        return view('depositos.show', compact('cliente', 'depositos'));
    }

    public function create()
    {
        return view('depositos.create', [
            'clientes' => Cliente::where('status',1)->orderBy('nombre')->get(),
            'cajas'    => Caja::where('estado','abierta')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_cliente'    => 'required|exists:clientes,id',
            'cantidad'      => 'required|numeric|min:0.01',
            'fecha_deposito'=> 'required|date',
            'nota'          => 'nullable|string',
            'id_caja'       => 'required|exists:cajas,id_caja',
        ]);

        // 1) Creamos el depósito
        $deposito = UserDeposito::create([
            'id_cliente'     => $data['id_cliente'],
            'cantidad'       => $data['cantidad'],
            'fecha_deposito' => $data['fecha_deposito'],
            'nota'           => $data['nota'] ?? null,
            'status'         => 1,                  // 1 = aprobado
            'id_usuario'     => Auth::id(),
            'id_caja'        => $data['id_caja'],
        ]);

        // 2) Registramos el movimiento en caja
        $this->ingresarPagoEnCaja($deposito);

        return redirect()
            ->route('depositos.show', $deposito->cliente)
            ->with('success', 'Depósito registrado y cargado en caja.');
    }

    public function update(Request $request, UserDeposito $deposito)
    {
        $data = $request->validate([
            'status' => 'required|in:0,1,2', // 0=Pendiente,1=Aprobado,2=Rechazado
        ]);

        $deposito->update(['status' => (int)$data['status']]);

        return back()->with('success', 'Status de depósito actualizado.');
    }

    /**
     * Crea un movimiento de ingreso en la caja asociada
     */
    protected function ingresarPagoEnCaja(UserDeposito $deposito): void
    {
        $caja    = Caja::findOrFail($deposito->id_caja);
        $last    = $caja->movimientos()->latest('fecha')->first();
        $antes   = $last ? $last->monto_posterior : $caja->saldo_inicial;
        $monto   = $deposito->cantidad;
        $despues = $antes + $monto;

        MovimientoCaja::create([
            'id_caja'         => $caja->id_caja,
            'tipo_mov'        => 'Ingreso',
            'id_cat_ing'      => null,
            'id_sub_ing'      => null,
            'monto'           => $monto,
            'fecha'           => now(),
            'descripcion'     => "Depósito #{$deposito->id}",
            'monto_anterior'  => $antes,
            'monto_posterior' => $despues,
            'id_usuario'      => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $despues]);
    }
}
