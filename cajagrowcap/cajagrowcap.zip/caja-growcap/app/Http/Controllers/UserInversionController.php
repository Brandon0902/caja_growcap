<?php

namespace App\Http\Controllers;

use App\Models\Caja;
use App\Models\CategoriaGasto;
use App\Models\CategoriaIngreso;
use App\Models\Cliente;
use App\Models\Inversion;         
use App\Models\UserInversion;
use App\Models\MovimientoCaja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class UserInversionController extends Controller
{
    public function index(Request $request)
    {
        $search = $request->input('search', '');

        $query = Cliente::query();
        if ($search) {
            $query->where(function($q) use ($search) {
                $q->where('nombre', 'like', "%{$search}%")
                  ->orWhere('apellido', 'like', "%{$search}%");
            });
        }

        $clientes = $query
            ->orderBy('nombre')
            ->paginate(15)
            ->withQueryString();

        return view('adminuserinversiones.index', compact('clientes', 'search'));
    }

    public function show($idCliente)
    {
        $cliente     = Cliente::findOrFail($idCliente);
        $inversiones = UserInversion::where('id_cliente', $idCliente)
            ->orderByDesc('fecha_inicio')
            ->paginate(15);

        $statusOptions = [
            1 => 'Autorizada',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazada',
            5 => 'Invertida',       // Egreso de caja
            6 => 'Finalizada',      // Ingreso de caja
        ];

        return view('adminuserinversiones.show', compact('cliente', 'inversiones', 'statusOptions'));
    }

    public function create()
    {
        $clientes = Cliente::orderBy('nombre')->get();
        $planes   = Inversion::where('status', 1)->get();
        $cajas    = Caja::where('estado', 'abierta')->get();

        return view('adminuserinversiones.create', compact('clientes', 'planes', 'cajas'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_cliente'   => 'required|exists:clientes,id',
            'id_activo'    => 'required|exists:inversiones,id_inversion',
            'fecha_inicio' => 'required|date',
            'cantidad'     => 'required|numeric|min:0.01',
            'id_caja'      => 'required|exists:cajas,id_caja',
        ]);

        $data = $request->only('id_cliente','id_activo','fecha_inicio','cantidad','id_caja');
        $plan = Inversion::findOrFail($data['id_activo']);

        $inversion = new UserInversion([
            'id_cliente'       => $data['id_cliente'],
            'id_activo'        => $data['id_activo'],
            'fecha_solicitud'  => now(),
            'fecha_inicio'     => $data['fecha_inicio'],
            'cantidad'         => $data['cantidad'],
            'interes'          => $plan->interes,
            'interes_generado' => $data['cantidad'] * $plan->interes / 100,
            'status'           => 2,  // Pendiente
            'id_usuario'       => Auth::id(),
        ]);

        // Caja para el egreso
        $inversion->id_caja = $data['id_caja'];

        $inversion->save();

        return redirect()
            ->route('user_inversiones.show', $inversion->id_cliente)
            ->with('success', 'Solicitud de inversión creada correctamente.');
    }

    public function edit(UserInversion $inversion)
    {
        $statusOptions = [
            1 => 'Autorizada',
            2 => 'Pendiente',
            3 => 'En revisión',
            4 => 'Rechazada',
            5 => 'Invertida',
            6 => 'Finalizada',
        ];
        $cajas = Caja::where('estado','abierta')->get();

        return view('adminuserinversiones.edit', compact('inversion','statusOptions','cajas'));
    }

    public function update(Request $request, UserInversion $inversion)
    {
        $data = $request->validate([
            'status'   => 'required|in:1,2,3,4,5,6',
            'nota'     => 'nullable|string',
            'id_caja'  => 'required|exists:cajas,id_caja',
        ]);

        $newStatus = (int) $data['status'];
        $oldStatus = (int) $inversion->status;

        $inversion->update([
            'status'            => $newStatus,
            'nota'              => $data['nota'],
            'fecha_respuesta'   => now(),
            'id_caja'           => $data['id_caja'],
        ]);

        // 5 => Invertida: egreso de caja
        if ($oldStatus !== 5 && $newStatus === 5) {
            $this->descontarDeCaja($inversion);
        }

        // 6 => Finalizada: ingreso de caja (monto + intereses)
        if ($oldStatus !== 6 && $newStatus === 6) {
            $this->ingresarRendimientoEnCaja($inversion);
        }

        return redirect()
            ->route('user_inversiones.show', $inversion->id_cliente)
            ->with('success','Inversión actualizada correctamente.');
    }

    protected function descontarDeCaja(UserInversion $inversion)
    {
        $caja          = $inversion->caja;
        $ultimoMov     = $caja->movimientos()->latest('fecha')->first();
        $saldoAnterior = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $monto         = $inversion->cantidad;
        $saldoPosterior= $saldoAnterior - $monto;
        $cat           = CategoriaGasto::firstWhere('nombre','Inversiones');

        MovimientoCaja::create([
            'id_caja'        => $caja->id_caja,
            'tipo_mov'       => 'Egreso',
            'id_cat_gasto'   => $cat->id_cat_gasto ?? null,
            'monto'          => $monto,
            'fecha'          => now(),
            'descripcion'    => "Desembolso inversión #{$inversion->id}",
            'monto_anterior' => $saldoAnterior,
            'monto_posterior'=> $saldoPosterior,
            'id_usuario'     => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldoPosterior]);
    }

    protected function ingresarRendimientoEnCaja(UserInversion $inversion)
    {
        $caja          = $inversion->caja;
        $ultimoMov     = $caja->movimientos()->latest('fecha')->first();
        $saldoAnterior = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $monto         = $inversion->cantidad + $inversion->interes_generado;
        $saldoPosterior= $saldoAnterior + $monto;
        $cat           = CategoriaIngreso::firstWhere('nombre','Inversiones');

        MovimientoCaja::create([
            'id_caja'        => $caja->id_caja,
            'tipo_mov'       => 'Ingreso',
            'id_cat_ing'     => $cat->id_cat_ing ?? null,
            'monto'          => $monto,
            'fecha'          => now(),
            'descripcion'    => "Cobro inversión #{$inversion->id}",
            'monto_anterior' => $saldoAnterior,
            'monto_posterior'=> $saldoPosterior,
            'id_usuario'     => Auth::id(),
        ]);

        $caja->update(['saldo_final' => $saldoPosterior]);
    }
}
