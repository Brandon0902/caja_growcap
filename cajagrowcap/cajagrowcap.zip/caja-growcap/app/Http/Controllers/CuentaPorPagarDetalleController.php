<?php

namespace App\Http\Controllers;

use App\Models\CuentaPorPagar;
use App\Models\CuentaPorPagarDetalle;
use App\Models\Caja;
use Illuminate\Http\Request;

class CuentaPorPagarDetalleController extends Controller
{
    /**
     * Muestra el formulario para crear un pago (detalle).
     */
    public function create(CuentaPorPagar $cuentas_por_pagar)
    {
        $cajas = Caja::all();
        return view(
          'cuentas_por_pagar.detalles.create',
          compact('cuentas_por_pagar','cajas')
        );
    }

    /**
     * Almacena el nuevo pago en la BD.
     */
    public function store(Request $request, CuentaPorPagar $cuentas_por_pagar)
    {
        $data = $request->validate([
            'numero_pago'      => 'required|integer|min:1',
            'fecha_pago'       => 'required|date',
            'saldo_inicial'    => 'required|numeric|min:0',
            'amortizacion_cap' => 'required|numeric|min:0',
            'pago_interes'     => 'required|numeric|min:0',
            'monto_pago'       => 'required|numeric|min:0',
            'saldo_restante'   => 'required|numeric|min:0',
            'estado'           => 'required|in:pendiente,pagado,vencido',
            'caja_id'          => 'nullable|exists:cajas,id_caja',
            'semana'           => 'nullable|integer|min:1',
        ]);

        // Ligamos el detalle a la cabecera
        $data['cuenta_id'] = $cuentas_por_pagar->id_cuentas_por_pagar;

        CuentaPorPagarDetalle::create($data);

        return redirect()
            ->route('cuentas-por-pagar.show', $cuentas_por_pagar)
            ->with('success', 'Pago agregado correctamente.');
    }

    /**
     * Muestra el formulario para editar un pago existente.
     */
    public function edit(CuentaPorPagarDetalle $detalle)
    {
        $cajas = Caja::all();
        return view(
          'cuentas_por_pagar.detalles.edit',
          compact('detalle','cajas')
        );
    }

    /**
     * Actualiza en la BD los datos del pago.
     */
    public function update(Request $request, CuentaPorPagarDetalle $detalle)
    {
        $data = $request->validate([
            'numero_pago'      => 'required|integer|min:1',
            'fecha_pago'       => 'required|date',
            'saldo_inicial'    => 'required|numeric|min:0',
            'amortizacion_cap' => 'required|numeric|min:0',
            'pago_interes'     => 'required|numeric|min:0',
            'monto_pago'       => 'required|numeric|min:0',
            'saldo_restante'   => 'required|numeric|min:0',
            'estado'           => 'required|in:pendiente,pagado,vencido',
            'caja_id'          => 'nullable|exists:cajas,id_caja',
            'semana'           => 'nullable|integer|min:1',
        ]);

        $detalle->update($data);

        return redirect()
            ->route('cuentas-por-pagar.show', $detalle->cuenta)
            ->with('success', 'Pago actualizado correctamente.');
    }

    /**
     * Elimina un pago.
     */
    public function destroy(CuentaPorPagarDetalle $detalle)
    {
        $cuenta = $detalle->cuenta;
        $detalle->delete();

        return redirect()
            ->route('cuentas-por-pagar.show', $cuenta)
            ->with('success', 'Pago eliminado correctamente.');
    }
}
