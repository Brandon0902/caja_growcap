<?php

namespace App\Http\Controllers;

use App\Models\MovimientoCaja;
use App\Models\Caja;
use App\Models\CategoriaIngreso;
use App\Models\SubcategoriaIngreso;
use App\Models\CategoriaGasto;
use App\Models\SubcategoriaGasto;
use App\Models\Proveedor;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class MovimientoCajaController extends Controller
{
    public function index()
    {
        $movimientos = MovimientoCaja::with(['caja', 'usuario'])
                          ->orderBy('fecha', 'desc')
                          ->paginate(20);

        return view('movimientos-caja.index', compact('movimientos'));
    }

    public function create()
    {
        $cajas       = Caja::orderBy('nombre')->get();
        $catsIngreso = CategoriaIngreso::orderBy('nombre')->get();
        $subsIngreso = SubcategoriaIngreso::orderBy('nombre')->get();
        $catsGasto   = CategoriaGasto::orderBy('nombre')->get();
        $subsGasto   = SubcategoriaGasto::orderBy('nombre')->get();
        $proveedores = Proveedor::orderBy('nombre')->get();

        return view('movimientos-caja.create', compact(
            'cajas', 'catsIngreso', 'subsIngreso', 'catsGasto', 'subsGasto', 'proveedores'
        ));
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_caja'      => 'required|exists:cajas,id_caja',
            'tipo_mov'     => 'required|in:ingreso,gasto',
            'id_cat_ing'   => 'required_if:tipo_mov,ingreso|exists:categoria_ingreso,id_cat_ing',
            'id_sub_ing'   => 'nullable|exists:subcategoria_ingreso,id_sub_ingreso',
            'id_cat_gasto' => 'required_if:tipo_mov,gasto|exists:categoria_gasto,id_cat_gasto',
            'id_sub_gasto' => 'nullable|exists:subcategoria_gasto,id_sub_gasto',
            'proveedor_id' => 'nullable|exists:proveedores,id_proveedor',
            'monto'        => 'required|numeric|min:0.01',
            'fecha'        => 'required|date',
            'descripcion'  => 'nullable|string|max:500',
        ]);

        $caja      = Caja::findOrFail($data['id_caja']);
        $ultimoMov = $caja->movimientos()->latest('fecha')->first();
        $montoPrev = $ultimoMov ? $ultimoMov->monto_posterior : $caja->saldo_inicial;
        $montoPost = $data['tipo_mov'] === 'ingreso'
                     ? $montoPrev + $data['monto']
                     : $montoPrev - $data['monto'];

        $data['monto_anterior']  = $montoPrev;
        $data['monto_posterior'] = $montoPost;
        $data['id_usuario']      = Auth::id();

        MovimientoCaja::create($data);
        $caja->update(['saldo_final' => $montoPost]);

        return redirect()
            ->route('movimientos-caja.index')
            ->with('success', 'Movimiento registrado correctamente.');
    }

    public function edit(MovimientoCaja $movimiento)
    {
        $cajas       = Caja::orderBy('nombre')->get();
        $catsIngreso = CategoriaIngreso::orderBy('nombre')->get();
        $subsIngreso = SubcategoriaIngreso::orderBy('nombre')->get();
        $catsGasto   = CategoriaGasto::orderBy('nombre')->get();
        $subsGasto   = SubcategoriaGasto::orderBy('nombre')->get();
        $proveedores = Proveedor::orderBy('nombre')->get();

        return view('movimientos-caja.edit', compact(
            'movimiento', 'cajas', 'catsIngreso', 'subsIngreso', 'catsGasto', 'subsGasto', 'proveedores'
        ));
    }

    public function update(Request $request, MovimientoCaja $movimiento)
    {
        $data = $request->validate([
            'id_caja'      => 'required|exists:cajas,id_caja',
            'tipo_mov'     => 'required|in:ingreso,gasto',
            'id_cat_ing'   => 'required_if:tipo_mov,ingreso|exists:categoria_ingreso,id_cat_ing',
            'id_sub_ing'   => 'nullable|exists:subcategoria_ingreso,id_sub_ingreso',
            'id_cat_gasto' => 'required_if:tipo_mov,gasto|exists:categoria_gasto,id_cat_gasto',
            'id_sub_gasto' => 'nullable|exists:subcategoria_gasto,id_sub_gasto',
            'proveedor_id' => 'nullable|exists:proveedores,id_proveedor',
            'monto'        => 'required|numeric|min:0.01',
            'fecha'        => 'required|date',
            'descripcion'  => 'nullable|string|max:500',
        ]);

        $cajaNew   = Caja::findOrFail($data['id_caja']);
        $ultimoMov = $cajaNew->movimientos()
                        ->where('id', '!=', $movimiento->id)
                        ->latest('fecha')->first();
        $montoPrev = $ultimoMov ? $ultimoMov->monto_posterior : $cajaNew->saldo_inicial;
        $montoPost = $data['tipo_mov'] === 'ingreso'
                     ? $montoPrev + $data['monto']
                     : $montoPrev - $data['monto'];

        $data['monto_anterior']  = $montoPrev;
        $data['monto_posterior'] = $montoPost;
        $data['id_usuario']      = Auth::id();

        $movimiento->update($data);
        $cajaNew->update(['saldo_final' => $montoPost]);

        return redirect()
            ->route('movimientos-caja.index')
            ->with('success', 'Movimiento actualizado correctamente.');
    }
}
