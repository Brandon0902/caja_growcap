<?php

namespace App\Http\Controllers;

use App\Models\Ahorro;
use App\Models\Caja;
use App\Models\CategoriaIngreso;
use App\Models\CategoriaGasto;
use App\Models\Cliente;
use App\Models\UserAhorro;
use App\Models\MovimientoCaja;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Carbon\Carbon;

class UserAhorroController extends Controller
{
    public function index(Request $request)
    {
        $clientes = Cliente::when($request->search, fn($q,$s) =>
                        $q->where('nombre','like',"%{$s}%")
                          ->orWhere('apellido','like',"%{$s}%")
                     )
                     ->orderBy('nombre')
                     ->paginate(15)
                     ->withQueryString();

        return view('adminuserahorros.index', [
            'clientes' => $clientes,
            'search'   => $request->search,
        ]);
    }

    public function show($idCliente)
    {
        $cliente = Cliente::findOrFail($idCliente);
        $ahorros = UserAhorro::with('movimientos')
                    ->where('id_cliente', $idCliente)
                    ->orderByDesc('fecha_inicio')
                    ->paginate(15);

        return view('adminuserahorros.show', compact('cliente','ahorros'));
    }

    public function create()
    {
        return view('adminuserahorros.create', [
            'clientes' => Cliente::orderBy('nombre')->get(),
            'planes'   => Ahorro::where('status',1)->get(),
            'cajas'    => Caja::where('estado','abierta')->get(),
        ]);
    }

    public function store(Request $request)
    {
        $data = $request->validate([
            'id_cliente'   => 'required|exists:clientes,id',
            'ahorro_id'    => 'required|exists:ahorros,id_ahorro',
            'fecha_inicio' => 'required|date',
            'monto_ahorro' => 'required|numeric|min:0.01',
            'id_caja'      => 'required|exists:cajas,id_caja',
        ]);

        $plan = Ahorro::findOrFail($data['ahorro_id']);

        $ahorro = new UserAhorro([
            'id_cliente'           => $data['id_cliente'],
            'ahorro_id'            => $data['ahorro_id'],
            'fecha_solicitud'      => now(),
            'fecha_inicio'         => $data['fecha_inicio'],
            'monto_ahorro'         => $data['monto_ahorro'],
            'rendimiento'          => $plan->rendimiento,
            'rendimiento_generado' => $data['monto_ahorro'] * $plan->rendimiento / 100,
            'status'               => 5, // 5=Depositado→Ingreso
            'id_usuario'           => Auth::id(),
        ]);

        $ahorro->id_caja = $data['id_caja'];
        $ahorro->save();

        // Registrar Ingreso en la caja
        $this->ingresarPagoEnCaja($ahorro);

        return redirect()
            ->route('user_ahorros.show', $ahorro->id_cliente)
            ->with('success','Ahorro depositado y registrado en caja.');
    }

    public function edit(UserAhorro $userAhorro)
    {
        return view('adminuserahorros.edit', [
            'userAhorro'    => $userAhorro,
            'statusOptions' => [5=>'Depositado',6=>'Retirado'],
            'cajas'         => Caja::where('estado','abierta')->get(),
        ]);
    }

    public function update(Request $request, UserAhorro $userAhorro)
    {
        $data = $request->validate([
            'status'  => 'required|in:5,6',
            'id_caja' => 'required|exists:cajas,id_caja',
        ]);

        $old = $userAhorro->status;
        $new = (int)$data['status'];

        $userAhorro->update([
            'status'  => $new,
            'id_caja' => $data['id_caja'],
        ]);

        if ($old !== 5 && $new === 5) {
            $this->ingresarPagoEnCaja($userAhorro);
        }

        if ($old !== 6 && $new === 6) {
            $this->descontarDeCaja($userAhorro);
        }

        return redirect()
            ->route('user_ahorros.show', $userAhorro->id_cliente)
            ->with('success','Ahorro actualizado correctamente.');
    }

    protected function ingresarPagoEnCaja(UserAhorro $ahorro)
    {
        $caja       = $ahorro->caja;
        $lastMov    = $caja->movimientos()->latest('fecha')->first();
        $antes      = $lastMov ? $lastMov->monto_posterior : $caja->saldo_inicial;
        $montoTotal = $ahorro->monto_ahorro + $ahorro->rendimiento_generado;
        $despues    = $antes + $montoTotal;
        $cat        = CategoriaIngreso::firstWhere('nombre','Ahorros');

        MovimientoCaja::create([
            'id_caja'        => $caja->id_caja,
            'tipo_mov'       => 'Ingreso',
            'id_cat_ing'     => $cat->id_cat_ing,
            'id_sub_ing'     => null,
            'monto'          => $montoTotal,
            'fecha'          => now(),
            'descripcion'    => "Depósito ahorro #{$ahorro->id}",
            'monto_anterior' => $antes,
            'monto_posterior'=> $despues,
            'id_usuario'     => Auth::id(),
        ]);

        $caja->update(['saldo_final'=>$despues]);
    }

    protected function descontarDeCaja(UserAhorro $ahorro)
    {
        $caja    = $ahorro->caja;
        $lastMov = $caja->movimientos()->latest('fecha')->first();
        $antes   = $lastMov ? $lastMov->monto_posterior : $caja->saldo_inicial;
        $monto   = $ahorro->monto_ahorro;
        $despues = $antes - $monto;
        $cat     = CategoriaGasto::firstWhere('nombre','Ahorros');

        MovimientoCaja::create([
            'id_caja'        => $caja->id_caja,
            'tipo_mov'       => 'Egreso',
            'id_cat_gasto'   => $cat->id_cat_gasto,
            'id_sub_gasto'   => null,
            'monto'          => $monto,
            'fecha'          => now(),
            'descripcion'    => "Retiro ahorro #{$ahorro->id}",
            'monto_anterior' => $antes,
            'monto_posterior'=> $despues,
            'id_usuario'     => Auth::id(),
        ]);

        $caja->update(['saldo_final'=>$despues]);
    }
}
