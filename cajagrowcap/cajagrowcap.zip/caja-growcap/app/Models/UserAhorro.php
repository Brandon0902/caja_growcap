<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class UserAhorro extends Model
{
    use HasFactory;

    protected $table      = 'user_ahorro';
    protected $primaryKey = 'id';
    public $timestamps    = false;

    protected $fillable = [
        'id_cliente',
        'ahorro_id',
        'monto_ahorro',
        'tipo',
        'tiempo',
        'rendimiento',
        'rendimiento_generado',
        'retiros',
        'meses_minimos',
        'retiros_echos',
        'fecha_solicitud',
        'fecha_creacion',
        'fecha_inicio',
        'status',
        'id_usuario',
        'id_caja',
        'saldo_fecha',
        'fecha_ultimo_calculo',
        'fecha_fin',
        'saldo_disponible',
        'cuota',
        'frecuencia_pago',
    ];

    protected $casts = [
        'id_cliente'           => 'integer',
        'ahorro_id'            => 'integer',
        'monto_ahorro'         => 'decimal:2',
        'tipo'                 => 'string',
        'tiempo'               => 'integer',
        'rendimiento'          => 'decimal:2',
        'rendimiento_generado' => 'decimal:2',
        'retiros'              => 'integer',
        'meses_minimos'        => 'string',   // o integer si lo cambiasas
        'retiros_echos'        => 'integer',
        'fecha_solicitud'      => 'datetime',
        'fecha_creacion'       => 'datetime',
        'fecha_inicio'         => 'datetime',
        'status'               => 'integer',
        'id_usuario'           => 'integer',
        'id_caja'              => 'integer',
        'saldo_fecha'          => 'decimal:2',
        'fecha_ultimo_calculo' => 'date',
        'fecha_fin'            => 'datetime',
        'saldo_disponible'     => 'decimal:2',
        'cuota'                => 'decimal:2',
        'frecuencia_pago'      => 'string',
    ];

    /** Relación con el plan de ahorro (“maestro”) */
    public function plan()
    {
        return $this->belongsTo(Ahorro::class, 'ahorro_id', 'id_ahorro');
    }

    /** Relación con la caja donde se hizo el depósito o retiro */
    public function caja()
    {
        return $this->belongsTo(Caja::class, 'id_caja', 'id_caja');
    }

    /** Movimientos de caja asociados a este ahorro */
    public function movimientos()
    {
        return $this->hasMany(MovimientoCaja::class, 'id_caja', 'id_caja')
                    ->where('descripcion', 'like', "Depósito ahorro #{$this->id}%")
                    ->orWhere('descripcion', 'like', "Retiro ahorro #{$this->id}%");
    }
}
