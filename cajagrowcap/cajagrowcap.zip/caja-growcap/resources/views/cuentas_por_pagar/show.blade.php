{{-- resources/views/cuentas_por_pagar/show.blade.php --}}
<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-white">
      {{ __('Cuenta #') . $cuenta->id_cuentas_por_pagar }}
    </h2>
  </x-slot>

  <div class="py-6 mx-auto max-w-5xl px-4 space-y-6">

    {{-- Cabecera --}}
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 grid grid-cols-2 gap-4">
      <div><strong>Sucursal:</strong> {{ optional($cuenta->sucursal)->nombre ?? '–' }}</div>
      <div><strong>Caja:</strong>     {{ optional($cuenta->caja)->nombre    ?? '–' }}</div>
      <div><strong>Proveedor:</strong>{{ optional($cuenta->proveedor)->nombre ?? '–' }}</div>
      <div><strong>Monto Total:</strong>{{ number_format($cuenta->monto_total, 2) }}</div>
      <div><strong>Emisión:</strong>  {{ $cuenta->fecha_emision ? $cuenta->fecha_emision->format('Y-m-d') : '–' }}</div>
      <div><strong>Vencimiento:</strong>{{ $cuenta->fecha_vencimiento ? $cuenta->fecha_vencimiento->format('Y-m-d') : '–' }}</div>
      <div><strong>Estado:</strong>   {{ ucfirst($cuenta->estado ?? '–') }}</div>
      <div><strong>Descripción:</strong>{{ $cuenta->descripcion ?? '–' }}</div>
    </div>

    {{-- Botón “Agregar Pago” --}}
    <div>
      <a href="{{ route('cuentas-por-pagar.detalles.create', $cuenta) }}"
         class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
        {{ __('Agregar Pago') }}
      </a>
    </div>

    {{-- Tabla de detalles --}}
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead class="bg-gray-50 dark:bg-gray-700">
          <tr>
            <th class="px-4 py-2">#</th>
            <th class="px-4 py-2">Fecha</th>
            <th class="px-4 py-2">Saldo Inicial</th>
            <th class="px-4 py-2">Capital</th>
            <th class="px-4 py-2">Interés</th>
            <th class="px-4 py-2">Total Pago</th>
            <th class="px-4 py-2">Saldo Restante</th>
            <th class="px-4 py-2">Semana</th>
            <th class="px-4 py-2">Estado</th>
            <th class="px-4 py-2">Acciones</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
          @forelse($cuenta->detalles as $d)
            <tr>
              <td class="px-4 py-2">{{ $d->numero_pago }}</td>
              <td class="px-4 py-2">{{ $d->fecha_pago ?? '–' }}</td>
              <td class="px-4 py-2">{{ number_format($d->saldo_inicial,2) }}</td>
              <td class="px-4 py-2">{{ number_format($d->amortizacion_cap,2) }}</td>
              <td class="px-4 py-2">{{ number_format($d->pago_interes,2) }}</td>
              <td class="px-4 py-2">{{ number_format($d->monto_pago,2) }}</td>
              <td class="px-4 py-2">{{ number_format($d->saldo_restante,2) }}</td>
              <td class="px-4 py-2">{{ $d->semana ?? '–' }}</td>
              <td class="px-4 py-2 capitalize">{{ $d->estado ?? '–' }}</td>
              <td class="px-4 py-2 whitespace-nowrap">
                <a href="{{ route('detalles.edit', $d) }}"
                   class="text-indigo-600 hover:text-indigo-900 mr-2">
                  {{ __('Editar') }}
                </a>
                <form action="{{ route('detalles.destroy', $d) }}"
                      method="POST"
                      class="inline-block"
                      onsubmit="return confirm('{{ __('Eliminar este pago?') }}');">
                  @csrf @method('DELETE')
                  <button class="text-red-600 hover:text-red-900">
                    {{ __('Borrar') }}
                  </button>
                </form>
              </td>
            </tr>
          @empty
            <tr>
              <td colspan="10" class="px-4 py-2 text-center text-gray-500">
                {{ __('No hay pagos registrados') }}
              </td>
            </tr>
          @endforelse
        </tbody>
      </table>
    </div>

  </div>
</x-app-layout>
