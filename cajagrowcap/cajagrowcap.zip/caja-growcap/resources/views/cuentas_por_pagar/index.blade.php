<x-app-layout>
  <x-slot name="header">
    <h2 class="font-semibold text-xl text-white">{{ __('Cuentas por Pagar') }}</h2>
  </x-slot>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    @if(session('success'))
      <div class="mb-4 rounded-lg bg-green-100 dark:bg-green-900 p-4 text-green-800 dark:text-green-200">
        {{ session('success') }}
      </div>
    @endif

    <div class="mb-4">
      <a href="{{ route('cuentas-por-pagar.create') }}"
         class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
        {{ __('Nueva Cuenta') }}
      </a>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead class="bg-gray-50 dark:bg-gray-700">
          <tr>
            <th class="px-4 py-2">ID</th>
            <th class="px-4 py-2">Sucursal</th>
            <th class="px-4 py-2">Caja</th>
            <th class="px-4 py-2">Proveedor</th>
            <th class="px-4 py-2">Monto</th>
            <th class="px-4 py-2">Emisión</th>
            <th class="px-4 py-2">Vencimiento</th>
            <th class="px-4 py-2">Estado</th>
            <th class="px-4 py-2">Acciones</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          @foreach($cuentas as $cuenta)
            <tr>
              <td class="px-4 py-2">{{ $cuenta->id_cuentas_por_pagar }}</td>
              <td class="px-4 py-2">{{ $cuenta->sucursal->nombre ?? '–' }}</td>
              <td class="px-4 py-2">{{ $cuenta->caja->nombre ?? '–' }}</td>
              <td class="px-4 py-2">{{ $cuenta->proveedor->nombre ?? '–' }}</td>
              <td class="px-4 py-2">{{ number_format($cuenta->monto_total,2) }}</td>
              <td class="px-4 py-2">{{ $cuenta->fecha_emision }}</td>
              <td class="px-4 py-2">{{ $cuenta->fecha_vencimiento }}</td>
              <td class="px-4 py-2 capitalize">{{ $cuenta->estado }}</td>
              <td class="px-4 py-2 whitespace-nowrap">
                <a href="{{ route('cuentas-por-pagar.show', $cuenta) }}"
                   class="text-green-600 hover:text-green-900 mr-2">{{ __('Ver') }}</a>
                <a href="{{ route('cuentas-por-pagar.edit', $cuenta) }}"
                   class="text-indigo-600 hover:text-indigo-900 mr-2">{{ __('Editar') }}</a>
                <form action="{{ route('cuentas-por-pagar.destroy', $cuenta) }}"
                      method="POST" class="inline-block"
                      onsubmit="return confirm('¿Seguro que quieres eliminarla?');">
                  @csrf @method('DELETE')
                  <button type="submit" class="text-red-600 hover:text-red-900">
                    {{ __('Eliminar') }}
                  </button>
                </form>
              </td>
            </tr>
          @endforeach
        </tbody>
      </table>

      <div class="mt-4">
        {{ $cuentas->links() }}
      </div>
    </div>
  </div>
</x-app-layout>
