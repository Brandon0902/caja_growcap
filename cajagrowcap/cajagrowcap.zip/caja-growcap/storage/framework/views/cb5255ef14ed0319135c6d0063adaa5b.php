
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Detalles de la Sucursal')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-6">
      
      <div>
        <h3 class="text-gray-500 dark:text-gray-400 uppercase text-xs font-medium"><?php echo e(__('Nombre')); ?></h3>
        <p class="mt-1 text-gray-900 dark:text-gray-100"><?php echo e($sucursal->nombre); ?></p>
      </div>

      
      <div>
        <h3 class="text-gray-500 dark:text-gray-400 uppercase text-xs font-medium"><?php echo e(__('Dirección')); ?></h3>
        <p class="mt-1 text-gray-900 dark:text-gray-100 whitespace-pre-line"><?php echo e($sucursal->direccion); ?></p>
      </div>

      
      <div>
        <h3 class="text-gray-500 dark:text-gray-400 uppercase text-xs font-medium"><?php echo e(__('Teléfono')); ?></h3>
        <p class="mt-1 text-gray-900 dark:text-gray-100"><?php echo e($sucursal->telefono); ?></p>
      </div>

      
      <div>
        <h3 class="text-gray-500 dark:text-gray-400 uppercase text-xs font-medium"><?php echo e(__('Gerente')); ?></h3>
        <p class="mt-1 text-gray-900 dark:text-gray-100">
          <?php echo e(optional($sucursal->gerente)->name ?? __('— Sin asignar —')); ?>

        </p>
      </div>

      
      <?php if($sucursal->politica_crediticia): ?>
      <div>
        <h3 class="text-gray-500 dark:text-gray-400 uppercase text-xs font-medium"><?php echo e(__('Política crediticia')); ?></h3>
        <p class="mt-1 text-gray-900 dark:text-gray-100 whitespace-pre-line">
          <?php echo e($sucursal->politica_crediticia); ?>

        </p>
      </div>
      <?php endif; ?>

      
      <div>
        <h3 class="text-gray-500 dark:text-gray-400 uppercase text-xs font-medium"><?php echo e(__('Activa')); ?></h3>
        <?php if($sucursal->acceso_activo): ?>
          <span class="inline-flex items-center rounded-full bg-green-100 px-2 py-1 text-xs font-semibold text-green-800 dark:bg-green-900 dark:text-green-200">
            Sí
          </span>
        <?php else: ?>
          <span class="inline-flex items-center rounded-full bg-red-100 px-2 py-1 text-xs font-semibold text-red-800 dark:bg-red-900 dark:text-red-200">
            No
          </span>
        <?php endif; ?>
      </div>

      
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <h3 class="text-gray-500 dark:text-gray-400 uppercase text-xs font-medium"><?php echo e(__('Creada por')); ?></h3>
          <p class="mt-1 text-gray-900 dark:text-gray-100">
            <?php echo e(optional($sucursal->creador)->name ?? '-'); ?>

          </p>
        </div>
        <div>
          <h3 class="text-gray-500 dark:text-gray-400 uppercase text-xs font-medium"><?php echo e(__('Fecha de creación')); ?></h3>
          <p class="mt-1 text-gray-900 dark:text-gray-100"><?php echo e($sucursal->created_at->format('d/m/Y H:i')); ?></p>
        </div>
      </div>
    </div>

    
    <div class="mt-6 flex space-x-3">
      <a href="<?php echo e(route('sucursales.index')); ?>"
         class="inline-flex items-center px-4 py-2 bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 
                text-gray-800 dark:text-gray-200 font-medium rounded-md shadow-sm transition">
        <?php echo e(__('← Volver')); ?>

      </a>

      <a href="<?php echo e(route('sucursales.edit', $sucursal)); ?>"
         class="inline-flex items-center px-4 py-2 bg-purple-600 hover:bg-purple-700 dark:bg-purple-500 dark:hover:bg-purple-600 
                text-white font-medium rounded-md shadow-sm transition">
        <?php echo e(__('Editar')); ?>

      </a>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/sucursales/show.blade.php ENDPATH**/ ?>