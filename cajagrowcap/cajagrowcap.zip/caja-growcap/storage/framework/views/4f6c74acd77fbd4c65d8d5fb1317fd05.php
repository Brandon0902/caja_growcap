

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Editar Movimiento de Caja')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
      <form action="<?php echo e(route('movimientos-caja.update', $movimiento)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="grid gap-6">
          
          <div>
            <label for="id_caja" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Caja
            </label>
            <select name="id_caja" id="id_caja"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                           focus:border-purple-500 focus:ring-purple-500
                           dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
              <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($caja->id); ?>"
                  <?php echo e(old('id_caja', $movimiento->id_caja) == $caja->id ? 'selected' : ''); ?>>
                  <?php echo e($caja->nombre); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_caja'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Tipo de Movimiento
            </label>
            <div class="mt-1 flex items-center space-x-4">
              <label class="inline-flex items-center">
                <input type="radio" name="tipo_mov" value="ingreso"
                  <?php echo e(old('tipo_mov', $movimiento->tipo_mov) == 'ingreso' ? 'checked' : ''); ?>>
                <span class="ml-2">Ingreso</span>
              </label>
              <label class="inline-flex items-center">
                <input type="radio" name="tipo_mov" value="gasto"
                  <?php echo e(old('tipo_mov', $movimiento->tipo_mov) == 'gasto' ? 'checked' : ''); ?>>
                <span class="ml-2">Gasto</span>
              </label>
            </div>
            <?php $__errorArgs = ['tipo_mov'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label for="id_cat_ing" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Categoría de Ingreso
            </label>
            <select name="id_cat_ing" id="id_cat_ing"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                           focus:border-purple-500 focus:ring-purple-500
                           dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
              <option value="">— selecciona —</option>
              <?php $__currentLoopData = $catsIngreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id_cat_ing); ?>"
                  <?php echo e(old('id_cat_ing', $movimiento->id_cat_ing) == $cat->id_cat_ing ? 'selected' : ''); ?>>
                  <?php echo e($cat->nombre); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_cat_ing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label for="id_sub_ing" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Subcategoría de Ingreso
            </label>
            <select name="id_sub_ing" id="id_sub_ing"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                           focus:border-purple-500 focus:ring-purple-500
                           dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
              <option value="">— opcional —</option>
              <?php $__currentLoopData = $subsIngreso; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($sub->id_sub_ingreso); ?>"
                  <?php echo e(old('id_sub_ing', $movimiento->id_sub_ing) == $sub->id_sub_ingreso ? 'selected' : ''); ?>>
                  <?php echo e($sub->nombre); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_sub_ing'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label for="id_cat_gasto" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Categoría de Gasto
            </label>
            <select name="id_cat_gasto" id="id_cat_gasto"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                           focus:border-purple-500 focus:ring-purple-500
                           dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
              <option value="">— selecciona —</option>
              <?php $__currentLoopData = $catsGasto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cat->id_cat_gasto); ?>"
                  <?php echo e(old('id_cat_gasto', $movimiento->id_cat_gasto) == $cat->id_cat_gasto ? 'selected' : ''); ?>>
                  <?php echo e($cat->nombre); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_cat_gasto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label for="id_sub_gasto" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Subcategoría de Gasto
            </label>
            <select name="id_sub_gasto" id="id_sub_gasto"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                           focus:border-purple-500 focus:ring-purple-500
                           dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
              <option value="">— opcional —</option>
              <?php $__currentLoopData = $subsGasto; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($sub->id_sub_gasto); ?>"
                  <?php echo e(old('id_sub_gasto', $movimiento->id_sub_gasto) == $sub->id_sub_gasto ? 'selected' : ''); ?>>
                  <?php echo e($sub->nombre); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['id_sub_gasto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label for="proveedor_id" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Proveedor
            </label>
            <select name="proveedor_id" id="proveedor_id"
                    class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                           focus:border-purple-500 focus:ring-purple-500
                           dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
              <option value="">— ninguno —</option>
              <?php $__currentLoopData = $proveedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prov): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($prov->id_proveedor); ?>"
                  <?php echo e(old('proveedor_id', $movimiento->proveedor_id) == $prov->id_proveedor ? 'selected' : ''); ?>>
                  <?php echo e($prov->nombre); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['proveedor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label for="monto" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Monto
            </label>
            <input type="number" name="monto" id="monto" step="0.01"
                   value="<?php echo e(old('monto', $movimiento->monto)); ?>"
                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                          focus:border-purple-500 focus:ring-purple-500
                          dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
            <?php $__errorArgs = ['monto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label for="fecha" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Fecha
            </label>
            <input type="date" name="fecha" id="fecha"
                   value="<?php echo e(old('fecha', $movimiento->fecha->format('Y-m-d'))); ?>"
                   class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                          focus:border-purple-500 focus:ring-purple-500
                          dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200">
            <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>

          
          <div>
            <label for="descripcion" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
              Descripción
            </label>
            <textarea name="descripcion" id="descripcion" rows="3"
                      class="mt-1 block w-full rounded-md border-gray-300 shadow-sm
                             focus:border-purple-500 focus:ring-purple-500
                             dark:bg-gray-700 dark:border-gray-600 dark:text-gray-200"><?php echo e(old('descripcion', $movimiento->descripcion)); ?></textarea>
            <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <p class="mt-1 text-sm text-red-600"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
          </div>
        </div>

        <div class="mt-6 flex justify-end space-x-2">
          <a href="<?php echo e(route('movimientos-caja.index')); ?>"
             class="px-4 py-2 bg-gray-200 rounded-md hover:bg-gray-300">
            Cancelar
          </a>
          <button type="submit"
                  class="px-4 py-2 bg-yellow-500 text-white rounded-md hover:bg-yellow-600">
            Actualizar
          </button>
        </div>
      </form>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/movimientos-caja/edit.blade.php ENDPATH**/ ?>