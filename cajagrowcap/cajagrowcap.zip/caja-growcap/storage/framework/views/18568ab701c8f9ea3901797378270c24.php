
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <?php $isEdit = $userData->exists; ?>
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e($isEdit
          ? "Editar Datos de Cliente ({$cliente->nombre} {$cliente->apellido})"
          : "Nuevo Registro de Datos Cliente ({$cliente->nombre} {$cliente->apellido})"); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <?php
    $tabs = [
      'general'       => 'Datos Generales',
      'beneficiarios' => 'Beneficiarios',
      'banco'         => 'Banco',
      'seguridad'     => 'Seguridad',
      'acceso'        => 'Acceso',
      'laborales'     => 'Laborales',
    ];
    $active = request('tab','general');
    $formAction = route('clientes.datos.save', $cliente) . '?tab=' . $active;
  ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    <?php if(session('success')): ?>
      <div class="mb-4 rounded-lg bg-green-100 p-4 text-green-800 dark:bg-green-900 dark:text-green-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg">
      
      <nav class="flex border-b border-gray-200 dark:border-gray-700 px-4">
        <?php $__currentLoopData = $tabs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="<?php echo e(route('clientes.datos.form', $cliente)); ?>?tab=<?php echo e($key); ?>"
             class="py-3 px-4 -mb-px border-b-2 font-medium text-sm
               <?php echo e($active === $key
                  ? 'border-indigo-500 text-indigo-600 dark:text-indigo-300'
                  : 'border-transparent text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200 hover:border-gray-300'); ?>">
            <?php echo e($label); ?>

          </a>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </nav>

      <?php if($active === 'laborales' && $userData->exists): ?>
        
        <?php echo $__env->make('user_data.partials.laborales', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <?php else: ?>
        <form action="<?php echo e($formAction); ?>" method="POST" class="space-y-6 p-6">
          <?php echo csrf_field(); ?>

          
          <input type="hidden" name="tab" value="<?php echo e($active); ?>">

          <div class="bg-gray-50 dark:bg-gray-700 rounded-lg p-6 space-y-6">
            <?php switch($active):
              case ('general'): ?>
                <?php echo $__env->make('user_data.partials.general', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

              <?php case ('beneficiarios'): ?>
                <?php echo $__env->make('user_data.partials.beneficiarios', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

              <?php case ('banco'): ?>
                <?php echo $__env->make('user_data.partials.banco', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

              <?php case ('seguridad'): ?>
                <?php echo $__env->make('user_data.partials.seguridad', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

              <?php case ('acceso'): ?>
                <?php echo $__env->make('user_data.partials.acceso', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php break; ?>

              <?php default: ?>
                <?php echo $__env->make('user_data.partials.general', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endswitch; ?>
          </div>

          <div class="text-right">
            <button type="submit"
                    class="px-4 py-2 <?php echo e($isEdit ? 'bg-indigo-600 hover:bg-indigo-700' : 'bg-blue-600 hover:bg-blue-700'); ?> text-white rounded">
              <?php echo e($isEdit ? 'Guardar cambios' : 'Guardar'); ?>

            </button>
          </div>
        </form>
      <?php endif; ?>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/user_data/form.blade.php ENDPATH**/ ?>