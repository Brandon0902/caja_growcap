<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      Mensaje #<?php echo e($mensaje->id); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-4">
      <div>
        <strong>Destinatario:</strong>
        <?php echo e($mensaje->id_cliente
            ? $mensaje->cliente->nombre . ' ' . $mensaje->cliente->apellido
            : 'Todos los clientes'); ?>

      </div>
      <div>
        <strong>Tipo:</strong>
        <?php switch($mensaje->tipo):
          case (1): ?> Notificación <?php break; ?>
          <?php case (2): ?> Recordatorio <?php break; ?>
          <?php case (3): ?> Alerta <?php break; ?>
        <?php endswitch; ?>
      </div>
      <div>
        <strong>Asunto:</strong> <?php echo e($mensaje->asunto); ?>

      </div>
      <div>
        <strong>Cuerpo:</strong><br>
        <div class="prose dark:prose-invert mt-2">
          <?php echo nl2br(e($mensaje->cuerpo)); ?>

        </div>
      </div>
      <?php if($mensaje->img): ?>
        <div>
          <strong>Imagen adjunta:</strong><br>
          <img src="<?php echo e(route('mensajes.imagen',$mensaje)); ?>"
               class="mt-2 max-h-64 rounded border"/>
        </div>
      <?php endif; ?>
      <div>
        <strong>Fecha de envío:</strong>
        <?php echo e(optional($mensaje->fecha_envio)->format('Y-m-d H:i') ?: '—'); ?>

      </div>
      <div>
        <strong>Estado:</strong>
        <?php if($mensaje->status): ?>
          Activo
        <?php else: ?>
          Inactivo
        <?php endif; ?>
      </div>

      <div class="pt-4">
        <a href="<?php echo e(route('mensajes.index')); ?>"
           class="px-4 py-2 bg-gray-300 hover:bg-gray-400 text-gray-800 dark:text-gray-200 rounded-md">
          Volver al listado
        </a>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/mensajes/show.blade.php ENDPATH**/ ?>