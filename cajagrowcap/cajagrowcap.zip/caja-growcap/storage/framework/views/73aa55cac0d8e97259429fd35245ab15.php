
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <div class="flex items-center justify-between">
      <h2 class="font-semibold text-xl text-white leading-tight">
        <?php echo e(__('Editar Préstamo #')); ?><?php echo e(str_pad($prestamo->id, 3, '0', STR_PAD_LEFT)); ?>

      </h2>
      <a href="<?php echo e(route('user_prestamos.show', $prestamo->id_cliente)); ?>"
         class="inline-flex items-center px-3 py-2 bg-gray-500 hover:bg-gray-600
                text-white text-sm font-medium rounded-md shadow-sm">
        <?php echo e(__('← Volver')); ?>

      </a>
    </div>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    <?php if($errors->any()): ?>
      <div class="mb-4 p-4 bg-red-100 text-red-800 rounded">
        <ul class="list-disc list-inside">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?php echo e(route('user_prestamos.update', $prestamo)); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>

      <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 space-y-6">
        
        <div>
          <label for="id_caja" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            <?php echo e(__('Caja de Desembolso')); ?>

          </label>
          <select id="id_caja" name="id_caja" required
                  class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md
                         bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 focus:ring focus:ring-purple-500">
            <option value="">— <?php echo e(__('Selecciona caja')); ?> —</option>
            <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $caja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($caja->id_caja); ?>"
                <?php echo e(old('id_caja', $prestamo->id_caja) == $caja->id_caja ? 'selected' : ''); ?>>
                <?php echo e($caja->nombre); ?> (<?php echo e($caja->fecha_apertura->format('d/m/Y')); ?>)
              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div>
          <label for="status" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            <?php echo e(__('Estado Préstamo')); ?>

          </label>
          <select id="status" name="status" required
                  class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md
                         bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 focus:ring focus:ring-purple-500">
            <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($key); ?>"
                <?php echo e(old('status', $prestamo->status) == $key ? 'selected' : ''); ?>>
                <?php echo e($label); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div>
          <label for="nota" class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            <?php echo e(__('Nota')); ?>

          </label>
          <textarea id="nota" name="nota" rows="4"
                    class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md
                           bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 focus:ring focus:ring-purple-500"><?php echo e(old('nota', $prestamo->nota)); ?></textarea>
        </div>

        
        <div class="flex justify-end">
          <button type="submit"
                  class="inline-flex items-center px-4 py-2 bg-green-600 hover:bg-green-700
                         text-white text-sm font-medium rounded-md shadow-sm focus:outline-none
                         focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
            <?php echo e(__('Guardar Cambios')); ?>

          </button>
        </div>
      </div>
    </form>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserprestamos/edit.blade.php ENDPATH**/ ?>