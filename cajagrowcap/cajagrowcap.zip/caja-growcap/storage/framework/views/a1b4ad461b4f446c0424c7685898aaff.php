<?php
    /* Municipios → objeto clave-valor para Alpine */
    $municipios = $municipios->toArray();                  //  [397 => 'Tlajomulco', …]
?>

<div
    x-data="municipioSelect()"
    x-init="init()"
    x-cloak
    class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6"
>

    
    <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Estado
        </label>

        <select name="id_estado"
                x-model="estado"
                @change="loadMunicipios"
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded
                       bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
            <option value="">— Selecciona —</option>
            <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($id); ?>"><?php echo e($nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        <?php $__errorArgs = ['id_estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    
    <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Municipio
        </label>

        <select name="id_municipio"
                x-model="municipio"
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded
                       bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
            <option value="">— Selecciona —</option>

            <template x-for="(nombre, id) in municipios" :key="id">
                <option :value="id"
                        :selected="id === municipio"
                        x-text="nombre"></option>
            </template>
        </select>

        <?php $__errorArgs = ['id_municipio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

</div>


<div class="sm:col-span-2 mb-6">
    <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
        RFC
    </label>
    <input type="text" name="rfc"
           value="<?php echo e(old('rfc', $userData->rfc ?? '')); ?>"
           class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded
                  bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"/>
    <?php $__errorArgs = ['rfc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>


<div class="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-6">
    <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Dirección
        </label>
        <input type="text" name="direccion"
               value="<?php echo e(old('direccion', $userData->direccion ?? '')); ?>"
               class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded
                      bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"/>
        <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Colonia
        </label>
        <input type="text" name="colonia"
               value="<?php echo e(old('colonia', $userData->colonia ?? '')); ?>"
               class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded
                      bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"/>
        <?php $__errorArgs = ['colonia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            CP
        </label>
        <input type="text" name="cp"
               value="<?php echo e(old('cp', $userData->cp ?? '')); ?>"
               class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded
                      bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"/>
        <?php $__errorArgs = ['cp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>




<script>
function municipioSelect () {
    return {
        /* siempre como string para comparación estricta */
        estado    : String(`<?php echo e(old('id_estado', $userData->id_estado)); ?>`.trim()),
        municipio : String(`<?php echo e(old('id_municipio', $userData->id_municipio)); ?>`.trim()),
        municipios: <?php echo json_encode($municipios, 15, 512) ?>,

        /* carga municipios cuando cambia el estado */
        async loadMunicipios() {
            if (!this.estado) {
                this.municipios = {};
                this.municipio  = '';
                return;
            }

            try {
                const res = await fetch(`/municipios?estado=${this.estado}`);
                const data = await res.json();
                this.municipios = data;

                /* conserva selección si sigue existiendo */
                if (!this.municipio || !(this.municipio in data)) {
                    this.municipio = '';
                }
            } catch (e) {
                console.error('Error cargando municipios', e);
            }
        },

        /* al iniciar */
        init() {
            if (this.estado && Object.keys(this.municipios).length === 0) {
                this.loadMunicipios();
            }
        }
    };
}
</script>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/user_data/partials/general.blade.php ENDPATH**/ ?>