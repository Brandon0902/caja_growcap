
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Ver Caja')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 space-y-4">
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Nombre</h3>
        <p class="text-gray-700 dark:text-gray-300"><?php echo e($caja->nombre); ?></p>
      </div>
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Sucursal</h3>
        <p class="text-gray-700 dark:text-gray-300">
          <?php echo e(optional($caja->sucursal)->nombre ?? '-'); ?>

        </p>
      </div>
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Responsable</h3>
        <p class="text-gray-700 dark:text-gray-300">
          <?php echo e(optional($caja->responsable)->name ?? '-'); ?>

        </p>
      </div>
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Fecha de apertura</h3>
        <p class="text-gray-700 dark:text-gray-300">
          <?php echo e($caja->fecha_apertura->format('Y-m-d H:i')); ?>

        </p>
      </div>
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Saldo inicial</h3>
        <p class="text-gray-700 dark:text-gray-300">
          <?php echo e(number_format($caja->saldo_inicial, 2)); ?>

        </p>
      </div>
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Estado</h3>
        <p class="text-gray-700 dark:text-gray-300">
          <?php echo e(ucfirst($caja->estado)); ?>

        </p>
      </div>
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Acceso activo</h3>
        <p class="text-gray-700 dark:text-gray-300">
          <?php echo e($caja->acceso_activo ? 'Sí' : 'No'); ?>

        </p>
      </div>
      <div>
        <h3 class="font-semibold text-lg text-gray-800 dark:text-gray-200">Creado por</h3>
        <p class="text-gray-700 dark:text-gray-300">
          <?php echo e(optional($caja->creador)->name ?? '-'); ?>

        </p>
      </div>
      <div class="flex justify-end">
        <a href="<?php echo e(route('cajas.index')); ?>"
           class="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded">
          <?php echo e(__('Volver')); ?>

        </a>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/cajas/show.blade.php ENDPATH**/ ?>