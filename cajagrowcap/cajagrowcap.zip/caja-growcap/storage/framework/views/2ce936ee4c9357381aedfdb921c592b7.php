
<div class="grid grid-cols-1 mb-6">
  <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
    NIP
  </label>
  <input
    type="text"
    name="nip"
    value="<?php echo e(old('nip', $userData->nip ?? '')); ?>"
    pattern="\d{4}"
    maxlength="4"
    minlength="4"
    inputmode="numeric"
    required
    class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
    oninvalid="this.setCustomValidity('El NIP debe tener exactamente 4 dígitos numéricos')"
    oninput="this.setCustomValidity('')"
  />
  <?php $__errorArgs = ['nip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/user_data/partials/seguridad.blade.php ENDPATH**/ ?>