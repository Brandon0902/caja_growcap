<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Tickets de Soporte')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{ search: '<?php echo e(request('search','')); ?>' }"
  >
    
    <div class="mb-4 flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
      <input type="text"
             x-model="search"
             @input.debounce.500ms="window.location = '<?php echo e(route('tickets.index')); ?>?search=' + search"
             placeholder="<?php echo e(__('Buscar…')); ?>"
             class="px-3 py-2 border rounded-md shadow-sm
                    focus:outline-none focus:ring-2 focus:ring-purple-500
                    bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200
                    dark:border-gray-600 w-full sm:w-1/3"/>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
          <thead class="bg-indigo-600 dark:bg-indigo-800">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">ID</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Cliente</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Asunto</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Área</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Fecha</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Status</th>
              <th class="px-6 py-3 text-right text-xs font-medium text-white uppercase">Acciones</th>
            </tr>
          </thead>
          <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr class="hover:bg-gray-100 dark:hover:bg-gray-700"
                  x-show="$el.textContent.toLowerCase().includes(search.toLowerCase())"
              >
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e(str_pad($ticket->id, 3, '0', STR_PAD_LEFT)); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e($ticket->cliente->nombre ?? '—'); ?>

                  <?php echo e($ticket->cliente->apellido ?? ''); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e($ticket->asunto); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e($ticket->area); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  
                  <?php echo e($ticket->fecha->format('d/m/Y')); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php
                    $labels = [0 => 'Pendiente', 1 => 'En Proceso', 2 => 'Cerrado'];
                    $colors = [
                      0 => 'bg-red-100 text-red-800',
                      1 => 'bg-yellow-100 text-yellow-800',
                      2 => 'bg-green-100 text-green-800',
                    ];
                  ?>
                  <span class="px-2 py-1 rounded text-sm <?php echo e($colors[$ticket->status]); ?>">
                    <?php echo e($labels[$ticket->status]); ?>

                  </span>
                </td>
                <td class="px-6 py-4 text-right">
                  <a href="<?php echo e(route('tickets.show', $ticket)); ?>"
                     class="inline-flex items-center px-3 py-2 bg-indigo-500 hover:bg-indigo-600
                            text-white text-sm font-medium rounded-md shadow-sm">
                    Ver / Responder
                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="7"
                    class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                  No hay tickets registrados.
                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
      <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right sm:px-6">
        <?php echo e($tickets->appends(['search' => request('search')])->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/tickets/index.blade.php ENDPATH**/ ?>