<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white"><?php echo e(__('Cuentas por Pagar')); ?></h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    <?php if(session('success')): ?>
      <div class="mb-4 rounded-lg bg-green-100 dark:bg-green-900 p-4 text-green-800 dark:text-green-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="mb-4">
      <a href="<?php echo e(route('cuentas-por-pagar.create')); ?>"
         class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
        <?php echo e(__('Nueva Cuenta')); ?>

      </a>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead class="bg-gray-50 dark:bg-gray-700">
          <tr>
            <th class="px-4 py-2">ID</th>
            <th class="px-4 py-2">Sucursal</th>
            <th class="px-4 py-2">Caja</th>
            <th class="px-4 py-2">Proveedor</th>
            <th class="px-4 py-2">Monto</th>
            <th class="px-4 py-2">Emisión</th>
            <th class="px-4 py-2">Vencimiento</th>
            <th class="px-4 py-2">Estado</th>
            <th class="px-4 py-2">Acciones</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          <?php $__currentLoopData = $cuentas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cuenta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="px-4 py-2"><?php echo e($cuenta->id_cuentas_por_pagar); ?></td>
              <td class="px-4 py-2"><?php echo e($cuenta->sucursal->nombre ?? '–'); ?></td>
              <td class="px-4 py-2"><?php echo e($cuenta->caja->nombre ?? '–'); ?></td>
              <td class="px-4 py-2"><?php echo e($cuenta->proveedor->nombre ?? '–'); ?></td>
              <td class="px-4 py-2"><?php echo e(number_format($cuenta->monto_total,2)); ?></td>
              <td class="px-4 py-2"><?php echo e($cuenta->fecha_emision); ?></td>
              <td class="px-4 py-2"><?php echo e($cuenta->fecha_vencimiento); ?></td>
              <td class="px-4 py-2 capitalize"><?php echo e($cuenta->estado); ?></td>
              <td class="px-4 py-2 whitespace-nowrap">
                <a href="<?php echo e(route('cuentas-por-pagar.show', $cuenta)); ?>"
                   class="text-green-600 hover:text-green-900 mr-2"><?php echo e(__('Ver')); ?></a>
                <a href="<?php echo e(route('cuentas-por-pagar.edit', $cuenta)); ?>"
                   class="text-indigo-600 hover:text-indigo-900 mr-2"><?php echo e(__('Editar')); ?></a>
                <form action="<?php echo e(route('cuentas-por-pagar.destroy', $cuenta)); ?>"
                      method="POST" class="inline-block"
                      onsubmit="return confirm('¿Seguro que quieres eliminarla?');">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="text-red-600 hover:text-red-900">
                    <?php echo e(__('Eliminar')); ?>

                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <div class="mt-4">
        <?php echo e($cuentas->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/cuentas_por_pagar/index.blade.php ENDPATH**/ ?>