
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <div class="flex items-center justify-between">
      <h2 class="font-semibold text-xl text-white leading-tight">
        Ticket #<?php echo e(str_pad($ticket->id,3,'0',STR_PAD_LEFT)); ?> – <?php echo e($ticket->asunto); ?>

      </h2>
      
      <form action="<?php echo e(route('tickets.destroy', $ticket)); ?>"
            method="POST"
            onsubmit="return confirm('¿Estás seguro de eliminar este ticket?');"
      >
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
        <button type="submit"
                class="px-3 py-2 bg-red-600 hover:bg-red-700 text-white rounded-md text-sm">
          Eliminar Ticket
        </button>
      </form>
    </div>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-4xl px-4 sm:px-6 lg:px-8 space-y-6">

    
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
      <p class="text-gray-700 dark:text-gray-200"><strong>Área:</strong> <?php echo e($ticket->area); ?></p>
      <p class="text-gray-700 dark:text-gray-200">
        <strong>Cliente:</strong>
        <?php echo e(optional($ticket->cliente)->nombre ?? '—'); ?>

        <?php echo e(optional($ticket->cliente)->apellido ?? ''); ?>

      </p>
      <p class="mt-4 text-gray-700 dark:text-gray-200 whitespace-pre-line">
        <?php echo e($ticket->mensaje); ?>

      </p>

      <?php if($ticket->adjunto): ?>
        <a href="<?php echo e(route('tickets.download', $ticket)); ?>"
           class="mt-4 inline-block text-indigo-600 hover:underline">
          📎 Ver adjunto
        </a>
      <?php endif; ?>

      <p class="mt-4 text-sm text-gray-500 dark:text-gray-400">
        Creado: <?php echo e(\Carbon\Carbon::parse($ticket->fecha)->format('d/m/Y H:i')); ?>

      </p>
    </div>

    
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-6">
      <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Respuestas</h3>

      <?php $__empty_1 = true; $__currentLoopData = $ticket->respuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="flex space-x-4">
          <img src="<?php echo e(asset('images/avatar_admin.png')); ?>"
               alt="Avatar Asesor"
               class="h-10 w-10 rounded-full flex-shrink-0">
          <div class="flex-1">
            <div class="flex justify-between items-center">
              <span class="font-medium text-gray-900 dark:text-gray-100">
                <?php echo e(optional($resp->usuario)->name ?? 'Usuario'); ?>

              </span>
              <span class="text-xs text-gray-500 dark:text-gray-400">
                <?php echo e(\Carbon\Carbon::parse($resp->fecha)->format('d/m/Y H:i')); ?>

              </span>
            </div>
            <p class="mt-2 text-gray-700 dark:text-gray-200 whitespace-pre-line">
              <?php echo e($resp->respuesta); ?>

            </p>
            
            <form action="<?php echo e(route('tickets.respuestas.destroy', $resp)); ?>"
                  method="POST"
                  class="mt-2 text-right"
                  onsubmit="return confirm('¿Eliminar esta respuesta?');"
            >
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="text-red-600 hover:text-red-800 text-sm">
                Eliminar respuesta
              </button>
            </form>
          </div>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <p class="text-gray-500 dark:text-gray-400">Aún no hay respuestas para este ticket.</p>
      <?php endif; ?>
    </div>

    
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
      <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">Agregar respuesta</h3>
      <form action="<?php echo e(route('tickets.respuestas.store', $ticket)); ?>"
            method="POST"
            class="mt-4 space-y-4"
      >
        <?php echo csrf_field(); ?>

        
        <div>
          <label for="status"
                 class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Cambiar estado
          </label>
          <select name="status" id="status" required
                  class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm
                         focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700
                         text-gray-900 dark:text-gray-100">
            <?php
              $labels = [0=>'Pendiente',1=>'En Proceso',2=>'Cerrado'];
            ?>
            <?php $__currentLoopData = $labels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($value); ?>" <?php echo e($ticket->status == $value ? 'selected' : ''); ?>>
                <?php echo e($label); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div>
          <label for="respuesta"
                 class="block text-sm font-medium text-gray-700 dark:text-gray-200">
            Tu respuesta
          </label>
          <textarea name="respuesta"
                    id="respuesta"
                    rows="4"
                    required
                    class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm
                           focus:ring-indigo-500 focus:border-indigo-500 bg-white dark:bg-gray-700
                           text-gray-900 dark:text-gray-100"></textarea>
        </div>

        
        <div class="text-right">
          <button type="submit"
                  class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-md">
            Contestar
          </button>
        </div>
      </form>
    </div>

  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/tickets/show.blade.php ENDPATH**/ ?>