
<?php
  $doc    = $userData->documento;
  $campos = [
    'documento_01'    => 'Comprobante de Domicilio',
    'documento_02'    => 'INE Frente',
    'documento_02_02' => 'INE Reversa',
    'documento_03'    => 'INE Beneficiario',
    'documento_04'    => 'INE Beneficiario 02',
    'documento_05'    => 'Contrato',
  ];
?>


<?php if($errors->any()): ?>
  <div class="mb-6 p-4 bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 rounded-lg">
    <ul class="list-disc pl-5">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
  <?php $__currentLoopData = $campos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div x-data="{ fileName: '<?php echo e($doc && $doc->$field ? basename($doc->$field) : ''); ?>' }"
         class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
      <span class="block text-sm font-semibold text-gray-700 dark:text-gray-200 mb-2">
        <?php echo e($label); ?>

      </span>

      <label for="<?php echo e($field); ?>Input"
             class="flex flex-col items-center justify-center h-32 border-2 border-dashed border-indigo-300 dark:border-gray-600 rounded-lg bg-indigo-50 dark:bg-gray-700 cursor-pointer hover:border-indigo-500 transition">
        <input id="<?php echo e($field); ?>Input"
               type="file"
               name="<?php echo e($field); ?>"
               accept=".pdf,.jpg,.jpeg,.png"
               class="hidden"
               @change="fileName = $event.target.files[0]?.name || fileName" />

        <svg xmlns="http://www.w3.org/2000/svg"
             class="w-8 h-8 text-indigo-500"
             fill="none" viewBox="0 0 24 24"
             stroke="currentColor">
          <path stroke-linecap="round"
                stroke-linejoin="round"
                stroke-width="2"
                d="M7 16l-4-4m0 0l4-4m-4 4h18" />
        </svg>

        <span class="mt-1 text-sm text-gray-600 dark:text-gray-400"
              x-text="fileName ? fileName : 'Seleccionar archivo'">
        </span>
      </label>

      
      <?php $__errorArgs = [$field];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  
  <div class="bg-white dark:bg-gray-800 p-4 rounded-lg shadow">
    <span class="block text-sm font-semibold text-gray-700 dark:text-gray-200 mb-2">
      Fecha de carga
    </span>
    <input
      type="datetime-local"
      name="fecha"
      value="<?php echo e(old('fecha', optional($doc?->fecha)->format('Y-m-d\TH:i'))); ?>"
      class="w-full px-3 py-2 bg-white dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"
    />

    <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/user_data/partials/documentos.blade.php ENDPATH**/ ?>