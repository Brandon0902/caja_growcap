<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Editar Usuario')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6">
      <?php if($errors->any()): ?>
        <div class="mb-4 text-red-600">
          <ul class="list-disc pl-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($e); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form action="<?php echo e(route('usuarios.update', $usuario)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <div class="mb-4">
          <label class="block text-gray-700 dark:text-gray-200">Nombre</label>
          <input type="text" name="name"
                 value="<?php echo e(old('name', $usuario->name)); ?>"
                 class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700
                        dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
        </div>

        <div class="mb-4">
          <label class="block text-gray-700 dark:text-gray-200">Email</label>
          <input type="email" name="email"
                 value="<?php echo e(old('email', $usuario->email)); ?>"
                 class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700
                        dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
        </div>

        <div class="mb-4">
          <label class="block text-gray-700 dark:text-gray-200">Nueva Contraseña (opcional)</label>
          <input type="password" name="password"
                 class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700
                        dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
        </div>

        <div class="mb-4">
          <label class="block text-gray-700 dark:text-gray-200">Confirmar Contraseña</label>
          <input type="password" name="password_confirmation"
                 class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700
                        dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
        </div>

        <div class="mb-4">
          <label class="block text-gray-700 dark:text-gray-200">Rol</label>
          <select name="rol"
                  class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700
                         dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500">
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($rol); ?>"
                <?php echo e(old('rol', $usuario->rol) == $rol ? 'selected' : ''); ?>>
                <?php echo e(ucfirst($rol)); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="mb-4">
          <label class="block text-gray-700 dark:text-gray-200">Activo</label>
          <select name="activo"
                  class="mt-1 border rounded px-3 py-2 bg-white dark:bg-gray-700
                         dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500">
            <option value="1" <?php echo e(old('activo', $usuario->activo)==1 ? 'selected':''); ?>>Sí</option>
            <option value="0" <?php echo e(old('activo', $usuario->activo)==0 ? 'selected':''); ?>>No</option>
          </select>
        </div>

        <div class="mb-6">
          <label class="block text-gray-700 dark:text-gray-200">Fecha de creación</label>
          <input type="datetime-local" name="fecha_creacion"
                 value="<?php echo e(old('fecha_creacion', $usuario->fecha_creacion->format('Y-m-d\TH:i'))); ?>"
                 class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700
                        dark:text-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500"/>
        </div>

        <div class="flex justify-end space-x-2">
          <a href="<?php echo e(route('usuarios.index')); ?>"
             class="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded">Cancelar</a>
          <button type="submit"
                  class="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded">
            Actualizar
          </button>
        </div>
      </form>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>