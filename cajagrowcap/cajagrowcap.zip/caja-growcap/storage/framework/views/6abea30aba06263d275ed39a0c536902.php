<div class="modal-header">
  <h5 class="modal-title">
    <?php echo e(__('Editar Abono #:id', ['id' => $abono->id])); ?>

  </h5>
  <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
</div>
<form action="<?php echo e(route('adminuserabonos.abonos.update', $abono->id)); ?>"
      method="POST" class="space-y-4 p-4">
  <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

  <div>
    <label class="block text-sm font-medium"><?php echo e(__('Tipo de Abono')); ?></label>
    <input type="text" name="tipo_abono"
           value="<?php echo e(old('tipo_abono',$abono->tipo_abono)); ?>"
           class="mt-1 block w-full border-gray-300 rounded-md"/>
  </div>

  <div>
    <label class="block text-sm font-medium"><?php echo e(__('Fecha Vencimiento')); ?></label>
    <input type="date" name="fecha_vencimiento"
           value="<?php echo e(old('fecha_vencimiento',$abono->fecha_vencimiento?->format('Y-m-d'))); ?>"
           class="mt-1 block w-full border-gray-300 rounded-md"/>
  </div>

  <div>
    <label class="block text-sm font-medium"><?php echo e(__('# Pago')); ?></label>
    <input type="number" name="num_pago"
           value="<?php echo e(old('num_pago',$abono->num_pago)); ?>"
           class="mt-1 block w-full border-gray-300 rounded-md"/>
  </div>

  <div>
    <label class="block text-sm font-medium"><?php echo e(__('Cantidad')); ?></label>
    <input type="number" step="0.01" name="cantidad"
           value="<?php echo e(old('cantidad',$abono->cantidad)); ?>"
           class="mt-1 block w-full border-gray-300 rounded-md"/>
  </div>

  <div>
    <label class="block text-sm font-medium"><?php echo e(__('Saldo Restante')); ?></label>
    <input type="number" step="0.01" name="saldo_restante"
           value="<?php echo e(old('saldo_restante',$abono->saldo_restante)); ?>"
           class="mt-1 block w-full border-gray-300 rounded-md"/>
  </div>

  <div>
    <label class="block text-sm font-medium"><?php echo e(__('Mora Generada')); ?></label>
    <input type="number" step="0.01" name="mora_generada"
           value="<?php echo e(old('mora_generada',$abono->mora_generada)); ?>"
           class="mt-1 block w-full border-gray-300 rounded-md"/>
  </div>

  <div>
    <label class="block text-sm font-medium"><?php echo e(__('Fecha')); ?></label>
    <input type="datetime-local" name="fecha"
           value="<?php echo e(old('fecha',$abono->fecha?->format('Y-m-d\TH:i'))); ?>"
           class="mt-1 block w-full border-gray-300 rounded-md"/>
  </div>

  <div>
    <label class="block text-sm font-medium"><?php echo e(__('Status')); ?></label>
    <select name="status" class="mt-1 block w-full border-gray-300 rounded-md">
      <option value="0" <?php if(old('status',$abono->status)==0): echo 'selected'; endif; ?>>
        <?php echo e(__('Pendiente')); ?>

      </option>
      <option value="1" <?php if(old('status',$abono->status)==1): echo 'selected'; endif; ?>>
        <?php echo e(__('Pagado')); ?>

      </option>
      <option value="2" <?php if(old('status',$abono->status)==2): echo 'selected'; endif; ?>>
        <?php echo e(__('Vencido')); ?>

      </option>
    </select>
  </div>

  <div class="modal-footer flex justify-end space-x-2">
    <button type="button"
            class="px-4 py-2 bg-gray-300 rounded-md hover:bg-gray-400"
            data-bs-dismiss="modal">
      <?php echo e(__('Cerrar')); ?>

    </button>
    <button type="submit"
            class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700">
      <?php echo e(__('Guardar cambios')); ?>

    </button>
  </div>
</form>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserabonos/abonos/edit_modal.blade.php ENDPATH**/ ?>