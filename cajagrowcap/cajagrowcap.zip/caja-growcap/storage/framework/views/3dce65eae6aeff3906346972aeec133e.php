
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-900 dark:text-gray-100 leading-tight">
      <?php echo e(__('Selección de Clientes para Datos')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">

    
    <?php if(session('success')): ?>
      <div class="mb-4 rounded-lg bg-green-100 p-4 text-green-800
                  dark:bg-green-900 dark:text-green-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    
    <div class="mb-4">
      <form method="GET" action="<?php echo e(route('user_data.index')); ?>" class="flex w-full">
        <input
          name="search"
          value="<?php echo e($search); ?>"
          placeholder="Buscar cliente…"
          class="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600
                 rounded-l-md bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        />
        <button
          type="submit"
          class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-r-md
                 focus:outline-none focus:ring-2 focus:ring-indigo-500"
        >
          Buscar
        </button>
      </form>
    </div>

    
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead class="bg-gray-50 dark:bg-gray-700">
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium
                       text-gray-600 dark:text-gray-300 uppercase">ID</th>
            <th class="px-6 py-3 text-left text-xs font-medium
                       text-gray-600 dark:text-gray-300 uppercase">Cliente</th>
            <th class="px-6 py-3 text-left text-xs font-medium
                       text-gray-600 dark:text-gray-300 uppercase">Estado de datos</th>
            <th class="px-6 py-3 text-right text-xs font-medium
                       text-gray-600 dark:text-gray-300 uppercase">Acciones</th>
          </tr>
        </thead>

        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
              <td class="px-6 py-4 whitespace-nowrap text-gray-700 dark:text-gray-200">
                <?php echo e($cliente->id); ?>

              </td>

              <td class="px-6 py-4 whitespace-nowrap text-gray-700 dark:text-gray-200">
                <?php echo e($cliente->nombre); ?> <?php echo e($cliente->apellido); ?>

              </td>

              <td class="px-6 py-4 whitespace-nowrap">
                <?php if($cliente->userData): ?>
                  <span class="text-green-600 dark:text-green-400">Registrado</span>
                <?php else: ?>
                  <span class="text-gray-500 dark:text-gray-400">Sin datos</span>
                <?php endif; ?>
              </td>

              <td class="px-6 py-4 whitespace-nowrap text-right">
                <a
                  href="<?php echo e(route('clientes.datos.form', $cliente)); ?>"
                  class="inline-block px-3 py-1 rounded
                         <?php echo e($cliente->userData
                              ? 'bg-blue-500 hover:bg-blue-600'
                              : 'bg-green-500 hover:bg-green-600'); ?>

                         text-white focus:outline-none focus:ring-2 focus:ring-offset-2
                         focus:ring-indigo-500 dark:focus:ring-offset-gray-800"
                >
                  <?php echo e($cliente->userData ? 'Ver / Editar' : 'Crear datos'); ?>

                </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>

    
    <div class="mt-4">
      <?php echo e($clientes->links()); ?>

    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/user_data/index.blade.php ENDPATH**/ ?>