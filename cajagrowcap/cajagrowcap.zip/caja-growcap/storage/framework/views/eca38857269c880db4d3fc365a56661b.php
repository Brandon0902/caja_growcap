
<?php
use App\Models\UserData;
// Obtenemos el UserData asociado al cliente (contiene documentos del aval)
$ud = UserData::firstWhere('id_cliente', $cliente->id);
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <div class="flex items-center justify-between">
      <h2 class="font-semibold text-xl text-white leading-tight">
        <?php echo e(__("Préstamos de")); ?> <?php echo e($cliente->nombre); ?> <?php echo e($cliente->apellido); ?>

      </h2>
      <div class="flex space-x-2">
        <a href="<?php echo e(route('user_prestamos.create')); ?>"
           class="inline-flex items-center px-3 py-2 bg-green-600 hover:bg-green-700
                  text-white text-sm font-medium rounded-md shadow-sm focus:outline-none
                  focus:ring-2 focus:ring-offset-2 focus:ring-green-500">
          <?php echo e(__('Crear Préstamo')); ?>

        </a>
        <a href="<?php echo e(route('user_prestamos.index')); ?>"
           class="inline-flex items-center px-3 py-2 bg-gray-500 hover:bg-gray-600
                  text-white text-sm font-medium rounded-md shadow-sm focus:outline-none
                  focus:ring-2 focus:ring-offset-2 focus:ring-gray-400">
          <?php echo e(__('← Volver')); ?>

        </a>
      </div>
    </div>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    <?php if(session('success')): ?>
      <div class="mb-4 rounded bg-green-100 p-4 text-green-800 dark:bg-green-900 dark:text-green-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="table-auto min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
        <thead class="bg-green-700 dark:bg-green-900">
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">#</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Cantidad</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Tipo</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Semanas</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Inicio</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Interés</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Abonos</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Mora</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Estado</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Aval</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Estado Aval</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Notificado Aval</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Documentos Aval</th>
            <th class="px-6 py-3 text-right text-xs font-medium text-white uppercase">Acciones</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          <?php $__empty_1 = true; $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e(str_pad($p->id, 3, '0', STR_PAD_LEFT)); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e(number_format($p->cantidad, 2)); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e($p->tipo_prestamo); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e($p->semanas); ?> semanas
              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e(\Carbon\Carbon::parse($p->fecha_inicio)->format('Y-m-d')); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e($p->interes_generado); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e($p->abonos_echos); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e(number_format($p->mora_acumulada, 2)); ?>

              </td>
              <td class="px-6 py-4 text-gray-900 dark:text-white">
                <?php echo e($statusOptions[$p->status] ?? '-'); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e(optional($p->aval)->nombre ?? 'Sin aval'); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e($statusOptions[$p->aval_status] ?? '-'); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e($p->aval_responded_at
                   ? \Carbon\Carbon::parse($p->aval_responded_at)->format('Y-m-d H:i')
                   : '—'); ?>

              </td>
              
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <div class="flex flex-col space-y-1 w-max">
                  <?php if($ud): ?>
                    <?php
                      $fields = [
                        'doc_solicitud_aval'        => 'Solicitud',
                        'doc_comprobante_domicilio' => 'Domicilio',
                        'doc_ine_frente'            => 'INE Frente',
                        'doc_ine_reverso'           => 'INE Reverso',
                      ];
                    ?>
                    <?php $__currentLoopData = $fields; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($ud->documento && $ud->documento->{$field}): ?>
                        <a href="<?php echo e(route('documentos.view', [$ud, $field])); ?>"
                           target="_blank"
                           class="block px-2 py-1 bg-blue-500 hover:bg-blue-600 text-white text-xs font-medium rounded">
                          <?php echo e($label); ?>

                        </a>
                      <?php else: ?>
                        <a href="<?php echo e(route('documentos.create', $ud)); ?>?field=<?php echo e($field); ?>"
                           class="block px-2 py-1 bg-gray-500 hover:bg-gray-600 text-white text-xs font-medium rounded">
                          <?php echo e($label); ?>

                        </a>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php endif; ?>
                </div>
              </td>
              <td class="px-6 py-4 text-right">
                <a href="<?php echo e(route('user_prestamos.edit', $p)); ?>"
                   class="inline-block px-3 py-1 bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-medium rounded">
                  <?php echo e(__('Editar')); ?>

                </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="14"
                  class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                <?php echo e(__('Este cliente no tiene préstamos.')); ?>

              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>

      <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right sm:px-6">
        <?php echo e($prestamos->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserprestamos/show.blade.php ENDPATH**/ ?>