<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Clientes')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8" x-data="{ search: '' }">
    <div class="mb-4 flex flex-col sm:flex-row sm:justify-between sm:items-center">
      <a href="<?php echo e(route('clientes.create')); ?>"
         class="px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-md">
        + Nuevo Cliente
      </a>
      <input type="text" x-model="search" placeholder="Buscar…"
             class="px-3 py-2 border rounded-md"/>
    </div>

    <?php if(session('success')): ?>
      <div class="mb-4 p-4 bg-green-100 text-green-800 rounded">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="bg-white shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 whitespace-nowrap">
        <thead class="bg-gray-800 text-white">
          <tr>
            <th class="px-4 py-2 text-left">ID</th>
            <th class="px-4 py-2 text-left">Código</th>
            <th class="px-4 py-2 text-left">Nombre</th>
            <th class="px-4 py-2 text-left">Email</th>
            <th class="px-4 py-2 text-left">Tipo</th>
            <th class="px-4 py-2 text-left">Status</th>
            <th class="px-4 py-2 text-left">Creado</th>
            <th class="px-4 py-2 text-left">Modif.</th>
            <th class="px-4 py-2 text-right">Acciones</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
        <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr x-show="$el.textContent.toLowerCase().includes(search.toLowerCase())">
            <td class="px-4 py-2"><?php echo e($c->id); ?></td>
            <td class="px-4 py-2"><?php echo e($c->codigo_cliente); ?></td>
            <td class="px-4 py-2"><?php echo e($c->nombre); ?> <?php echo e($c->apellido); ?></td>
            <td class="px-4 py-2"><?php echo e($c->email); ?></td>
            <td class="px-4 py-2"><?php echo e($c->tipo); ?></td>
            <td class="px-4 py-2">
              <?php if($c->status): ?>
                <span class="px-2 py-1 bg-green-100 text-green-800 rounded">Activo</span>
              <?php else: ?>
                <span class="px-2 py-1 bg-red-100 text-red-800 rounded">Inactivo</span>
              <?php endif; ?>
            </td>
            <td class="px-4 py-2"><?php echo e(optional($c->fecha)->format('d/m/Y')); ?></td>
            <td class="px-4 py-2"><?php echo e(optional($c->fecha_edit)->format('d/m/Y')); ?></td>
            <td class="px-4 py-2 text-right space-x-1">
              <a href="<?php echo e(route('clientes.show', $c)); ?>" class="text-blue-600 hover:underline">Ver</a>
              <a href="<?php echo e(route('clientes.edit', $c)); ?>" class="text-yellow-600 hover:underline">Editar</a>
              <form action="<?php echo e(route('clientes.destroy', $c)); ?>" method="POST" class="inline">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button onclick="return confirm('¿Desactivar cliente?')"
                        class="text-red-600 hover:underline">Inactivar</button>
              </form>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="9" class="px-4 py-6 text-center text-gray-500">
              No hay clientes registrados.
            </td>
          </tr>
        <?php endif; ?>
        </tbody>
      </table>
      <div class="p-4">
        <?php echo e($clientes->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminclientes/index.blade.php ENDPATH**/ ?>