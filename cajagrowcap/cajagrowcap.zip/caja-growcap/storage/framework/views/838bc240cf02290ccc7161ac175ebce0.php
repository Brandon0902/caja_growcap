
<?php
  $laboral = $userData->laboral;
?>

<div
  x-data='{
    companies: <?php echo json_encode(
      $empresas->mapWithKeys(fn($e) => [
        $e->id => [
          "direccion" => $e->direccion, "telefono"  => $e->telefono
        ]
      ]), 512) ?>,
    selected:  <?php echo json_encode(old("empresa_id", $laboral?->empresa_id  ?? ""), 512) ?>,
    direccion: <?php echo json_encode(old("direccion", $laboral?->direccion   ?? ""), 512) ?>,
    telefono:  <?php echo json_encode(old("telefono", $laboral?->telefono    ?? ""), 512) ?>
  }'
  x-init="
    if (selected) {
      direccion = companies[selected]?.direccion || '';
      telefono  = companies[selected]?.telefono  || '';
    }
  "
  x-cloak
  class="p-6 bg-gray-50 dark:bg-gray-700 rounded-b-lg"
>
  <?php if(session('success')): ?>
    <div class="mb-4 p-4 bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200 rounded">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?>

  <form
    method="POST"
    action="<?php echo e($laboral
      ? route('user_data.laborales.update', [$userData, $laboral])
      : route('user_data.laborales.store',  $userData)); ?>"
  >
    <?php echo csrf_field(); ?>
    <?php if($laboral): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

    
    <input type="hidden" name="empresa_id" x-bind:value="selected">
    <input type="hidden" name="direccion"   x-bind:value="direccion">
    <input type="hidden" name="telefono"    x-bind:value="telefono">

    <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Empresa</label>
        <select
          x-model="selected"
          @change="direccion = companies[selected]?.direccion || ''; telefono = companies[selected]?.telefono || ''"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        >
          <option value="">-- Seleccionar --</option>
          <?php $__currentLoopData = $empresas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
              value="<?php echo e($emp->id); ?>"
              <?php echo e(old('empresa_id', $laboral?->empresa_id ?? '') == $emp->id ? 'selected' : ''); ?>

            >
              <?php echo e($emp->nombre); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['empresa_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Dirección</label>
        <input
          type="text" disabled x-model="direccion"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-gray-100 dark:bg-gray-600 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Teléfono</label>
        <input
          type="text" disabled x-model="telefono"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-gray-100 dark:bg-gray-600 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        />
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Puesto</label>
        <input
          type="text" name="puesto"
          value="<?php echo e(old('puesto', $laboral?->puesto ?? '')); ?>"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        />
        <?php $__errorArgs = ['puesto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Salario Mensual</label>
        <input
          type="number" step="0.01" name="salario_mensual"
          value="<?php echo e(old('salario_mensual', $laboral?->salario_mensual ?? '')); ?>"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        />
        <?php $__errorArgs = ['salario_mensual'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Tipo Salario</label>
        <select
          name="tipo_salario"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        >
          <?php $__currentLoopData = ['Asalariado','Independiente','No hay datos']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
              value="<?php echo e($t); ?>"
              <?php echo e(old('tipo_salario', $laboral?->tipo_salario ?? '') === $t ? 'selected' : ''); ?>

            >
              <?php echo e($t); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['tipo_salario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Estado Salario</label>
        <select
          name="estado_salario"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        >
          <?php $__currentLoopData = ['Estable','Variable','Inestable']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
              value="<?php echo e($e); ?>"
              <?php echo e(old('estado_salario', $laboral?->estado_salario ?? '') === $e ? 'selected' : ''); ?>

            >
              <?php echo e($e); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['estado_salario'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Valor Tipo Salario</label>
        <input
          type="number" name="tipo_salario_valor"
          value="<?php echo e(old('tipo_salario_valor', $laboral?->tipo_salario_valor ?? '')); ?>"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        />
        <?php $__errorArgs = ['tipo_salario_valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Recurrencia Pago</label>
        <select
          name="recurrencia_pago"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        >
          <?php $__currentLoopData = ['Semanal','Quincenal','Mensual']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option
              value="<?php echo e($r); ?>"
              <?php echo e(old('recurrencia_pago', $laboral?->recurrencia_pago ?? '') === $r ? 'selected' : ''); ?>

            >
              <?php echo e($r); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['recurrencia_pago'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      
      <div>
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Valor Recurrencia</label>
        <input
          type="number" name="recurrencia_valor"
          value="<?php echo e(old('recurrencia_valor', $laboral?->recurrencia_valor ?? '')); ?>"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        />
        <?php $__errorArgs = ['recurrencia_valor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      
      <div class="sm:col-span-2">
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">Fecha Registro</label>
        <input
          type="datetime-local" name="fecha_registro"
          value="<?php echo e(old(
            'fecha_registro',
            optional($laboral?->fecha_registro)->format('Y-m-d\TH:i')
          )); ?>"
          class="mt-1 block w-full rounded border-gray-300 dark:border-gray-600
                 bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100
                 focus:ring-indigo-500 focus:border-indigo-500"
        />
        <?php $__errorArgs = ['fecha_registro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <p class="mt-1 text-sm text-red-600 dark:text-red-400"><?php echo e($message); ?></p>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>
    </div>

    <div class="mt-6 flex space-x-2">
      <button
        type="submit"
        class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded"
      >
        <?php echo e($laboral ? 'Actualizar' : 'Guardar'); ?>

      </button>

      <?php if($laboral): ?>
        <form
          action="<?php echo e(route('user_data.laborales.destroy', [$userData, $laboral])); ?>"
          method="POST"
          onsubmit="return confirm('¿Eliminar registro laboral?');"
        >
          <?php echo csrf_field(); ?>
          <?php echo method_field('DELETE'); ?>
          <button
            type="submit"
            class="px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded"
          >
            Eliminar
          </button>
        </form>
      <?php endif; ?>
    </div>
  </form>
</div>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/user_data/partials/laborales.blade.php ENDPATH**/ ?>