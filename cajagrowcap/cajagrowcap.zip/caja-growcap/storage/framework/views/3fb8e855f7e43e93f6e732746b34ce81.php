
<div class="grid grid-cols-1 sm:grid-cols-2 gap-6 mb-6">

  
  <div>
    <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
      Banco
    </label>
    <select
      name="banco"
      class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
    >
      <option value="">— Selecciona banco —</option>
      <?php
        $banks = [
          'BBVA',
          'Banamex',
          'Santander',
          'Banorte',
          'HSBC',
          'Scotiabank',
          'Inbursa',
          'Citibanamex',
          'Banco Azteca',
          'Banco del Bajío',
          'BanCoppel',
          'Banca Mifel',
          'Banco Compartamos',
        ];
      ?>
      <?php $__currentLoopData = $banks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option
          value="<?php echo e($bank); ?>"
          <?php echo e(old('banco', $userData->banco ?? '') === $bank ? 'selected' : ''); ?>

        >
          <?php echo e($bank); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    <?php $__errorArgs = ['banco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

  
  <div>
    <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
      Cuenta (máx. 16 dígitos)
    </label>
    <input
      type="text"
      name="cuenta"
      maxlength="16"
      value="<?php echo e(old('cuenta', $userData->cuenta ?? '')); ?>"
      class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100"
    />
    <?php $__errorArgs = ['cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
      <p class="text-red-600 dark:text-red-300 text-sm"><?php echo e($message); ?></p>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
  </div>

</div>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/user_data/partials/banco.blade.php ENDPATH**/ ?>