<?php
    $plansJs = $planes->map(fn($p) => [
        'id'      => $p->id_prestamo,
        'periodo' => $p->periodo,
        'semanas' => $p->semanas,
        'interes' => $p->interes,
    ]);
?>

<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Crear Préstamo (Admin)')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    <?php if($errors->any()): ?>
      <div class="mb-4 p-4 bg-red-100 text-red-800 rounded">
        <ul class="list-disc list-inside">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <li><?php echo e($e); ?></li> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?php echo e(route('user_prestamos.store')); ?>"
          method="POST"
          enctype="multipart/form-data"
          x-data='{
            plans: <?php echo json_encode($plansJs, 15, 512) ?>,
            selectedPlan: <?php echo e(json_encode(old("id_activo"))); ?>,
            cantidad:     <?php echo e(json_encode(old("cantidad"))); ?>,
            get periodo() {
              const p = this.plans.find(x => x.id === this.selectedPlan);
              return p ? p.periodo : "";
            },
            get semanas() {
              return this.plans.find(x => x.id === this.selectedPlan)?.semanas || "";
            },
            get interes() {
              const p = this.plans.find(x => x.id === this.selectedPlan);
              return p ? p.interes + "%" : "";
            },
            get interesGen() {
              if (! this.cantidad || ! this.interes) return "";
              return ((this.cantidad * parseFloat(this.interes)) / 100).toFixed(2);
            }
          }'>
      <?php echo csrf_field(); ?>

      
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Cliente')); ?></label>
        <select name="id_cliente" required
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200">
          <option value=""><?php echo e(__('-- Seleccione Cliente --')); ?></option>
          <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id); ?>" <?php if(old('id_cliente') == $c->id): echo 'selected'; endif; ?>><?php echo e($c->nombre); ?> <?php echo e($c->apellido); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Plan')); ?></label>
        <select name="id_activo" x-model.number="selectedPlan" required
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200">
          <option value=""><?php echo e(__('-- Seleccione Plan --')); ?></option>
          <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($p->id_prestamo); ?>" <?php if(old('id_activo') == $p->id_prestamo): echo 'selected'; endif; ?>>
              <?php echo e($p->periodo); ?> (<?php echo e($p->semanas); ?> <?php echo e(__('semanas')); ?>, <?php echo e($p->interes); ?>%)
            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      
      <div class="mb-4 grid grid-cols-3 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Periodo')); ?></label>
          <input x-model="periodo" disabled
                 class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200"/>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Semanas')); ?></label>
          <input x-model="semanas" disabled
                 class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200"/>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Interés %')); ?></label>
          <input x-model="interes" disabled
                 class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200"/>
        </div>
      </div>

      
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Fecha de inicio')); ?></label>
        <input type="date" name="fecha_inicio" value="<?php echo e(old('fecha_inicio')); ?>" required
               class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200"/>
      </div>

      
      <div class="mb-4 grid grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Cantidad a solicitar')); ?></label>
          <input type="number" name="cantidad" x-model.number="cantidad" step="0.01" required
                 class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200"/>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Interés generado')); ?></label>
          <input :value="interesGen" disabled
                 class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-200"/>
        </div>
      </div>

      
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Caja (de dónde sale el desembolso)')); ?></label>
        <select name="id_caja" required
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200">
          <option value=""><?php echo e(__('-- Seleccione Caja --')); ?></option>
          <?php $__empty_1 = true; $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <option value="<?php echo e($cx->id_caja); ?>" <?php if(old('id_caja') == $cx->id_caja): echo 'selected'; endif; ?>>
              <?php echo e($cx->nombre); ?>

              <?php if(!is_null($cx->saldo_final)): ?> — <?php echo e(__('Saldo:')); ?> $<?php echo e(number_format($cx->saldo_final, 2)); ?> <?php endif; ?>
            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <option value="" disabled><?php echo e(__('No hay cajas abiertas disponibles')); ?></option>
          <?php endif; ?>
        </select>
        <p class="text-xs italic text-gray-500 dark:text-gray-400 mt-1">
          <?php echo e(__('Si el estado se crea como Pagado, el desembolso se registrará como Egreso en esta caja y se generará el plan de abonos.')); ?>

        </p>
      </div>

      
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Estado inicial del préstamo')); ?></label>
        <select name="status" required
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200">
          <?php $oldStatus = old('status', 3); ?>
          <option value="1" <?php if($oldStatus==1): echo 'selected'; endif; ?>>Autorizado</option>
          <option value="2" <?php if($oldStatus==2): echo 'selected'; endif; ?>>Pendiente</option>
          <option value="3" <?php if($oldStatus==3): echo 'selected'; endif; ?>>En revisión</option>
          <option value="4" <?php if($oldStatus==4): echo 'selected'; endif; ?>>Rechazado</option>
          <option value="5" <?php if($oldStatus==5): echo 'selected'; endif; ?>>Pagado</option>
          <option value="6" <?php if($oldStatus==6): echo 'selected'; endif; ?>>Terminado</option>
        </select>
        <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
          <?php echo e(__('Si eliges “Pagado”, se generará el plan de abonos y el desembolso quedará registrado en caja automáticamente.')); ?>

        </p>
      </div>

      <hr class="my-4"/>

      
      <div class="mb-4">
        <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Código de Aval')); ?></label>
        <input type="text" name="codigo_aval" value="<?php echo e(old('codigo_aval')); ?>"
               class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200"/>
        <p class="text-xs italic text-gray-500 dark:text-gray-400">
          <?php echo e(__('Si ingresa código de aval no es necesario subir documentos.')); ?>

        </p>
      </div>

      
      <div class="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Solicitud de Aval')); ?></label>
          <input type="file" name="doc_solicitud_aval" class="mt-1 block w-full text-gray-700 dark:text-gray-200"/>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Comprobante de Domicilio')); ?></label>
          <input type="file" name="doc_comprobante_domicilio" class="mt-1 block w-full text-gray-700 dark:text-gray-200"/>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('INE Frente')); ?></label>
          <input type="file" name="doc_ine_frente" class="mt-1 block w-full text-gray-700 dark:text-gray-200"/>
        </div>
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('INE Reverso')); ?></label>
          <input type="file" name="doc_ine_reverso" class="mt-1 block w-full text-gray-700 dark:text-gray-200"/>
        </div>
      </div>

      
      <div class="flex justify-end">
        <button class="px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md shadow">
          <?php echo e(__('Crear Nuevo Préstamo')); ?>

        </button>
      </div>
    </form>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserprestamos/create.blade.php ENDPATH**/ ?>