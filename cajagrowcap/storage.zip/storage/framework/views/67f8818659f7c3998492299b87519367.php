
<label for="<?php echo e($for); ?>"
       <?php echo e($attributes->merge([
           'class' => 'block text-sm font-medium text-gray-700 dark:text-gray-300'
       ])); ?>>
    <?php echo e($value); ?>

</label>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/components/label.blade.php ENDPATH**/ ?>