
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white">
      <?php echo e(__('Cuenta #') . $cuenta->id_cuentas_por_pagar); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-5xl px-4 space-y-6">

    
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 grid grid-cols-2 gap-4">
      <div><strong>Sucursal:</strong> <?php echo e(optional($cuenta->sucursal)->nombre ?? '–'); ?></div>
      <div><strong>Caja:</strong>     <?php echo e(optional($cuenta->caja)->nombre    ?? '–'); ?></div>
      <div><strong>Proveedor:</strong><?php echo e(optional($cuenta->proveedor)->nombre ?? '–'); ?></div>
      <div><strong>Monto Total:</strong><?php echo e(number_format($cuenta->monto_total, 2)); ?></div>
      <div><strong>Tasa anual:</strong> <?php echo e($cuenta->tasa_anual); ?>%</div>
      <div><strong># de abonos:</strong> <?php echo e($cuenta->numero_abonos); ?></div>
      <div><strong>Periodo:</strong>    <?php echo e(ucfirst($cuenta->periodo_pago)); ?></div>
      <div><strong>Emisión:</strong>    <?php echo e($cuenta->fecha_emision->format('Y-m-d')); ?></div>
      <div><strong>Vencimiento:</strong><?php echo e($cuenta->fecha_vencimiento->format('Y-m-d')); ?></div>
      <div><strong>Estado:</strong>     <?php echo e(ucfirst($cuenta->estado)); ?></div>
      <div class="col-span-2"><strong>Descripción:</strong> <?php echo e($cuenta->descripcion ?? '–'); ?></div>
    </div>

    
    <div 
      x-data="{ modalPagoId: null }"
      class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6 overflow-x-auto"
    >
      <h3 class="font-semibold mb-4"><?php echo e(__('Cronograma de amortización')); ?></h3>

      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
        <thead class="bg-gray-50 dark:bg-gray-700">
          <tr>
            <th class="px-4 py-2">#</th>
            <th class="px-4 py-2">Fecha</th>
            <th class="px-4 py-2 text-right">Saldo inicial</th>
            <th class="px-4 py-2 text-right">Capital</th>
            <th class="px-4 py-2 text-right">Interés</th>
            <th class="px-4 py-2 text-right">Total pago</th>
            <th class="px-4 py-2 text-right">Saldo restante</th>
            <th class="px-4 py-2">Estado</th>
            <th class="px-4 py-2">Acción</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
          <?php $__empty_1 = true; $__currentLoopData = $cuenta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="<?php echo e($d->estado === 'vencido' ? 'bg-red-50' : ''); ?>">
              <td class="px-4 py-2 text-center"><?php echo e($d->numero_pago); ?></td>
              <td class="px-4 py-2"><?php echo e($d->fecha_pago->format('Y-m-d')); ?></td>
              <td class="px-4 py-2 text-right"><?php echo e(number_format($d->saldo_inicial,2)); ?></td>
              <td class="px-4 py-2 text-right"><?php echo e(number_format($d->amortizacion_cap,2)); ?></td>
              <td class="px-4 py-2 text-right"><?php echo e(number_format($d->pago_interes,2)); ?></td>
              <td class="px-4 py-2 text-right"><?php echo e(number_format($d->monto_pago,2)); ?></td>
              <td class="px-4 py-2 text-right"><?php echo e(number_format($d->saldo_restante,2)); ?></td>
              <td class="px-4 py-2 capitalize"><?php echo e(ucfirst($d->estado)); ?></td>
              <td class="px-4 py-2">
                <button
                  @click="modalPagoId = <?php echo e($d->id); ?>"
                  class="px-2 py-1 bg-green-600 text-white rounded hover:bg-green-700"
                  <?php echo e($d->estado === 'pagado' ? 'disabled opacity-50' : ''); ?>

                >
                  Pagar
                </button>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="9" class="px-4 py-2 text-center text-gray-500">
                <?php echo e(__('No hay abonos generados')); ?>

              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>

      
      <?php $__currentLoopData = $cuenta->detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div
        x-show="modalPagoId === <?php echo e($d->id); ?>"
        class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
      >
        <div
          class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md"
          @click.away="modalPagoId = null"
        >
          <h3 class="font-semibold text-lg mb-4">
            Abono #<?php echo e($d->numero_pago); ?> — Marcar como pagado
          </h3>

          <form action="<?php echo e(route('detalles.update', $d)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            
            <input type="hidden" name="numero_pago"      value="<?php echo e($d->numero_pago); ?>">
            <input type="hidden" name="fecha_pago"       value="<?php echo e($d->fecha_pago->toDateString()); ?>">
            <input type="hidden" name="saldo_inicial"    value="<?php echo e($d->saldo_inicial); ?>">
            <input type="hidden" name="amortizacion_cap" value="<?php echo e($d->amortizacion_cap); ?>">
            <input type="hidden" name="pago_interes"     value="<?php echo e($d->pago_interes); ?>">
            <input type="hidden" name="monto_pago"       value="<?php echo e($d->monto_pago); ?>">
            <input type="hidden" name="saldo_restante"   value="<?php echo e($d->saldo_restante); ?>">

            
            <div class="mb-4">
              <label class="block font-medium mb-1">Estado</label>
              <select name="estado" class="w-full rounded border">
                <option value="pendiente" <?php echo e($d->estado==='pendiente'?'selected':''); ?>>
                  Pendiente
                </option>
                <option value="pagado" <?php echo e($d->estado==='pagado'?'selected':''); ?>>
                  Pagado
                </option>
                <option value="vencido" <?php echo e($d->estado==='vencido'?'selected':''); ?>>
                  Vencido
                </option>
              </select>
            </div>

            
            <div class="mb-4">
              <label class="block font-medium mb-1">Caja origen</label>
              <select name="caja_id" class="w-full rounded border">
                <option value="">-- Selecciona caja --</option>
                <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option
                    value="<?php echo e($c->id_caja); ?>"
                    <?php echo e($d->caja_id === $c->id_caja ? 'selected' : ''); ?>

                  ><?php echo e($c->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            
            <div class="mb-4">
              <label class="block font-medium mb-1">Comentario</label>
              <textarea
                name="comentario"
                rows="3"
                class="w-full rounded border"
              ><?php echo e(old('comentario', $d->comentario)); ?></textarea>
            </div>

            
            <div class="flex justify-end space-x-2">
              <button
                type="button"
                @click="modalPagoId = null"
                class="px-4 py-2 bg-gray-200 rounded"
              >Cancelar</button>
              <button
                type="submit"
                class="px-4 py-2 bg-green-600 text-white rounded"
              >Guardar</button>
            </div>
          </form>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/cuentas_por_pagar/show.blade.php ENDPATH**/ ?>