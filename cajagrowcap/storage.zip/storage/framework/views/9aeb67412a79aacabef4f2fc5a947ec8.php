
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
      <?php echo e(__('Abonos (todas las cuentas por pagar)')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-6">

    
    <form id="filters" method="GET" class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow grid grid-cols-1 md:grid-cols-6 gap-3">
      <div>
        <label class="block text-sm mb-1">Estado</label>
        <select name="estado" class="w-full rounded-md dark:bg-gray-900">
          <option value="">— Todos —</option>
          <?php $__currentLoopData = ['pendiente','pagado','vencido']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($e); ?>" <?php if(request('estado')===$e): echo 'selected'; endif; ?>><?php echo e(ucfirst($e)); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <div>
        <label class="block text-sm mb-1">Sucursal</label>
        <select name="sucursal_id" class="w-full rounded-md dark:bg-gray-900">
          <option value="">— Todas —</option>
          <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($s->id_sucursal); ?>" <?php if(request('sucursal_id')==$s->id_sucursal): echo 'selected'; endif; ?>>
              <?php echo e($s->nombre); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>

      <div>
        <label class="block text-sm mb-1">Desde</label>
        <input type="date" name="desde" value="<?php echo e(request('desde')); ?>" class="w-full rounded-md dark:bg-gray-900">
      </div>

      <div>
        <label class="block text-sm mb-1">Hasta</label>
        <input type="date" name="hasta" value="<?php echo e(request('hasta')); ?>" class="w-full rounded-md dark:bg-gray-900">
      </div>

      <div class="md:col-span-2">
        <label class="block text-sm mb-1">Buscar (proveedor / comentario / descripción)</label>

        
        <div
          x-data="{
            q: <?php echo \Illuminate\Support\Js::from(request('q'))->toHtml() ?>,
            loading: false,
            init() {
              const form   = document.getElementById('filters');
              const target = document.getElementById('cppd-results');

              // auto buscar al cambiar selects/fechas
              form?.addEventListener('change', () => this.refresh());

              // interceptar paginación/links dentro del contenedor
              target?.addEventListener('click', (e) => {
                const a = e.target.closest('a');
                if (!a || !a.href) return;
                e.preventDefault();
                this.fetchTo(a.href, target);
              });
            },
            buildUrl() {
              const form   = document.getElementById('filters');
              const action = <?php echo \Illuminate\Support\Js::from(route('cuentas-por-pagar.detalles.index'))->toHtml() ?>;
              const params = new URLSearchParams(form ? new FormData(form) : {});
              params.set('q', this.q ?? '');
              // opcional para controladores que devuelven solo parcial
              params.set('ajax','1');
              return `${action}?${params.toString()}`;
            },
            async refresh() {
              const target = document.getElementById('cppd-results');
              await this.fetchTo(this.buildUrl(), target);
            },
            async fetchTo(url, target) {
              this.loading = true;
              try {
                const res  = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
                const text = await res.text();

                // Intentar extraer solo #cppd-results del HTML recibido.
                let htmlToInject = text;
                try {
                  const doc = new DOMParser().parseFromString(text, 'text/html');
                  const frag = doc.querySelector('#cppd-results');
                  if (frag) htmlToInject = frag.innerHTML;
                } catch(_) {}

                if (target) {
                  target.innerHTML = htmlToInject;
                  // Re-inicializa Alpine en lo recién inyectado (para modales)
                  if (window.Alpine && Alpine.initTree) Alpine.initTree(target);
                }

                // Actualiza URL visible (sin ajax=1)
                const u = new URL(url, window.location.origin);
                u.searchParams.delete('ajax');
                history.replaceState({}, '', u);
              } catch(err) {
                console.error('live search error', err);
              } finally {
                this.loading = false;
              }
            }
          }"
        >
          <div class="relative">
            <input
              type="text"
              name="q"
              x-model="q"
              @input.debounce.400ms="refresh()"
              placeholder="Ej. Proveedor XYZ"
              class="w-full rounded-md dark:bg-gray-900 pr-8"
              autocomplete="off"
            />
            
            <svg x-show="loading" class="h-5 w-5 animate-spin absolute right-2 top-2.5 opacity-70" viewBox="0 0 24 24">
              <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none" opacity=".25"></circle>
              <path d="M22 12a10 10 0 0 1-10 10" fill="currentColor"></path>
            </svg>
          </div>
        </div>
      </div>

      
      <div class="md:col-span-6 mt-2">
        <div class="flex flex-wrap items-center gap-6 px-3 py-2 rounded-lg bg-gray-50 dark:bg-gray-900/40 border border-gray-200 dark:border-gray-700">
          <div class="text-lg font-semibold">
            Cuentas: <?php echo e(number_format($resumen['cuentas'])); ?>

          </div>

          <div class="flex items-center gap-2 text-red-700 dark:text-red-400 text-lg font-semibold">
            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M12 9v3m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" />
            </svg>
            <span>Saldo Vencido: $<?php echo e(number_format($resumen['saldo_vencido'], 2)); ?></span>
          </div>

          <div class="text-lg font-semibold">
            Saldo Pendiente: $<?php echo e(number_format($resumen['saldo_pendiente'], 2)); ?>

          </div>

          <div class="ml-auto flex gap-2">
            <a href="<?php echo e(route('cuentas-por-pagar.detalles.index')); ?>"
               class="px-4 py-2 rounded-lg bg-gray-200 dark:bg-gray-700">Limpiar</a>
            <button class="px-4 py-2 rounded-lg bg-indigo-600 text-white hover:bg-indigo-700">
              Filtrar
            </button>
          </div>
        </div>
      </div>
    </form>

    
    <div id="cppd-results">
      <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow overflow-x-auto"
           x-data="{ modalPagoId: null }">

        <table class="min-w-full text-sm">
          <thead>
            <tr class="bg-gray-50 dark:bg-gray-900/40">
              <th class="px-3 py-2 text-left">#Cuenta</th>
              <th class="px-3 py-2 text-left">Proveedor</th>
              <th class="px-3 py-2 text-left">Sucursal</th>
              <th class="px-3 py-2 text-left"># Pago</th>
              <th class="px-3 py-2 text-left">Fecha</th>
              <th class="px-3 py-2 text-right">Monto</th>
              
              
              <th class="px-3 py-2 text-right">Saldo Rest.</th>
              <th class="px-3 py-2 text-left">Estado</th>
              <th class="px-3 py-2 text-left">Caja</th>
              <th class="px-3 py-2 text-left">Comentario</th>
              <th class="px-3 py-2 text-left">Descripción</th>
              <th class="px-3 py-2 text-left">Acciones</th>
            </tr>
          </thead>
          <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="border-t border-gray-200 dark:border-gray-700 <?php echo e($d->estado==='vencido' ? 'bg-red-50/40 dark:bg-red-900/10' : ''); ?>">
              <td class="px-3 py-2"><?php echo e($d->cuenta?->id_cuentas_por_pagar ?? '—'); ?></td>
              <td class="px-3 py-2"><?php echo e($d->cuenta?->proveedor?->nombre ?? '—'); ?></td>
              <td class="px-3 py-2"><?php echo e($d->cuenta?->sucursal?->nombre ?? '—'); ?></td>
              <td class="px-3 py-2"><?php echo e($d->numero_pago); ?></td>
              <td class="px-3 py-2"><?php echo e(\Carbon\Carbon::parse($d->fecha_pago)->format('Y-m-d')); ?></td>
              <td class="px-3 py-2 text-right"><?php echo e(number_format($d->monto_pago, 2)); ?></td>
              
              
              <td class="px-3 py-2 text-right"><?php echo e(number_format($d->saldo_restante, 2)); ?></td>
              <td class="px-3 py-2">
                <span class="px-2 py-0.5 rounded text-xs
                  class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'bg-yellow-100 text-yellow-800'   => $d->estado==='pendiente',
                    'bg-red-100 text-red-800'         => $d->estado==='vencido',
                    'bg-emerald-100 text-emerald-800' => $d->estado==='pagado',
                  ]); ?>"">
                  <?php echo e(ucfirst($d->estado)); ?>

                </span>
              </td>
              <td class="px-3 py-2"><?php echo e($d->caja?->nombre ?? '—'); ?></td>
              <td class="px-3 py-2"><?php echo e($d->comentario ?? '—'); ?></td>
              <td class="px-3 py-2"><?php echo e($d->cuenta?->descripcion ?? '—'); ?></td>
              <td class="px-3 py-2">
                <div class="flex items-center gap-3">
                  <?php if($d->cuenta): ?>
                    <a class="text-indigo-600 hover:underline"
                       href="<?php echo e(route('cuentas-por-pagar.show', $d->cuenta)); ?>">
                      Ver cuenta
                    </a>
                  <?php endif; ?>

                  
                  <button
                    @click="modalPagoId = <?php echo e($d->id); ?>"
                    class="text-green-700 hover:underline disabled:opacity-50"
                    <?php echo e($d->estado === 'pagado' ? 'disabled' : ''); ?>

                  >
                    Pagar
                  </button>

                  <?php if(Route::has('cuentas-por-pagar.detalles.edit')): ?>
                    <a class="text-blue-600 hover:underline"
                       href="<?php echo e(route('cuentas-por-pagar.detalles.edit', $d)); ?>">
                      Editar
                    </a>
                  <?php endif; ?>
                </div>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="12" class="px-3 py-6 text-center text-gray-500">
                No hay abonos para los filtros seleccionados.
              </td>
            </tr>
          <?php endif; ?>
          </tbody>
        </table>

        <div class="mt-4">
          <?php echo e($detalles->links()); ?>

        </div>

        
        <?php $__currentLoopData = $detalles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div
            x-show="modalPagoId === <?php echo e($d->id); ?>"
            x-cloak
            class="fixed inset-0 flex items-center justify-center bg-black/50 z-50"
          >
            <div
              class="bg-white dark:bg-gray-800 rounded-lg p-6 w-full max-w-md"
              @click.away="modalPagoId = null"
            >
              <h3 class="font-semibold text-lg mb-4">
                Abono #<?php echo e($d->numero_pago); ?> — Marcar como pagado
              </h3>

              <form action="<?php echo e(route('detalles.update', $d)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <input type="hidden" name="numero_pago"      value="<?php echo e($d->numero_pago); ?>">
                <input type="hidden" name="fecha_pago"       value="<?php echo e(\Carbon\Carbon::parse($d->fecha_pago)->toDateString()); ?>">
                <input type="hidden" name="saldo_inicial"    value="<?php echo e($d->saldo_inicial); ?>">
                <input type="hidden" name="amortizacion_cap" value="<?php echo e($d->amortizacion_cap); ?>">
                <input type="hidden" name="pago_interes"     value="<?php echo e($d->pago_interes); ?>">
                <input type="hidden" name="monto_pago"       value="<?php echo e($d->monto_pago); ?>">
                <input type="hidden" name="saldo_restante"   value="<?php echo e($d->saldo_restante); ?>">

                
                <div class="mb-4">
                  <label class="block font-medium mb-1">Estado</label>
                  <select name="estado" class="w-full rounded border dark:bg-gray-900">
                    <option value="pendiente" <?php echo e($d->estado==='pendiente'?'selected':''); ?>>Pendiente</option>
                    <option value="pagado"    <?php echo e($d->estado==='pagado'?'selected':''); ?>>Pagado</option>
                    <option value="vencido"   <?php echo e($d->estado==='vencido'?'selected':''); ?>>Vencido</option>
                  </select>
                </div>

                
                <div class="mb-4">
                  <label class="block font-medium mb-1">Caja origen</label>
                  <select name="caja_id" class="w-full rounded border dark:bg-gray-900">
                    <option value="">-- Selecciona caja --</option>
                    <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <option value="<?php echo e($c->id_caja); ?>" <?php echo e($d->caja_id === $c->id_caja ? 'selected' : ''); ?>>
                        <?php echo e($c->nombre); ?>

                      </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>

                
                <div class="mb-4">
                  <label class="block font-medium mb-1">Comentario</label>
                  <textarea name="comentario" rows="3" class="w-full rounded border dark:bg-gray-900"><?php echo e(old('comentario', $d->comentario)); ?></textarea>
                </div>

                <div class="flex justify-end gap-2">
                  <button type="button" @click="modalPagoId = null" class="px-4 py-2 bg-gray-200 dark:bg-gray-700 rounded">
                    Cancelar
                  </button>
                  <button type="submit" class="px-4 py-2 bg-green-600 text-white rounded">
                    Guardar
                  </button>
                </div>
              </form>
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/cuentas_por_pagar/detalles/index.blade.php ENDPATH**/ ?>