
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Clientes')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <style>[x-cloak]{display:none!important}</style>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{
         search: '',
         typing: false,
         clear(){ this.search=''; }
       }">

    <div class="mb-4 flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
      <a href="<?php echo e(route('clientes.create')); ?>"
         class="px-4 py-2 bg-yellow-500 hover:bg-yellow-600 text-white rounded-md shadow">
        + <?php echo e(__('Nuevo Cliente')); ?>

      </a>

      <div class="flex items-center gap-2 w-full sm:w-auto">
        <div class="relative flex-1 sm:w-96">
          <input type="text"
                 x-model.debounce.400ms="search"
                 @input="typing = true; setTimeout(()=>typing=false, 350)"
                 placeholder="<?php echo e(__('Buscar por nombre / email / código / tipo…')); ?>"
                 class="w-full px-3 py-2 border rounded-md shadow-sm
                        focus:outline-none focus:ring-2 focus:ring-purple-500
                        bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"/>
          
          <svg x-cloak x-show="typing"
               class="h-5 w-5 animate-spin absolute right-3 top-2.5 opacity-70"
               viewBox="0 0 24 24">
            <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none" opacity=".25"></circle>
            <path d="M22 12a10 10 0 0 1-10 10" fill="currentColor"></path>
          </svg>
        </div>

        <button @click="clear()"
                class="px-3 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800
                       dark:bg-gray-700 dark:text-gray-200 rounded-md">
          <?php echo e(__('Limpiar')); ?>

        </button>
      </div>
    </div>

    <?php if(session('success')): ?>
      <div class="mb-4 p-4 rounded bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-100">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
        <thead class="bg-gray-800 text-white dark:bg-gray-900">
          <tr>
            <th class="px-4 py-2 text-left text-xs font-medium uppercase">ID</th>
            <th class="px-4 py-2 text-left text-xs font-medium uppercase">Código</th>
            <th class="px-4 py-2 text-left text-xs font-medium uppercase">Nombre</th>
            <th class="px-4 py-2 text-left text-xs font-medium uppercase">Email</th>
            <th class="px-4 py-2 text-left text-xs font-medium uppercase">Tipo</th>
            <th class="px-4 py-2 text-left text-xs font-medium uppercase">Status</th>
            <th class="px-4 py-2 text-left text-xs font-medium uppercase">Creado</th>
            <th class="px-4 py-2 text-left text-xs font-medium uppercase">Modif.</th>
            <th class="px-4 py-2 text-right text-xs font-medium uppercase">Acciones</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
          <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr
              x-show="($el.textContent || '').toLowerCase().includes((search || '').toLowerCase())"
              class="hover:bg-gray-50 dark:hover:bg-gray-700"
            >
              <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e($c->id); ?></td>
              <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e($c->codigo_cliente); ?></td>
              <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                <?php echo e($c->nombre); ?> <?php echo e($c->apellido); ?>

              </td>
              <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e($c->email); ?></td>
              <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e($c->tipo); ?></td>
              <td class="px-4 py-2">
                <?php if($c->status): ?>
                  <span class="px-2 py-1 bg-green-100 text-green-800 rounded text-xs font-semibold">
                    <?php echo e(__('Activo')); ?>

                  </span>
                <?php else: ?>
                  <span class="px-2 py-1 bg-red-100 text-red-800 rounded text-xs font-semibold">
                    <?php echo e(__('Inactivo')); ?>

                  </span>
                <?php endif; ?>
              </td>
              <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e(optional($c->fecha)->format('d/m/Y')); ?></td>
              <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e(optional($c->fecha_edit)->format('d/m/Y')); ?></td>
              <td class="px-4 py-2 text-right space-x-2">
                <a href="<?php echo e(route('clientes.show', $c)); ?>" class="text-blue-600 hover:underline">
                  <?php echo e(__('Ver')); ?>

                </a>
                <a href="<?php echo e(route('clientes.edit', $c)); ?>" class="text-yellow-600 hover:underline">
                  <?php echo e(__('Editar')); ?>

                </a>
                <form action="<?php echo e(route('clientes.destroy', $c)); ?>" method="POST" class="inline">
                  <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                  <button onclick="return confirm('<?php echo e(__('¿Desactivar cliente?')); ?>')"
                          class="text-red-600 hover:underline">
                    <?php echo e(__('Inactivar')); ?>

                  </button>
                </form>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="9" class="px-4 py-6 text-center text-gray-500 dark:text-gray-400">
                <?php echo e(__('No hay clientes registrados.')); ?>

              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>

      <div class="p-4">
        <?php echo e($clientes->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminclientes/index.blade.php ENDPATH**/ ?>