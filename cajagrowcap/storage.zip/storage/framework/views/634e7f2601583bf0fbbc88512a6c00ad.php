<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Ahorros (todos)')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{
         search: '<?php echo e($search ?? ''); ?>',
         status: '<?php echo e($status ?? ''); ?>',
         desde:  '<?php echo e($desde  ?? ''); ?>',
         hasta:  '<?php echo e($hasta  ?? ''); ?>',
         orden:  '<?php echo e($orden  ?? 'fecha_desc'); ?>'
       }">
    <?php if(session('success')): ?>
      <div class="mb-4 rounded-lg bg-green-100 dark:bg-green-900 p-4 text-green-800 dark:text-green-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    
    <div class="mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-sm">
      <input type="text" x-model="search" placeholder="<?php echo e(__('Buscar por cliente / # / monto / plan…')); ?>"
             class="px-2 py-1 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500
                    bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="status"
              class="px-2 py-1 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($key); ?>" <?php if((string)($status ?? '') === (string)($key ?? '')): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <input type="date" x-model="desde"
             class="px-2 py-1 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />
      <input type="date" x-model="hasta"
             class="px-2 py-1 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="orden"
              class="px-2 py-1 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="fecha_desc"><?php echo e(__('Más recientes')); ?></option>
        <option value="fecha_asc"><?php echo e(__('Más antiguos')); ?></option>
        <option value="monto_desc"><?php echo e(__('Monto ↓')); ?></option>
        <option value="monto_asc"><?php echo e(__('Monto ↑')); ?></option>
      </select>

      <button
        @click="window.location = '<?php echo e(route('user_ahorros.index')); ?>'
          + `?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status ?? '')}
              &desde=${encodeURIComponent(desde ?? '')}&hasta=${encodeURIComponent(hasta ?? '')}
              &orden=${encodeURIComponent(orden)}`"
        class="px-3 py-1 bg-purple-600 hover:bg-purple-700 text-white rounded-md shadow text-sm">
        <?php echo e(__('Filtrar')); ?>

      </button>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg">
      <div class="overflow-x-auto max-w-full">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap text-sm">
          <thead class="bg-purple-700 dark:bg-purple-900 text-xs">
            <tr>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">#</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Cliente</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Plan</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Monto</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">% Rend.</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Rend. Gen.</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Fecha</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Status</th>
              <th class="px-3 py-2 text-left font-medium text-white uppercase">Caja</th>
              <th class="px-3 py-2 text-right font-medium text-white uppercase">Acciones</th>
            </tr>
          </thead>

          <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            <?php $__empty_1 = true; $__currentLoopData = $ahorros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                <td class="px-3 py-2 text-gray-700 dark:text-gray-200"><?php echo e(str_pad($a->id, 3, '0', STR_PAD_LEFT)); ?></td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200 truncate max-w-[150px]" title="<?php echo e(optional($a->cliente)->email); ?>">
                  <?php echo e(optional($a->cliente)->nombre); ?> <?php echo e(optional($a->cliente)->apellido); ?>

                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($a->ahorro)->tipo_ahorro ?? $a->tipo ?? '—'); ?>

                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  $<?php echo e(number_format($a->monto_ahorro, 2)); ?>

                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(number_format($a->rendimiento, 2)); ?>%
                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  $<?php echo e(number_format($a->rendimiento_generado, 2)); ?>

                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(\Carbon\Carbon::parse($a->fecha_inicio)->format('Y-m-d')); ?>

                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e([5=>'Depositado',6=>'Retirado'][$a->status] ?? '—'); ?>

                </td>

                <td class="px-3 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($a->caja)->nombre ?? '—'); ?>

                </td>

                <td class="px-3 py-2 text-right">
                  <a href="<?php echo e(route('user_ahorros.show', $a->id)); ?>"
                     class="px-2 py-1 bg-yellow-500 hover:bg-yellow-600 text-white rounded text-xs">
                    <?php echo e(__('Ver')); ?>

                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="10" class="px-3 py-4 text-center text-gray-500 dark:text-gray-400 text-sm">
                  <?php echo e(__('No hay ahorros registrados.')); ?>

                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="px-3 py-2 text-right bg-gray-50 dark:bg-gray-700 sm:px-4 text-sm">
        <?php echo e($ahorros->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserahorros/index.blade.php ENDPATH**/ ?>