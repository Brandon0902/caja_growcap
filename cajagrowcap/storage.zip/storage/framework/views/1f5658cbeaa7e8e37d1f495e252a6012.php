
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      Retiros
    </h2>
   <?php $__env->endSlot(); ?>

  <?php
    $statusLabels = [
      0 => 'Solicitado',
      1 => 'Aprobado',
      2 => 'Pagado',
      3 => 'Rechazado',
    ];
    $initTab = request('tab', $tab ?? 'inv'); // 'inv' | 'ahorro'
  ?>

  <style>[x-cloak]{display:none!important}</style>

  <div
    class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
    x-data="{
      tab: '<?php echo e($initTab); ?>',
      search: <?php echo \Illuminate\Support\Js::from($search ?? '')->toHtml() ?>,
      openModal: false,
      modalData: { action:'', tipo:'', cantidad:'', fecha:'', status:'' }
    }"
  >
    
    <div class="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
      <input
        type="text"
        x-model="search"
        @input.debounce.500ms="
          window.location = '<?php echo e(route('retiros.index')); ?>'
            + '?search=' + encodeURIComponent(search)
            + '&tab=' + tab
        "
        placeholder="Buscar por cliente, email, ID o tipo…"
        class="px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-600
               bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 w-full sm:w-96"
      />

      <div class="flex border-b border-gray-200 dark:border-gray-700">
        <button
          @click="tab = 'inv'; window.history.replaceState({}, '', '?search=' + encodeURIComponent(search) + '&tab=inv')"
          :class="tab === 'inv' ? 'border-green-600 text-green-600' : 'text-gray-500 dark:text-gray-400'"
          class="py-2 px-4 border-b-2 focus:outline-none">
          Retiros de Inversión
        </button>
        <button
          @click="tab = 'ahorro'; window.history.replaceState({}, '', '?search=' + encodeURIComponent(search) + '&tab=ahorro')"
          :class="tab === 'ahorro' ? 'border-green-600 text-green-600' : 'text-gray-500 dark:text-gray-400'"
          class="py-2 px-4 border-b-2 focus:outline-none">
          Retiros de Ahorro
        </button>
      </div>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6 space-y-6">

      
      <template x-if="tab === 'inv'">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
            <thead class="bg-green-600 dark:bg-green-800">
              <tr>
                <?php $__currentLoopData = ['Solicitud','Cliente','Monto','Fecha Solicitud','Días','Status','Acciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($col); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              <?php $__empty_1 = true; $__currentLoopData = $retirosInv; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">#<?php echo e($r->id); ?></td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    <?php echo e($r->cliente_nombre); ?> <?php echo e($r->cliente_apellido); ?>

                    <div class="text-xs text-gray-500"><?php echo e($r->cliente_email); ?></div>
                  </td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    $<?php echo e(number_format((float)$r->cantidad, 2)); ?>

                  </td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    <?php echo e(\Carbon\Carbon::parse($r->fecha_solicitud)->format('Y-m-d')); ?>

                  </td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    <?php echo e(\Carbon\Carbon::parse($r->fecha_solicitud)->diffInDays(now())); ?>

                  </td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    <?php echo e($statusLabels[$r->status] ?? $r->status); ?>

                  </td>
                  <td class="px-6 py-4 text-right">
                    <button
                      @click="
                        modalData = {
                          action: '<?php echo e(route('retiros.inversion.update', $r->id)); ?>',
                          tipo: <?php echo \Illuminate\Support\Js::from($r->tipo)->toHtml() ?>,
                          cantidad: <?php echo e((float) $r->cantidad); ?>,
                          fecha: <?php echo \Illuminate\Support\Js::from($r->fecha_solicitud)->toHtml() ?>,
                          status: <?php echo e((int) $r->status); ?>

                        };
                        openModal = true;
                      "
                      class="inline-flex items-center px-3 py-2 bg-green-500 hover:bg-green-600 text-white text-sm font-medium rounded-md">
                      Editar
                    </button>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="7" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                    No hay retiros de inversión.
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>

          <div class="mt-4">
            <?php echo e($retirosInv->appends(['search' => $search, 'tab' => 'inv'])->links()); ?>

          </div>
        </div>
      </template>

      
      <template x-if="tab === 'ahorro'">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
            <thead class="bg-green-600 dark:bg-green-800">
              <tr>
                <?php $__currentLoopData = ['Solicitud','Cliente','Monto','Fecha Solicitud','Días','Status','Acciones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $col): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e($col); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              <?php $__empty_1 = true; $__currentLoopData = $retirosAh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">#<?php echo e($r->id); ?></td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    <?php echo e($r->cliente_nombre); ?> <?php echo e($r->cliente_apellido); ?>

                    <div class="text-xs text-gray-500"><?php echo e($r->cliente_email); ?></div>
                  </td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    $<?php echo e(number_format((float)$r->cantidad, 2)); ?>

                  </td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    <?php echo e(\Carbon\Carbon::parse($r->fecha_solicitud)->format('Y-m-d')); ?>

                  </td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    <?php echo e(\Carbon\Carbon::parse($r->fecha_solicitud)->diffInDays(now())); ?>

                  </td>
                  <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                    <?php echo e($statusLabels[$r->status] ?? $r->status); ?>

                  </td>
                  <td class="px-6 py-4 text-right">
                    <button
                      @click="
                        modalData = {
                          action: '<?php echo e(route('retiros.ahorro.update', $r->id)); ?>',
                          tipo: <?php echo \Illuminate\Support\Js::from($r->tipo)->toHtml() ?>,
                          cantidad: <?php echo e((float) $r->cantidad); ?>,
                          fecha: <?php echo \Illuminate\Support\Js::from($r->fecha_solicitud)->toHtml() ?>,
                          status: <?php echo e((int) $r->status); ?>

                        };
                        openModal = true;
                      "
                      class="inline-flex items-center px-3 py-2 bg-green-500 hover:bg-green-600 text-white text-sm font-medium rounded-md">
                      Editar
                    </button>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="7" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                    No hay retiros de ahorro.
                  </td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>

          <div class="mt-4">
            <?php echo e($retirosAh->appends(['search' => $search, 'tab' => 'ahorro'])->links()); ?>

          </div>
        </div>
      </template>

      
      <div
        x-cloak
        x-show="openModal"
        x-transition.opacity
        class="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50"
      >
        <div class="bg-white dark:bg-gray-800 rounded-lg w-full max-w-lg p-6">
          <div class="flex justify-between items-center mb-4">
            <h3 class="text-lg font-semibold text-gray-900 dark:text-gray-100">
              Aprobar Retiro
            </h3>
            <button @click="openModal = false"
                    class="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300">
              &times;
            </button>
          </div>

          <form :action="modalData.action" method="POST" class="space-y-4">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>

            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                Tipo de Retiro
              </label>
              <select
                name="tipo"
                x-model="modalData.tipo"
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm
                       focus:ring-green-500 focus:border-green-500 bg-white dark:bg-gray-700
                       text-gray-900 dark:text-gray-100"
                required
              >
                <option value="Transferencia">Transferencia</option>
                <option value="Efectivo">Efectivo</option>
              </select>
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                Cantidad
              </label>
              <input
                type="number"
                name="cantidad"
                x-model.number="modalData.cantidad"
                step="0.01"
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm
                       focus:ring-green-500 focus:border-green-500 bg-white dark:bg-gray-700
                       text-gray-900 dark:text-gray-100"
                required
              />
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                Fecha Solicitud
              </label>
              <input
                type="text"
                name="fecha_solicitud"
                x-model="modalData.fecha"
                readonly
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm
                       bg-gray-100 dark:bg-gray-600 text-gray-700 dark:text-gray-200"
              />
            </div>

            <div>
              <label class="block text-sm font-medium text-gray-700 dark:text-gray-200">
                Status
              </label>
              <select
                name="status"
                x-model="modalData.status"
                class="mt-1 block w-full border-gray-300 dark:border-gray-600 rounded-md shadow-sm
                       focus:ring-green-500 focus:border-green-500 bg-white dark:bg-gray-700
                       text-gray-900 dark:text-gray-100"
                required
              >
                <option value="">--</option>
                <option value="0">Solicitado</option>
                <option value="1">Aprobado</option>
                <option value="2">Pagado</option>
                <option value="3">Rechazado</option>
              </select>
            </div>

            <div class="pt-4 flex justify-end gap-2">
              <button
                type="button"
                @click="openModal = false"
                class="px-4 py-2 bg-gray-300 dark:bg-gray-600 text-gray-700 dark:text-gray-200 rounded-md"
              >
                Cancelar
              </button>
              <button
                type="submit"
                class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md"
              >
                Guardar
              </button>
            </div>
          </form>
        </div>
      </div>
      

    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/retiros/index.blade.php ENDPATH**/ ?>