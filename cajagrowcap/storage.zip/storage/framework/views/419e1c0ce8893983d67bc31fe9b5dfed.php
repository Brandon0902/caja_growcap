<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Préstamos de :name', ['name' => $cliente->nombre . ' ' . $cliente->apellido])); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 table-auto">
        <thead class="bg-green-600 dark:bg-green-800">
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">ID</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Período</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Monto</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Interés</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Fecha</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Status</th>
            <th class="px-6 py-3 text-right text-xs font-medium text-white uppercase">Acciones</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          <?php $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e(str_pad($p->id, 3, '0', STR_PAD_LEFT)); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e($p->tipo_prestamo); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                $<?php echo e(number_format($p->cantidad, 2)); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e($p->interes); ?>%
              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e(\Carbon\Carbon::parse($p->fecha_solicitud)->format('Y-m-d')); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php
                  $labels = [
                    1 => 'Autorizado',
                    2 => 'Pendiente',
                    3 => 'En revisión',
                    4 => 'Rechazado',
                    5 => 'Pagado',
                    6 => 'Terminado',
                  ];
                ?>
                <?php echo e($labels[$p->status] ?? $p->status); ?>

              </td>
              <td class="px-6 py-4 text-right">
                <a
                  href="<?php echo e(route('adminuserabonos.abonos.index', $p->id)); ?>"
                  class="inline-flex items-center px-3 py-2 bg-green-500 hover:bg-green-600 text-white text-sm font-medium rounded-md transition"
                >
                  <svg xmlns="http://www.w3.org/2000/svg"
                       class="h-4 w-4 mr-1"
                       fill="none" viewBox="0 0 24 24"
                       stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round"
                          d="M9 5l7 7-7 7" />
                  </svg>
                  <?php echo e(__('Ver Detalles')); ?>

                </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>

      <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right sm:px-6">
        <?php echo e($prestamos->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserabonos/prestamos/index.blade.php ENDPATH**/ ?>