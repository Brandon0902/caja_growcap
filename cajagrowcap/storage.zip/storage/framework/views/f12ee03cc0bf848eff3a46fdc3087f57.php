<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <div class="flex flex-wrap items-center justify-start gap-3">
      <?php if (\Illuminate\Support\Facades\Blade::check('role', 'admin')): ?>
        <a href="<?php echo e(route('depositos.create')); ?>"
           class="inline-flex items-center px-3 py-2 bg-green-600 hover:bg-green-700
                  text-white text-sm font-medium rounded-md shadow">
          <?php echo e(__('+ Nuevo depósito (emergencia)')); ?>

        </a>
      <?php endif; ?>

      <h2 class="font-semibold text-xl text-white leading-tight">
        <?php echo e(__('Depósitos')); ?>

      </h2>
    </div>
   <?php $__env->endSlot(); ?>

  <style>[x-cloak]{ display:none!important; }</style>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="depositosIndexPage()">

    <?php if(session('success')): ?>
      <div class="mb-4 rounded-lg bg-green-100 dark:bg-green-900 p-4 text-green-800 dark:text-green-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    
    <div class="mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
      <div class="relative">
        <input type="text"
               x-model="search"
               @input.debounce.400ms="liveSearch()"
               @keydown.enter.prevent
               placeholder="<?php echo e(__('Buscar por cliente / # / nota / monto…')); ?>"
               class="w-full px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500
                      bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />
        
        <svg x-show="loading" class="h-5 w-5 animate-spin absolute right-3 top-2.5 opacity-70" viewBox="0 0 24 24">
          <circle cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4" fill="none" opacity=".25"></circle>
          <path d="M22 12a10 10 0 0 1-10 10" fill="currentColor"></path>
        </svg>
      </div>

      <select x-model="status" @change="liveSearch()"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($key); ?>" <?php if((string)($status ?? '') === (string)($key ?? '')): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <input type="date" x-model="desde" @change="liveSearch()"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />
      <input type="date" x-model="hasta" @change="liveSearch()"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="orden" @change="liveSearch()"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="fecha_desc"><?php echo e(__('Más recientes')); ?></option>
        <option value="fecha_asc"><?php echo e(__('Más antiguos')); ?></option>
        <option value="monto_desc"><?php echo e(__('Monto ↓')); ?></option>
        <option value="monto_asc"><?php echo e(__('Monto ↑')); ?></option>
      </select>

      <button
        @click="go()"
        class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md shadow">
        <?php echo e(__('Filtrar')); ?>

      </button>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg" id="depositos-results">
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
          <thead class="bg-green-700 dark:bg-green-900">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">#</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Cliente</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Monto</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Fecha</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Status</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Caja</th>
              <th class="px-6 py-3 text-right text-xs font-medium text-white uppercase">Acciones</th>
            </tr>
          </thead>
          <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            <?php $__empty_1 = true; $__currentLoopData = $depositos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dep): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr class="hover:bg-gray-100 dark:hover:bg-gray-700">
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200"><?php echo e(str_pad($dep->id, 3, '0', STR_PAD_LEFT)); ?></td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($dep->cliente)->nombre); ?> <?php echo e(optional($dep->cliente)->apellido); ?>

                  <div class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(optional($dep->cliente)->email); ?></div>
                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">$<?php echo e(number_format($dep->cantidad,2)); ?></td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200"><?php echo e(\Carbon\Carbon::parse($dep->fecha_deposito)->format('Y-m-d')); ?></td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e([0=>'Pendiente',1=>'Aprobado',2=>'Rechazado'][$dep->status] ?? '—'); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($dep->caja)->nombre ?? '—'); ?>

                </td>
                <td class="px-6 py-4 text-right">
                  <a href="<?php echo e(route('depositos.show', $dep)); ?>"
                     class="inline-flex items-center px-3 py-2 bg-green-500 hover:bg-green-600
                            text-white text-sm font-medium rounded-md">
                    <?php echo e(__('Ver')); ?>

                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="7" class="px-6 py-6 text-center text-gray-500 dark:text-gray-400">
                  <?php echo e(__('No hay depósitos registrados.')); ?>

                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="px-4 py-3 text-right bg-gray-50 dark:bg-gray-700 sm:px-6">
        <?php echo e($depositos->links()); ?>

      </div>
    </div>
  </div>

  
  <script>
    function depositosIndexPage() {
      return {
        // Estado inicial desde el servidor (si vienen en la query)
        search: <?php echo json_encode($search ?? request('search', ''), 512) ?>,
        status: <?php echo json_encode($status ?? request('status', ''), 512) ?>,
        desde:  <?php echo json_encode($desde  ?? request('desde', ''), 512) ?>,
        hasta:  <?php echo json_encode($hasta  ?? request('hasta', ''), 512) ?>,
        orden:  <?php echo json_encode($orden  ?? request('orden', 'fecha_desc'), 512) ?>,

        loading: false,
        container: null,

        init() {
          this.container = document.getElementById('depositos-results');

          // Interceptar SOLO paginación (?page=) dentro del contenedor
          this.container?.addEventListener('click', (e) => {
            const a = e.target.closest('a');
            if (!a || !a.href) return;
            if (!/([?&])page=/.test(a.href)) return; // no interferir con "Ver"
            e.preventDefault();
            this.fetchTo(a.href);
          });
        },

        // Fallback navegación normal (clic en "Filtrar")
        go() {
          const base = <?php echo json_encode(route('depositos.index'), 15, 512) ?>;
          const params = new URLSearchParams({
            search: this.search ?? '',
            status: this.status ?? '',
            desde:  this.desde  ?? '',
            hasta:  this.hasta  ?? '',
            orden:  this.orden  ?? 'fecha_desc',
          });
          window.location = `${base}?${params.toString()}`;
        },

        // ===== Live search =====
        buildUrl() {
          const base = <?php echo json_encode(route('depositos.index'), 15, 512) ?>;
          const params = new URLSearchParams({
            search: this.search ?? '',
            status: this.status ?? '',
            desde:  this.desde  ?? '',
            hasta:  this.hasta  ?? '',
            orden:  this.orden  ?? 'fecha_desc',
            ajax:   '1', // si el backend devuelve solo el fragmento; si no, extraemos
          });
          return `${base}?${params.toString()}`;
        },

        async liveSearch() {
          await this.fetchTo(this.buildUrl());
        },

        async fetchTo(url) {
          this.loading = true;
          try {
            const res  = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } });
            const text = await res.text();

            // Si el backend devuelve la vista completa, extraemos #depositos-results
            let htmlToInject = text;
            try {
              const doc  = new DOMParser().parseFromString(text, 'text/html');
              const frag = doc.querySelector('#depositos-results');
              if (frag) htmlToInject = frag.innerHTML;
            } catch (_) {}

            if (this.container) {
              this.container.innerHTML = htmlToInject;
              // re-init Alpine si hay directivas nuevas en el fragmento
              if (window.Alpine && Alpine.initTree) Alpine.initTree(this.container);
            }

            // Actualiza la URL visible (quitando ajax=1)
            const u = new URL(url, window.location.origin);
            u.searchParams.delete('ajax');
            history.replaceState({}, '', u);

          } catch (e) {
            console.error('Live search error:', e);
          } finally {
            this.loading = false;
          }
        },
      }
    }
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/depositos/index.blade.php ENDPATH**/ ?>