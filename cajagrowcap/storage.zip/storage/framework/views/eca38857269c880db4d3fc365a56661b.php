<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <div class="flex items-center justify-between">
      <h2 class="font-semibold text-xl text-white leading-tight">
        <?php echo e(__('Préstamo #')); ?><?php echo e(str_pad($prestamo->id, 3, '0', STR_PAD_LEFT)); ?>

      </h2>
      <div class="flex space-x-2">
        <a href="<?php echo e(route('user_prestamos.index')); ?>"
           class="inline-flex items-center px-3 py-2 bg-gray-500 hover:bg-gray-600 text-white text-sm font-medium rounded-md">
          <?php echo e(__('← Volver')); ?>

        </a>
        <a href="<?php echo e(route('user_prestamos.edit', $prestamo)); ?>"
           class="inline-flex items-center px-3 py-2 bg-yellow-500 hover:bg-yellow-600 text-white text-sm font-medium rounded-md">
          <?php echo e(__('Editar')); ?>

        </a>
      </div>
    </div>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-5xl px-4 sm:px-6 lg:px-8 space-y-6">
    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6">
      <h3 class="font-semibold text-lg text-gray-900 dark:text-gray-100 mb-3"><?php echo e(__('Resumen')); ?></h3>
      <div class="grid grid-cols-1 md:grid-cols-2 gap-4 text-gray-700 dark:text-gray-200">
        <div><span class="font-medium"><?php echo e(__('Cliente:')); ?></span>
          <?php echo e(optional($prestamo->cliente)->nombre); ?> <?php echo e(optional($prestamo->cliente)->apellido); ?>

          <div class="text-xs text-gray-500"><?php echo e(optional($prestamo->cliente)->email); ?></div>
        </div>
        <div><span class="font-medium"><?php echo e(__('Monto:')); ?></span> $<?php echo e(number_format($prestamo->cantidad,2)); ?></div>
        <div><span class="font-medium"><?php echo e(__('Tipo / Semanas:')); ?></span> <?php echo e($prestamo->tipo_prestamo); ?> / <?php echo e($prestamo->semanas); ?></div>
        <div><span class="font-medium"><?php echo e(__('Interés:')); ?></span> <?php echo e(number_format($prestamo->interes,2)); ?>% ( $<?php echo e(number_format($prestamo->interes_generado,2)); ?> )</div>
        <div><span class="font-medium"><?php echo e(__('Inicio:')); ?></span> <?php echo e(\Carbon\Carbon::parse($prestamo->fecha_inicio)->format('Y-m-d')); ?></div>
        <div><span class="font-medium"><?php echo e(__('Status:')); ?></span> <?php echo e($statusOptions[$prestamo->status] ?? '—'); ?></div>
        <div><span class="font-medium"><?php echo e(__('Caja:')); ?></span> <?php echo e(optional($prestamo->caja)->nombre ?? '—'); ?></div>
        <div><span class="font-medium"><?php echo e(__('Mora acum.:')); ?></span> $<?php echo e(number_format($prestamo->mora_acumulada,2)); ?></div>
      </div>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6">
      <h3 class="font-semibold text-lg text-gray-900 dark:text-gray-100 mb-3"><?php echo e(__('Plan de pagos')); ?></h3>
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
          <thead class="bg-gray-100 dark:bg-gray-700">
            <tr>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">#</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Fecha Vto.</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Pagado</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Saldo Rest.</th>
              <th class="px-4 py-2 text-left text-xs font-medium text-gray-700 dark:text-gray-300 uppercase">Estado</th>
            </tr>
          </thead>
          <tbody class="divide-y divide-gray-200 dark:divide-gray-700">
            <?php $__currentLoopData = $prestamo->abonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ab): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e($ab->num_pago); ?></td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e($ab->fecha_vencimiento); ?></td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">$<?php echo e(number_format($ab->cantidad,2)); ?></td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">$<?php echo e(number_format($ab->saldo_restante,2)); ?></td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e([0=>'Pendiente',1=>'Pagado'][$ab->status] ?? '—'); ?>

                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php if($prestamo->abonos->isEmpty()): ?>
              <tr>
                <td colspan="5" class="px-4 py-4 text-center text-gray-500 dark:text-gray-400">
                  <?php echo e(__('Sin abonos generados.')); ?>

                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserprestamos/show.blade.php ENDPATH**/ ?>