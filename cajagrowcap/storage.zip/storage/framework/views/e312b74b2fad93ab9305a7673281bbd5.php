
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Movimientos de Caja')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{ search: '', filterCaja: '', filterTipo: '' }"
  >
    
    <div class="mb-4 flex flex-col sm:flex-row sm:justify-between sm:items-center space-y-2 sm:space-y-0">
      
      <a href="<?php echo e(route('movimientos-caja.create')); ?>"
         class="inline-flex items-center px-4 py-2
                bg-yellow-500 hover:bg-yellow-600 dark:bg-yellow-700 dark:hover:bg-yellow-800
                text-white font-semibold rounded-md shadow-sm focus:outline-none
                focus:ring-2 focus:ring-offset-2 focus:ring-yellow-400">
        + Nuevo Movimiento
      </a>

      <div class="flex space-x-2">
        
        <select x-model="filterCaja"
                class="px-3 py-2 sm:w-48 border rounded-md shadow-sm
                       focus:outline-none focus:ring-2 focus:ring-purple-500
                       bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200
                       dark:border-gray-600">
          <option value=""><?php echo e(__('Todas las cajas')); ?></option>
          <?php $__currentLoopData = $movimientos->pluck('caja')->unique('id_caja'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($c->id_caja); ?>"><?php echo e($c->nombre); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

        
        <select x-model="filterTipo"
                class="px-3 py-2 sm:w-40 border rounded-md shadow-sm
                       focus:outline-none focus:ring-2 focus:ring-purple-500
                       bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200
                       dark:border-gray-600">
          <option value=""><?php echo e(__('Todos los tipos')); ?></option>
          <option value="ingreso"><?php echo e(__('Ingreso')); ?></option>
          <option value="gasto"><?php echo e(__('Gasto')); ?></option>
        </select>

        
        <input type="text"
               x-model="search"
               placeholder="<?php echo e(__('Buscar…')); ?>"
               class="px-3 py-2 border rounded-md shadow-sm
                      focus:outline-none focus:ring-2 focus:ring-purple-500
                      bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200
                      dark:border-gray-600"/>
      </div>
    </div>

    <?php if(session('success')): ?>
      <div class="mb-4 rounded-lg bg-yellow-100 p-4 text-yellow-800
                  dark:bg-yellow-900 dark:text-yellow-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg">
      <div class="overflow-x-auto">
        <table class="table-auto min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
          <thead class="bg-purple-700 dark:bg-purple-900">
            <tr>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Fecha</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Caja</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Tipo</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Categoría</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Subcategoría</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Proveedor</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">ID Origen</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Monto</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Saldo Ant.</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Saldo Post.</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase">Usuario</th>
              <th class="px-4 py-2 text-xs font-medium text-white uppercase text-right">Acciones</th>
            </tr>
          </thead>
          <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            <?php $__empty_1 = true; $__currentLoopData = $movimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr x-show="
                $el.textContent.toLowerCase().includes(search.toLowerCase())
                && (!filterCaja || filterCaja == '<?php echo e($m->id_caja); ?>')
                && (!filterTipo || filterTipo == '<?php echo e(strtolower($m->tipo_mov)); ?>')
              ">
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e($m->fecha->format('Y-m-d H:i')); ?>

                </td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($m->caja)->nombre ?? '-'); ?>

                </td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200"><?php echo e(ucfirst($m->tipo_mov)); ?></td>

                
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php if(strtolower($m->tipo_mov) === 'ingreso'): ?>
                    <?php echo e(optional($m->categoriaIngreso)->nombre ?? '-'); ?>

                  <?php else: ?>
                    <?php echo e(optional($m->categoriaGasto)->nombre ?? '-'); ?>

                  <?php endif; ?>
                </td>

                
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php if(strtolower($m->tipo_mov) === 'ingreso'): ?>
                    <?php echo e(optional($m->subcategoriaIngreso)->nombre ?? '-'); ?>

                  <?php else: ?>
                    <?php echo e(optional($m->subcategoriaGasto)->nombre ?? '-'); ?>

                  <?php endif; ?>
                </td>

                
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($m->proveedor)->nombre ?? '-'); ?>

                </td>

                
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php if($m->origen_id): ?>
                    <span class="inline-flex items-center px-2 py-0.5 rounded-full
                                 bg-gray-100 dark:bg-gray-700 border border-gray-200 dark:border-gray-600
                                 font-mono text-xs text-gray-700 dark:text-gray-200">
                      #<?php echo e($m->origen_id); ?>

                    </span>
                  <?php else: ?>
                    <span class="text-gray-400">—</span>
                  <?php endif; ?>
                </td>

                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(number_format($m->monto,2)); ?>

                </td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(number_format($m->monto_anterior,2)); ?>

                </td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(number_format($m->monto_posterior,2)); ?>

                </td>
                <td class="px-4 py-2 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($m->usuario)->name ?? '-'); ?>

                </td>
                <td class="px-4 py-2 text-right space-x-2">
                  <a href="<?php echo e(route('movimientos-caja.edit', $m)); ?>"
                     class="inline-flex items-center text-yellow-500 hover:text-yellow-700">
                    <svg xmlns="http://www.w3.org/2000/svg"
                         class="h-5 w-5" fill="none" viewBox="0 0 24 24"
                         stroke="currentColor" stroke-width="2">
                      <path stroke-linecap="round" stroke-linejoin="round"
                            d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5" />
                      <path stroke-linecap="round" stroke-linejoin="round"
                            d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4
                               9.5-9.5z" />
                    </svg>
                  </a>
                  <form action="<?php echo e(route('movimientos-caja.destroy', $m)); ?>"
                        method="POST" class="inline">
                    <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                    <button type="button" class="inline-flex items-center text-red-500 hover:text-red-700 btn-delete"
                            data-id="<?php echo e($m->id_mov); ?>">
                      <svg xmlns="http://www.w3.org/2000/svg"
                           class="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                        <path fill-rule="evenodd"
                              d="M6 2a1 1 0 00-1 1v1H3a1 1 0
                                 100 2h14a1 1 0 100-2h-2V3a1 1 0
                                 00-1-1H6zm3 7a1 1 0 012 0v6a1 1 0
                                 11-2 0V9zm-4 0a1 1 0 012 0v6a1 1 0
                                 11-2 0V9z" clip-rule="evenodd"/>
                      </svg>
                    </button>
                  </form>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="12"
                    class="px-4 py-2 text-center text-gray-500 dark:text-gray-400">
                  <?php echo e(__('No hay movimientos registrados.')); ?>

                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      
      <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right sm:px-6">
        <?php echo e($movimientos->links()); ?>

      </div>
    </div>
  </div>

  
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <script>
    document.querySelectorAll('.btn-delete').forEach(btn => {
      btn.addEventListener('click', () => {
        const id = btn.dataset.id;
        Swal.fire({
          title: '¿Eliminar movimiento?',
          text: 'Esta acción no se puede deshacer.',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonText: 'Sí, eliminar',
          cancelButtonText: 'Cancelar',
          confirmButtonColor: '#d33',
        }).then(result => {
          if (result.isConfirmed) {
            btn.closest('form').submit();
          }
        });
      });
    });
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/movimientos-caja/index.blade.php ENDPATH**/ ?>