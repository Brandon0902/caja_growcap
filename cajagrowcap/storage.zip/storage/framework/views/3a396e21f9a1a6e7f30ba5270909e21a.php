<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="text-xl font-semibold text-white">Gestión de Metas y Presupuestos</h2>
   <?php $__env->endSlot(); ?>

  <div class="p-6 space-y-6">

    
    <?php if(session('success')): ?>
      <div class="p-3 rounded bg-green-100 text-green-800">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
      <div class="p-3 rounded bg-red-100 text-red-800">
        <ul class="list-disc list-inside">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($e); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <form action="<?php echo e(route('presupuestos.store')); ?>" method="POST" class="space-y-4">
      <?php echo csrf_field(); ?>

      
      <div class="flex flex-col sm:flex-row gap-4">
        <div>
          <label class="block text-sm font-medium mb-1">Mes</label>
          <select name="mes" class="border rounded px-2 py-1 bg-white dark:bg-gray-800">
            <?php $__currentLoopData = range(1,12); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($m); ?>" <?php if($m == $mes): echo 'selected'; endif; ?>><?php echo e($meses[$m] ?? $m); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div>
          <label class="block text-sm font-medium mb-1">Año</label>
          <select name="año" class="border rounded px-2 py-1 bg-white dark:bg-gray-800">
            <?php $__currentLoopData = range(now()->year, now()->year-5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($y); ?>" <?php if($y == $año): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      </div>

      
      <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php $__currentLoopData = $fuentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $row = $presupuestos[$f] ?? null;
            $tipoInicial = $row->tipo ?? ($tiposPorDefecto[$f] ?? 'Presupuesto');
          ?>

          <div class="border rounded p-3 bg-white dark:bg-gray-800">
            <label class="font-semibold block mb-2"><?php echo e($f); ?></label>

            
            <input type="hidden" name="fuente[]" value="<?php echo e($f); ?>" />

            <div class="flex items-center gap-2 mb-2">
              <label class="text-sm w-20">Tipo</label>
              <select name="tipo[]" class="border rounded px-2 py-1 flex-1 bg-white dark:bg-gray-900">
                <?php $__currentLoopData = $tipos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($t); ?>" <?php if($tipoInicial === $t): echo 'selected'; endif; ?>><?php echo e($t); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            <div class="flex items-center gap-2">
              <label class="text-sm w-20">Monto</label>
              <input
                type="number"
                step="0.01"
                name="monto[]"
                value="<?php echo e($row->monto ?? ''); ?>"
                placeholder="0.00"
                class="border rounded px-2 py-1 flex-1 bg-white dark:bg-gray-900"
              />
            </div>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>

      <div>
        <button type="submit" class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded">
          Guardar
        </button>
      </div>
    </form>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/presupuestos/index.blade.php ENDPATH**/ ?>