<button type="<?php echo e($type); ?>"
        <?php echo e($attributes->merge([
            'class' => 'px-4 py-2 bg-purple-600 text-white rounded hover:bg-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500'
        ])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/components/button.blade.php ENDPATH**/ ?>