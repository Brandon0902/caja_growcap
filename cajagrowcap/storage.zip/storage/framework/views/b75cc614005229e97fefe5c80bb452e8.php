<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200 leading-tight">
      <?php echo e(__('Permisos y Roles')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 space-y-6">

    <?php if(session('ok')): ?>
      <div class="bg-green-100 text-green-800 px-4 py-2 rounded-md">
        <?php echo e(session('ok')); ?>

      </div>
    <?php endif; ?>
    <?php if($errors->any()): ?>
      <div class="bg-rose-100 text-rose-800 px-4 py-2 rounded-md">
        <ul class="list-disc list-inside">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($e); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <form method="POST" action="<?php echo e(route('admin.permisos.sync-enum')); ?>" class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow flex items-center justify-between">
        <?php echo csrf_field(); ?>
        <div>
          <h3 class="font-semibold">Sincronizar enum → Spatie</h3>
          <p class="text-sm text-gray-500 dark:text-gray-400">Lee el campo <code>usuarios.rol</code> y sincroniza los roles de Spatie.</p>
        </div>
        <button class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Ejecutar</button>
      </form>

      <form method="POST" action="<?php echo e(route('admin.permisos.cache-reset')); ?>" class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow flex items-center justify-between">
        <?php echo csrf_field(); ?>
        <div>
          <h3 class="font-semibold">Resetear caché de permisos</h3>
          <p class="text-sm text-gray-500 dark:text-gray-400">Forzar a Spatie a recargar permisos/roles.</p>
        </div>
        <button class="px-4 py-2 bg-gray-700 text-white rounded-lg hover:bg-gray-800">Reset</button>
      </form>

      
      <form method="POST" action="<?php echo e(route('admin.permisos.prune')); ?>" class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow flex items-center justify-between">
        <?php echo csrf_field(); ?>
        <div>
          <h3 class="font-semibold">Podar permisos según navbar</h3>
          <p class="text-sm text-gray-500 dark:text-gray-400">Normaliza sinónimos y elimina permisos de módulos/acciones no usados.</p>
        </div>
        <button class="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700">Podar BD</button>
      </form>
    </div>

    
    <div class="bg-blue-50 dark:bg-blue-900/30 text-blue-900 dark:text-blue-200 px-4 py-2 rounded-md">
      <strong>Alcance por módulo:</strong>
      <span class="font-mono">ver_todas</span> (ve todo),
      <span class="font-mono">ver_sucursal</span> (solo la sucursal del usuario),
      <span class="font-mono">ver_asignadas</span> (solo asignadas al usuario).
    </div>

    
    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
      <h3 class="font-semibold mb-4">Permisos por Rol</h3>

      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $rolePerms = $role->permissions->pluck('name')->toArray(); ?>

        <details class="mb-4" <?php if($loop->first): ?> open <?php endif; ?>>
          <summary class="cursor-pointer select-none font-semibold text-purple-700 dark:text-purple-300">
            Rol: <?php echo e(ucfirst($role->name)); ?>

          </summary>

          <form method="POST" action="<?php echo e(route('admin.permisos.roles.sync', $role)); ?>" class="mt-3">
            <?php echo csrf_field(); ?>

            <div class="overflow-x-auto rounded-lg border border-gray-200 dark:border-gray-700">
              <table class="min-w-full text-sm">
                <thead>
                  <tr class="bg-gray-50 dark:bg-gray-900/40">
                    <th class="px-3 py-2 text-left">Módulo</th>
                    <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <th class="px-3 py-2 text-center"><?php echo e($labels[$act] ?? ucfirst($act)); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tr>
                </thead>
                <tbody>

                
                <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent => $children): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    // Calcula estado del padre (por acción) según los hijos
                    $parentState = []; // act => ['all'=>bool,'some'=>bool,'names'=>[]]
                    foreach ($actions as $act) {
                      $names = [];
                      foreach ($children as $childModule) {
                        $permsChild = $permsByModule[$childModule] ?? collect();
                        $mapRaw = [];
                        foreach ($permsChild as $p) {
                          $parts = explode('.', $p->name, 2);
                          if (!empty($parts[1])) $mapRaw[$parts[1]] = $p->name;
                        }
                        $chosen = null;
                        $candidates = [$act];
                        foreach ($synonyms as $from => $to) { if ($to === $act) $candidates[] = $from; }
                        foreach ($candidates as $cand) {
                          if (isset($mapRaw[$cand])) { $chosen = $mapRaw[$cand]; break; }
                        }
                        if ($chosen) $names[] = $chosen;
                      }
                      $has = array_map(fn($n)=>in_array($n, $rolePerms), $names);
                      $all  = !empty($names) && count(array_filter($has)) === count($names);
                      $some = !empty($names) && count(array_filter($has)) > 0 && !$all;
                      $parentState[$act] = ['all'=>$all,'some'=>$some,'names'=>$names];
                    }
                  ?>

                  <tr class="border-t border-gray-200 dark:border-gray-700 bg-gray-50/70 dark:bg-gray-900/40">
                    <td class="px-3 py-2 font-semibold capitalize"><?php echo e(str_replace('_',' ', $parent)); ?> <span class="opacity-60">(todo)</span></td>
                    <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <td class="px-3 py-2 text-center">
                        <input type="checkbox"
                               class="parent-toggle rounded border-gray-300 dark:bg-gray-900"
                               data-parent="<?php echo e($parent); ?>"
                               data-action="<?php echo e($act); ?>"
                               data-child-names='<?php echo json_encode($parentState[$act]["names"], 15, 512) ?>'
                               <?php if($parentState[$act]['all']): echo 'checked'; endif; ?>>
                        <span class="sr-only"><?php echo e($act); ?></span>
                        <script>
                          document.addEventListener('DOMContentLoaded', () => {
                            const el = document.querySelector(
                              'input.parent-toggle[data-parent="<?php echo e($parent); ?>"][data-action="<?php echo e($act); ?>"]'
                            );
                            if (el) el.indeterminate = <?php echo e($parentState[$act]['some'] ? 'true' : 'false'); ?>;
                          });
                        </script>
                      </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                

                
                <?php $__currentLoopData = $permsByModule; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $perms): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php
                    // mapa bruto acción->nombre_permiso del módulo actual
                    $mapRaw = [];
                    foreach ($perms as $p) {
                      $parts = explode('.', $p->name, 2);
                      if (!empty($parts[1])) $mapRaw[$parts[1]] = $p->name;
                    }

                    // map canónico => nombre_permiso_real (considera sinónimos)
                    $map = [];
                    foreach ($actions as $canon) {
                      $candidates = [$canon];
                      foreach ($synonyms as $from => $to) {
                        if ($to === $canon) $candidates[] = $from;
                      }
                      foreach ($candidates as $cand) {
                        if (isset($mapRaw[$cand])) { $map[$canon] = $mapRaw[$cand]; break; }
                      }
                    }

                    // ¿A qué grupo pertenece este módulo (si aplica)?
                    $groupName = null;
                    foreach ($groups as $gName => $gChildren) {
                      if (in_array($module, $gChildren, true)) { $groupName = $gName; break; }
                    }
                  ?>

                  <tr class="border-t border-gray-200 dark:border-gray-700">
                    <td class="px-3 py-2 font-medium capitalize"><?php echo e(str_replace('_',' ', $module)); ?></td>

                    <?php $__currentLoopData = $actions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $act): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <td class="px-3 py-2 text-center">
                        <?php if(isset($map[$act])): ?>
                          <input
                            type="checkbox"
                            name="permissions[]"
                            value="<?php echo e($map[$act]); ?>"
                            class="rounded border-gray-300 dark:bg-gray-900"
                            data-module="<?php echo e($module); ?>"
                            data-action="<?php echo e($act); ?>"
                            <?php if($groupName): ?> data-group="<?php echo e($groupName); ?>" <?php endif; ?>
                            <?php if(in_array($map[$act], $rolePerms)): echo 'checked'; endif; ?>
                          >
                        <?php else: ?>
                          <span class="text-gray-400">—</span>
                        <?php endif; ?>
                      </td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </tbody>
              </table>
            </div>

            <div class="mt-3 flex justify-end">
              <button class="px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700">
                Guardar permisos
              </button>
            </div>
          </form>
        </details>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    
    <div class="bg-white dark:bg-gray-800 p-4 rounded-xl shadow">
      <h3 class="font-semibold mb-4">Asignar roles a usuarios</h3>

      <div class="overflow-x-auto rounded-lg border border-gray-200 dark:border-gray-700">
        <table class="min-w-full text-sm">
          <thead>
            <tr class="bg-gray-50 dark:bg-gray-900/40">
              <th class="px-3 py-2 text-left">Usuario</th>
              <th class="px-3 py-2 text-left">Email</th>
              <th class="px-3 py-2 text-left">Sucursal</th>
              <th class="px-3 py-2 text-left">Roles</th>
              <th class="px-3 py-2"></th>
            </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t border-gray-200 dark:border-gray-700 align-top">
              <td class="px-3 py-2"><?php echo e($u->name); ?></td>
              <td class="px-3 py-2"><?php echo e($u->email); ?></td>
              <td class="px-3 py-2"><?php echo e(optional($u->sucursal)->nombre ?? '—'); ?></td>
              <td class="px-3 py-2">
                <form method="POST" action="<?php echo e(route('admin.permisos.usuarios.sync', $u)); ?>" class="flex flex-col gap-2">
                  <?php echo csrf_field(); ?>
                  <div class="flex items-center gap-2">
                    <select name="roles[]" multiple class="rounded-md dark:bg-gray-900 min-w-[220px]" size="3">
                      <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $r): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($r->name); ?>" <?php if($u->roles->pluck('name')->contains($r->name)): echo 'selected'; endif; ?>>
                          <?php echo e(ucfirst($r->name)); ?>

                        </option>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <button class="px-3 py-1.5 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">Guardar</button>
                  </div>
                </form>

                <?php if(isset($cajasAll)): ?>
                  <details class="mt-2">
                    <summary class="text-sm text-gray-600 dark:text-gray-300 cursor-pointer">
                      Cajas asignadas
                    </summary>
                    <form class="mt-2 flex items-start gap-2" onsubmit="return false;">
                      <?php echo csrf_field(); ?>
                      <select multiple size="4" class="rounded-md dark:bg-gray-900 min-w-[260px]">
                        <?php $__currentLoopData = $cajasAll; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <option value="<?php echo e($c->id_caja); ?>">[Suc <?php echo e($c->id_sucursal); ?>] <?php echo e($c->nombre); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </select>
                      <button class="px-3 py-1.5 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 opacity-50 cursor-not-allowed"
                              title="Implementa la ruta para guardar">
                        Guardar asignación
                      </button>
                    </form>
                  </details>
                <?php endif; ?>
              </td>
              <td class="px-3 py-2"></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  
  <script>
    document.addEventListener('DOMContentLoaded', () => {
      // Exclusividad de alcances dentro del mismo módulo
      const scope = new Set(['ver_todas','ver_sucursal','ver_asignadas']);
      document.querySelectorAll('form[action*="roles"]').forEach(form => {
        form.addEventListener('change', e => {
          const el = e.target;
          if (!el.matches('input[type=checkbox][name="permissions[]"]')) return;
          const action = el.dataset.action;
          const module = el.dataset.module;
          if (el.checked && scope.has(action) && module) {
            form.querySelectorAll(`input[data-module="${module}"]`).forEach(cb => {
              if (cb !== el && scope.has(cb.dataset.action)) cb.checked = false;
            });
          }
        });
      });

      // Padre -> Hijos
      document.querySelectorAll('input.parent-toggle').forEach(parent => {
        parent.addEventListener('change', () => {
          const group   = parent.dataset.parent;
          const action  = parent.dataset.action;
          const checked = parent.checked;

          document.querySelectorAll(`input[type=checkbox][data-group="${group}"][data-action="${action}"]`)
            .forEach(cb => { cb.checked = checked; cb.dispatchEvent(new Event('change', {bubbles:true})); });

          parent.indeterminate = false;
        });
      });

      // Hijos -> Padre (ajusta checked/indeterminate)
      const updateParentState = (group, action) => {
        const parent = document.querySelector(`input.parent-toggle[data-parent="${group}"][data-action="${action}"]`);
        if (!parent) return;
        const childs = Array.from(document.querySelectorAll(`input[type=checkbox][data-group="${group}"][data-action="${action}"]`));
        if (childs.length === 0) return;
        const on = childs.filter(cb => cb.checked).length;
        parent.checked = (on === childs.length);
        parent.indeterminate = (on > 0 && on < childs.length);
      };

      document.querySelectorAll('input[type=checkbox][data-group]').forEach(child => {
        child.addEventListener('change', () => {
          updateParentState(child.dataset.group, child.dataset.action);
        });
        // estado inicial al cargar
        updateParentState(child.dataset.group, child.dataset.action);
      });
    });
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/permisos/index.blade.php ENDPATH**/ ?>