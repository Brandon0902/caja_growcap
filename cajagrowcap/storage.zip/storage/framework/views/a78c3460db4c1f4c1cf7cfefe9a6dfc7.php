<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Inversiones')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{
         search: '<?php echo e($search); ?>',
         status: '<?php echo e($status); ?>',
         desde: '<?php echo e($desde); ?>',
         hasta: '<?php echo e($hasta); ?>',
         fin_desde: '<?php echo e($fin_desde); ?>',
         fin_hasta: '<?php echo e($fin_hasta); ?>',
         orden: '<?php echo e($orden); ?>'
       }">

    <?php if(session('success')): ?>
      <div class="mb-4 rounded-lg bg-green-100 dark:bg-green-900 p-4 text-green-800 dark:text-green-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    
    <div class="mb-4 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-8 gap-3">
      <input type="text" x-model="search" placeholder="<?php echo e(__('Buscar por cliente / # / monto…')); ?>"
             class="px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-purple-500
                    bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600 col-span-2" />

      <select x-model="status"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($key); ?>" <?php if((string)($status ?? '') === (string)($key ?? '')): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      
      <input type="date" x-model="desde"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
             placeholder="Inicio desde" />
      <input type="date" x-model="hasta"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
             placeholder="Inicio hasta" />

      
      <input type="date" x-model="fin_desde"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
             placeholder="Fin desde" />
      <input type="date" x-model="fin_hasta"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"
             placeholder="Fin hasta" />

      <select x-model="orden"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="fecha_inicio_desc"><?php echo e(__('Más recientes (inicio)')); ?></option>
        <option value="fecha_inicio_asc"><?php echo e(__('Más antiguas (inicio)')); ?></option>
        <option value="fecha_fin_desc"><?php echo e(__('Más recientes (fin)')); ?></option>
        <option value="fecha_fin_asc"><?php echo e(__('Más antiguas (fin)')); ?></option>
        <option value="monto_desc"><?php echo e(__('Monto ↓')); ?></option>
        <option value="monto_asc"><?php echo e(__('Monto ↑')); ?></option>
      </select>

      <button
        @click="window.location = '<?php echo e(route('user_inversiones.index')); ?>'
          + `?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status ?? '')}
              &desde=${encodeURIComponent(desde ?? '')}&hasta=${encodeURIComponent(hasta ?? '')}
              &fin_desde=${encodeURIComponent(fin_desde ?? '')}&fin_hasta=${encodeURIComponent(fin_hasta ?? '')}
              &orden=${encodeURIComponent(orden)}`"
        class="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-md shadow">
        <?php echo e(__('Filtrar')); ?>

      </button>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg">
      <div class="overflow-x-auto">
        <table class="table-auto min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
          <thead class="bg-purple-700 dark:bg-purple-900">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">#</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Cliente</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Plan</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Interés</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Monto</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Fecha inicio</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Fecha fin</th>
              <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Estatus</th>
              <th class="px-6 py-3 text-right text-xs font-medium text-white uppercase">Acciones</th>
            </tr>
          </thead>
          <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
            <?php $__empty_1 = true; $__currentLoopData = $inversiones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e(str_pad($inv->id, 3, '0', STR_PAD_LEFT)); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($inv->cliente)->nombre); ?> <?php echo e(optional($inv->cliente)->apellido); ?>

                  <div class="text-xs text-gray-500 dark:text-gray-400">
                    <?php echo e(optional($inv->cliente)->email); ?>

                  </div>
                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e(optional($inv->plan)->periodo); ?> 
                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e(number_format($inv->rendimiento ?? optional($inv->plan)->rendimiento ?? 0, 2)); ?>%
                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  $<?php echo e(number_format($inv->cantidad, 2)); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e(\Carbon\Carbon::parse($inv->fecha_inicio)->format('Y-m-d')); ?>

                </td>
                <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                  <?php echo e($inv->fecha_fin ? \Carbon\Carbon::parse($inv->fecha_fin)->format('Y-m-d') : '—'); ?>

                </td>
                <td class="px-6 py-4">
                  <?php
                    $badgeClasses = [
                      1 => 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200',
                      2 => 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
                      3 => 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
                      4 => 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200',
                      5 => 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
                      6 => 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200',
                    ];
                  ?>
                  <span class="px-2 py-1 rounded text-xs font-semibold <?php echo e($badgeClasses[$inv->status] ?? 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'); ?>">
                    <?php echo e([1=>'Autorizada',2=>'Pendiente',3=>'En revisión',4=>'Rechazada',5=>'Invertida',6=>'Finalizada'][$inv->status] ?? '—'); ?>

                  </span>
                </td>
                <td class="px-6 py-4 text-right">
                  <a href="<?php echo e(route('user_inversiones.show', $inv)); ?>"
                     class="inline-flex items-center px-3 py-2 bg-yellow-500 hover:bg-yellow-600
                            text-white text-sm font-medium rounded-md shadow-sm focus:outline-none
                            focus:ring-2 focus:ring-offset-2 focus:ring-yellow-400">
                    <?php echo e(__('Ver')); ?>

                  </a>
                  <a href="<?php echo e(route('user_inversiones.edit', $inv)); ?>"
                     class="inline-flex items-center px-3 py-2 bg-indigo-600 hover:bg-indigo-700
                            text-white text-sm font-medium rounded-md shadow-sm focus:outline-none
                            focus:ring-2 focus:ring-offset-2 focus:ring-indigo-400 ml-2">
                    <?php echo e(__('Editar')); ?>

                  </a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr>
                <td colspan="9" class="px-6 py-4 text-center text-gray-500 dark:text-gray-400">
                  <?php echo e(__('No hay inversiones registradas.')); ?>

                </td>
              </tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>

      <div class="bg-gray-50 dark:bg-gray-700 px-4 py-3 text-right sm:px-6">
        <?php echo e($inversiones->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserinversiones/index.blade.php ENDPATH**/ ?>