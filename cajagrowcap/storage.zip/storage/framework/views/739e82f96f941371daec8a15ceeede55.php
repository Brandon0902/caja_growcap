
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-gray-800 dark:text-gray-200">
      <?php echo e(__('Contabilidad Profunda')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="px-4 py-6 space-y-6">

    
    <?php if(isset($kpi)): ?>
      <div class="grid gap-4 grid-cols-2 md:grid-cols-4 xl:grid-cols-6">
        <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
          <div class="text-xs text-gray-500">Movimientos</div>
          <div class="text-2xl font-bold"><?php echo e($kpi['movimientos']); ?></div>
        </div>
        <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
          <div class="text-xs text-gray-500">Ingresos</div>
          <div class="text-2xl font-bold text-green-600"><?php echo e(number_format($kpi['ingresos'],2)); ?></div>
        </div>
        <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
          <div class="text-xs text-gray-500">Egresos</div>
          <div class="text-2xl font-bold text-red-600"><?php echo e(number_format($kpi['egresos'],2)); ?></div>
        </div>
        <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
          <div class="text-xs text-gray-500">Balance</div>
          <div class="text-2xl font-bold <?php echo e($kpi['balance']>=0 ? 'text-green-600':'text-red-600'); ?>">
            <?php echo e(number_format($kpi['balance'],2)); ?>

          </div>
        </div>
        <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
          <div class="text-xs text-gray-500">Cajas</div>
          <div class="text-2xl font-bold"><?php echo e($kpi['cajas']); ?></div>
        </div>
        <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
          <div class="text-xs text-gray-500">Usuarios distintos</div>
          <div class="text-2xl font-bold"><?php echo e($kpi['usuarios']); ?></div>
        </div>
      </div>
    <?php endif; ?>

    
    <?php if(isset($movs)): ?>
      <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-4">
        <?php $__currentLoopData = $fuentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php
            $gasto = ($gastoPorFuente[$f] ?? 0);
            $pres  = $presupuestos[$f]->monto ?? 0;
            $pct   = $pres > 0 ? min(100, round($gasto * 100 / $pres)) : null;
          ?>
          <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
            <div class="text-sm text-gray-500"><?php echo e($f); ?></div>
            <div class="mt-1 text-xl font-bold text-red-600"><?php echo e(number_format($gasto,2)); ?></div>
            <div class="text-xs text-gray-500">/ <?php echo e(number_format($pres,2)); ?> presupuestado</div>
            <?php if(!is_null($pct)): ?>
              <div class="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-2 overflow-hidden">
                <div class="h-2 <?php echo e($pct >= 100 ? 'bg-red-500':'bg-green-500'); ?>" style="width: <?php echo e($pct); ?>%"></div>
              </div>
              <div class="text-xs text-gray-500 mt-1"><?php echo e($pct); ?>% usado</div>
            <?php endif; ?>
          </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    <?php endif; ?>

    
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4">
      
      <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl lg:col-span-2">
        <div class="text-sm text-gray-500 mb-2">Ingresos vs Egresos (por día)</div>
        <canvas id="chartIE"></canvas>
      </div>

      
      <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
        <div class="text-sm text-gray-500 mb-2">Ingresos / Egresos por fuente</div>
        <canvas id="chartFuente"></canvas>
      </div>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
        <div class="text-sm text-gray-500 mb-2">Ingresos / Egresos por caja</div>
        <canvas id="chartCaja"></canvas>
      </div>
      <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
        <div class="text-sm text-gray-500 mb-2">Ingresos / Egresos por categoría</div>
        <canvas id="chartCat"></canvas>
      </div>
      <div class="p-4 bg-white dark:bg-gray-800 shadow rounded-xl">
        <div class="text-sm text-gray-500 mb-2">Ingresos / Egresos por subcategoría</div>
        <canvas id="chartSub"></canvas>
      </div>
    </div>

    
    <div class="sticky top-16 z-10">
      <div class="p-4 bg-white/95 dark:bg-gray-800/95 backdrop-blur shadow rounded-xl">
        <form method="GET" action="<?php echo e(route('contabilidad.index')); ?>">
          <div class="grid grid-cols-2 md:grid-cols-4 xl:grid-cols-8 gap-3 items-end">
            
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Mes</label>
              <select name="mes" class="w-full border rounded px-2 py-1">
                <option value="">—</option>
                <?php $__currentLoopData = $meses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($n); ?>" <?php if(($mes ?? '') == $n): echo 'selected'; endif; ?>><?php echo e($nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Año</label>
              <select name="año" class="w-full border rounded px-2 py-1">
                <option value="">—</option>
                <?php $__currentLoopData = $años; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($y); ?>" <?php if(($año ?? '') == $y): echo 'selected'; endif; ?>><?php echo e($y); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Desde</label>
              <input type="date" name="desde" value="<?php echo e($desde ?? ''); ?>" class="w-full border rounded px-2 py-1">
            </div>
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Hasta</label>
              <input type="date" name="hasta" value="<?php echo e($hasta ?? ''); ?>" class="w-full border rounded px-2 py-1">
            </div>

            
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Tipo</label>
              <select name="tipo" class="w-full border rounded px-2 py-1">
                <option value="">Ambos</option>
                <option value="ingreso" <?php if(($tipo ?? '')==='ingreso'): echo 'selected'; endif; ?>>Ingresos</option>
                <option value="egreso"  <?php if(($tipo ?? '')==='egreso'): echo 'selected'; endif; ?>>Egresos</option>
              </select>
            </div>
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Fuente</label>
              <select name="fuente" class="w-full border rounded px-2 py-1">
                <option value="">Todas</option>
                <?php $__currentLoopData = $fuentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($f); ?>" <?php if(($fuente ?? '')===$f): echo 'selected'; endif; ?>><?php echo e($f); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Cliente</label>
              <select name="cliente_id" class="w-full border rounded px-2 py-1">
                <option value="">—</option>
                <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($id); ?>" <?php if(($cliente_id ?? '')==$id): echo 'selected'; endif; ?>><?php echo e($n); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Sucursal</label>
              <select name="sucursal_id" class="w-full border rounded px-2 py-1">
                <option value="">—</option>
                <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($id); ?>" <?php if(($sucursal_id ?? '')==$id): echo 'selected'; endif; ?>><?php echo e($n); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Caja</label>
              <select name="caja_id" class="w-full border rounded px-2 py-1">
                <option value="">—</option>
                <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($id); ?>" <?php if(($caja_id ?? '')==$id): echo 'selected'; endif; ?>><?php echo e($n); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">Usuario</label>
              <select name="usuario_id" class="w-full border rounded px-2 py-1">
                <option value="">—</option>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($id); ?>" <?php if(($usuario_id ?? '')==$id): echo 'selected'; endif; ?>><?php echo e($n); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </div>

            
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">ID Categoría</label>
              <input type="number" name="categoria_id" value="<?php echo e($categoria_id ?? ''); ?>" class="w-full border rounded px-2 py-1">
            </div>
            <div>
              <label class="block text-xs text-gray-600 dark:text-gray-300">ID Subcategoría</label>
              <input type="number" name="subcategoria_id" value="<?php echo e($subcategoria_id ?? ''); ?>" class="w-full border rounded px-2 py-1">
            </div>

            <div class="md:col-span-2 xl:col-span-1">
              <button class="w-full px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Aplicar
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>

    
    <?php if(isset($movs)): ?>
      <div class="bg-white dark:bg-gray-800 shadow rounded-xl">
        <div class="max-h-[60vh] overflow-y-auto rounded-b-xl">
          <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
            <thead class="bg-gray-50 dark:bg-gray-700 sticky top-0 z-10">
              <tr>
                <th class="px-4 py-2 text-left text-xs font-medium">Fecha</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Fuente</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Cliente</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Sucursal</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Caja</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Usuario</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Categoría</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Subcategoría</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Descripción</th>
                <th class="px-4 py-2 text-right text-xs font-medium">Monto</th>
                <th class="px-4 py-2 text-left text-xs font-medium">Tipo</th>
              </tr>
            </thead>
            <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              <?php $__currentLoopData = $movs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $catNombre = $m->tipo === 'ingreso' ? optional($m->categoriaIngreso)->nombre : optional($m->categoriaGasto)->nombre;
                  $subNombre = $m->tipo === 'ingreso' ? optional($m->subcategoriaIngreso)->nombre : optional($m->subcategoriaGasto)->nombre;
                ?>
                <tr class="<?php echo e($m->tipo=='egreso' ? 'bg-red-50 dark:bg-red-900/30' : 'bg-green-50 dark:bg-green-900/30'); ?>">
                  <td class="px-4 py-2 whitespace-nowrap"><?php echo e($m->fecha?->format('d-m-Y')); ?></td>
                  <td class="px-4 py-2 whitespace-nowrap"><?php echo e($m->fuente); ?></td>
                  <td class="px-4 py-2 whitespace-nowrap"><?php echo e($m->cliente->nombre ?? '—'); ?></td>
                  <td class="px-4 py-2 whitespace-nowrap"><?php echo e($m->sucursal->nombre ?? '—'); ?></td>
                  <td class="px-4 py-2 whitespace-nowrap"><?php echo e($m->caja->nombre ?? '—'); ?></td>
                  <td class="px-4 py-2 whitespace-nowrap"><?php echo e($m->user->name ?? '—'); ?></td>
                  <td class="px-4 py-2 whitespace-nowrap"><?php echo e($catNombre ?? '—'); ?></td>
                  <td class="px-4 py-2 whitespace-nowrap"><?php echo e($subNombre ?? '—'); ?></td>
                  <td class="px-4 py-2"><?php echo e($m->descripcion); ?></td>
                  <td class="px-4 py-2 text-right whitespace-nowrap"><?php echo e(number_format($m->monto,2)); ?></td>
                  <td class="px-4 py-2 capitalize whitespace-nowrap"><?php echo e($m->tipo); ?></td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot class="bg-gray-50 dark:bg-gray-700">
              <tr class="font-semibold">
                <td colspan="9" class="px-4 py-2 text-right">Balance neto:</td>
                <td class="px-4 py-2 text-right"><?php echo e(number_format(($kpi['balance'] ?? 0), 2)); ?></td>
                <td></td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    <?php endif; ?>

  </div>

  
  <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
  // ===== Datos desde PHP =====
  const labelsDias      = <?php echo json_encode($labelsDias ?? [], 15, 512) ?>;
  const ingresosDia     = <?php echo json_encode($ingresosDia ?? [], 15, 512) ?>;
  const egresosDia      = <?php echo json_encode($egresosDia ?? [], 15, 512) ?>;

  const labelsFuente    = <?php echo json_encode($labelsFuente ?? [], 15, 512) ?>;
  const datosFuenteIng  = <?php echo json_encode($datosFuenteIng ?? [], 15, 512) ?>;
  const datosFuenteEgr  = <?php echo json_encode($datosFuenteEgr ?? [], 15, 512) ?>;

  const labelsCaja      = <?php echo json_encode($labelsCaja ?? [], 15, 512) ?>;
  const datosCajaIng    = <?php echo json_encode($datosCajaIng ?? [], 15, 512) ?>;
  const datosCajaEgr    = <?php echo json_encode($datosCajaEgr ?? [], 15, 512) ?>;

  const labelsCat       = <?php echo json_encode($labelsCat ?? [], 15, 512) ?>;
  const datosCatIng     = <?php echo json_encode($datosCatIng ?? [], 15, 512) ?>;
  const datosCatEgr     = <?php echo json_encode($datosCatEgr ?? [], 15, 512) ?>;

  const labelsSub       = <?php echo json_encode($labelsSub ?? [], 15, 512) ?>;
  const datosSubIng     = <?php echo json_encode($datosSubIng ?? [], 15, 512) ?>;
  const datosSubEgr     = <?php echo json_encode($datosSubEgr ?? [], 15, 512) ?>;

  // ===== Barra Ingresos vs Egresos por día =====
  const ctxIE = document.getElementById('chartIE');
  if (ctxIE) {
    new Chart(ctxIE, {
      type: 'bar',
      data: {
        labels: labelsDias,
        datasets: [
          { label: 'Ingresos', data: ingresosDia, backgroundColor: 'rgba(34,197,94,0.7)' },
          { label: 'Egresos',  data: egresosDia,  backgroundColor: 'rgba(239,68,68,0.7)' },
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        scales: { y: { beginAtZero: true } },
        plugins: { legend: { position: 'bottom' } }
      }
    });
    ctxIE.parentElement.style.height = '320px';
  }

  // ===== Paleta de colores distinta por etiqueta =====
  function makePalette(n, alpha = 0.85, light = 55, offset = 0) {
    const colors = [];
    for (let i = 0; i < n; i++) {
      const hue = (i * 360 / Math.max(1, n) + offset) % 360;
      colors.push(`hsl(${hue} 70% ${light}% / ${alpha})`);
    }
    return colors;
  }

  // ===== Helper: dona de 2 anillos (Ingresos / Egresos) con paletas distintas =====
  function renderDualDonut(id, labels, dataIng, dataEgr) {
    const el = document.getElementById(id);
    if (!el) return;

    // Colores: cada etiqueta un color; mismo tono para egresos pero más oscuro/otra opacidad
    const colorsIng = makePalette(labels.length, 0.85, 58,   0);  // más brillante
    const colorsEgr = makePalette(labels.length, 0.65, 42,  12);  // mismo círculo cromático pero desplazado/oscuro

    new Chart(el, {
      type: 'doughnut',
      data: {
        labels,
        datasets: [
          // Primer dataset (leyenda tomará estos colores)
          { label: 'Ingresos', data: dataIng, backgroundColor: colorsIng, borderWidth: 1, borderColor: '#fff' },
          // Segundo anillo
          { label: 'Egresos',  data: dataEgr, backgroundColor: colorsEgr, borderWidth: 1, borderColor: '#fff' }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '55%',      // agujero central
        radius: '95%',      // tamaño total
        plugins: { legend: { position: 'bottom' } },
        animation: { animateRotate: true, animateScale: true }
      }
    });

    el.parentElement.style.height = '300px';
  }

  // ===== Donas dobles =====
  renderDualDonut('chartFuente', labelsFuente, datosFuenteIng, datosFuenteEgr);
  renderDualDonut('chartCaja',   labelsCaja,   datosCajaIng,   datosCajaEgr);
  renderDualDonut('chartCat',    labelsCat,    datosCatIng,    datosCatEgr);
  renderDualDonut('chartSub',    labelsSub,    datosSubIng,    datosSubEgr);
</script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/contabilidad/index.blade.php ENDPATH**/ ?>