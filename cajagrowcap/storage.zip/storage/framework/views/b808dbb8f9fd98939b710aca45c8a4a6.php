<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <div class="flex items-center gap-3">
      <a href="<?php echo e(route('user_prestamos.create')); ?>"
         class="inline-flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md shadow">
        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4v16m8-8H4"/>
        </svg>
        <?php echo e(__('Nuevo préstamo')); ?>

      </a>

      <h2 class="font-semibold text-xl text-white leading-tight">
        <?php echo e(__('Préstamos (todos)')); ?>

      </h2>
    </div>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="{
         search: '<?php echo e($search ?? ''); ?>',
         status: '<?php echo e($status ?? ''); ?>',
         desde:  '<?php echo e($desde  ?? ''); ?>',
         hasta:  '<?php echo e($hasta  ?? ''); ?>',
         orden:  '<?php echo e($orden  ?? 'fecha_desc'); ?>'
       }">

    <?php if(session('success')): ?>
      <div class="mb-4 rounded bg-green-100 p-3 text-green-800 dark:bg-green-900 dark:text-green-200">
        <?php echo e(session('success')); ?>

      </div>
    <?php endif; ?>

    

    
    <div class="mb-4 grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3">
      <input type="text" x-model="search" placeholder="<?php echo e(__('Buscar cliente / # / monto…')); ?>"
             class="px-3 py-2 border rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-green-500
                    bg-white text-gray-700 dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="status"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($key); ?>" <?php if((string)($status ?? '') === (string)($key ?? '')): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <input type="date" x-model="desde"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />
      <input type="date" x-model="hasta"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600" />

      <select x-model="orden"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="fecha_desc"><?php echo e(__('Más recientes')); ?></option>
        <option value="fecha_asc"><?php echo e(__('Más antiguos')); ?></option>
        <option value="monto_desc"><?php echo e(__('Monto ↓')); ?></option>
        <option value="monto_asc"><?php echo e(__('Monto ↑')); ?></option>
      </select>

      <button
        @click="window.location = '<?php echo e(route('user_prestamos.index')); ?>'
          + `?search=${encodeURIComponent(search)}&status=${encodeURIComponent(status ?? '')}
              &desde=${encodeURIComponent(desde ?? '')}&hasta=${encodeURIComponent(hasta ?? '')}
              &orden=${encodeURIComponent(orden)}`"
        class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md shadow">
        <?php echo e(__('Filtrar')); ?>

      </button>
    </div>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 whitespace-nowrap">
        <thead class="bg-green-700 dark:bg-green-900">
          <tr>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">#</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Cliente</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Tipo</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Monto</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">% Interés</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Int. generado</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Inicio</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Status</th>
            <th class="px-6 py-3 text-left text-xs font-medium text-white uppercase">Caja</th>
            <th class="px-6 py-3 text-right text-xs font-medium text-white uppercase">Acciones</th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          <?php $__empty_1 = true; $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="hover:bg-gray-50 dark:hover:bg-gray-700">
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200"><?php echo e(str_pad($p->id, 3, '0', STR_PAD_LEFT)); ?></td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e(optional($p->cliente)->nombre); ?> <?php echo e(optional($p->cliente)->apellido); ?>

                <div class="text-xs text-gray-500 dark:text-gray-400"><?php echo e(optional($p->cliente)->email); ?></div>
              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200"><?php echo e($p->tipo_prestamo); ?></td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">$<?php echo e(number_format($p->cantidad,2)); ?></td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200"><?php echo e(number_format($p->interes,2)); ?>%</td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">$<?php echo e(number_format($p->interes_generado,2)); ?></td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200"><?php echo e(\Carbon\Carbon::parse($p->fecha_inicio)->format('Y-m-d')); ?></td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200">
                <?php echo e([1=>'Autorizado',2=>'Pendiente',3=>'En revisión',4=>'Rechazado',5=>'Pagado',6=>'Terminado'][$p->status] ?? '—'); ?>

              </td>
              <td class="px-6 py-4 text-gray-700 dark:text-gray-200"><?php echo e(optional($p->caja)->nombre ?? '—'); ?></td>
              <td class="px-6 py-4 text-right">
                <a href="<?php echo e(route('user_prestamos.show', $p)); ?>"
                   class="inline-flex items-center px-3 py-2 bg-green-600 hover:bg-green-700 text-white text-sm font-medium rounded-md">
                  <?php echo e(__('Ver')); ?>

                </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="10" class="px-6 py-6 text-center text-gray-500 dark:text-gray-400">
                <?php echo e(__('No hay préstamos registrados.')); ?>

              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>

      <div class="px-4 py-3 text-right bg-gray-50 dark:bg-gray-700 sm:px-6">
        <?php echo e($prestamos->links()); ?>

      </div>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserprestamos/index.blade.php ENDPATH**/ ?>