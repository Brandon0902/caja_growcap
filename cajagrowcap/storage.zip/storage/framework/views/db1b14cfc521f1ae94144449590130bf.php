<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <div class="flex items-center justify-between">
      <h2 class="font-semibold text-xl text-white leading-tight">
        <?php echo e(__('Nuevo depósito de emergencia')); ?>

      </h2>
      <a href="<?php echo e(route('depositos.index')); ?>"
         class="inline-flex items-center px-3 py-2 bg-gray-500 hover:bg-gray-600 text-white text-sm font-medium rounded-md">
        <?php echo e(__('← Volver')); ?>

      </a>
    </div>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
    <?php if($errors->any()): ?>
      <div class="mb-4 rounded-lg border border-red-200 bg-red-50 p-4 text-red-700 dark:border-red-800 dark:bg-red-900/40 dark:text-red-200">
        <div class="font-semibold mb-1"><?php echo e(__('Hay errores en el formulario:')); ?></div>
        <ul class="list-disc ml-5 text-sm">
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg p-6">
      <form method="POST" action="<?php echo e(route('depositos.store')); ?>" enctype="multipart/form-data" class="space-y-5">
        <?php echo csrf_field(); ?>

        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Cliente')); ?></label>
          <select name="id_cliente"
                  class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600
                         bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm
                         focus:border-green-500 focus:ring-green-500" required>
            <option value=""><?php echo e(__('Selecciona un cliente…')); ?></option>
            <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($c->id); ?>" <?php if(old('id_cliente')==$c->id): echo 'selected'; endif; ?>>
                <?php echo e($c->nombre); ?> <?php echo e($c->apellido); ?> — <?php echo e($c->email); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Monto')); ?></label>
          <input type="number" name="cantidad" step="0.01" min="0.01" value="<?php echo e(old('cantidad')); ?>"
                 class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600
                        bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm
                        focus:border-green-500 focus:ring-green-500" required>
        </div>

        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Fecha de depósito')); ?></label>
          <input type="date" name="fecha_deposito"
                 value="<?php echo e(old('fecha_deposito', now()->toDateString())); ?>"
                 class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600
                        bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm
                        focus:border-green-500 focus:ring-green-500" required>
        </div>

        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Caja a impactar')); ?></label>
          <select name="id_caja"
                  class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600
                         bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm
                         focus:border-green-500 focus:ring-green-500" required>
            <option value=""><?php echo e(__('Selecciona una caja…')); ?></option>
            <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($cx->id_caja); ?>" <?php if(old('id_caja')==$cx->id_caja): echo 'selected'; endif; ?>><?php echo e($cx->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <?php if(\Illuminate\Support\Facades\Schema::hasColumn('cajas','estado')): ?>
            <p class="text-xs text-gray-500 dark:text-gray-400 mt-1"><?php echo e(__('Solo se listan cajas abiertas.')); ?></p>
          <?php endif; ?>
        </div>

        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Nota (opcional)')); ?></label>
          <input type="text" name="nota" value="<?php echo e(old('nota')); ?>"
                 placeholder="<?php echo e(__('Depósito realizado por admin (emergencia)')); ?>"
                 class="mt-1 block w-full rounded-md border-gray-300 dark:border-gray-600
                        bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm
                        focus:border-green-500 focus:ring-green-500">
        </div>

        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-200"><?php echo e(__('Comprobante (opcional)')); ?></label>
          <input type="file" name="deposito" accept=".jpg,.jpeg,.png,.pdf"
                 class="mt-1 block w-full text-sm text-gray-900 dark:text-gray-100
                        file:mr-4 file:py-2 file:px-4
                        file:rounded-md file:border-0
                        file:text-sm file:font-semibold
                        file:bg-green-50 file:text-green-700
                        hover:file:bg-green-100">
          <p class="text-xs text-gray-500 dark:text-gray-400 mt-1">
            <?php echo e(__('JPG, PNG o PDF (máx. 4MB).')); ?>

          </p>
        </div>

        <div class="pt-2 flex justify-end gap-3">
          <a href="<?php echo e(route('depositos.index')); ?>"
             class="px-4 py-2 bg-gray-200 hover:bg-gray-300 text-gray-800 dark:bg-gray-700 dark:hover:bg-gray-600 dark:text-gray-100 rounded-md">
            <?php echo e(__('Cancelar')); ?>

          </a>
          <button type="submit"
                  class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md">
            <?php echo e(__('Guardar y aprobar')); ?>

          </button>
        </div>
      </form>
    </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/depositos/create.blade.php ENDPATH**/ ?>