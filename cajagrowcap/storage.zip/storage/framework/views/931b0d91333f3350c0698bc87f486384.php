<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Abonos (Todos)')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  
  <style>[x-cloak]{ display:none !important; }</style>

  <div class="py-6 mx-auto max-w-7xl px-4 sm:px-6 lg:px-8"
       x-data="page()"
       x-init="onLoad(<?php echo e(json_encode(session('openEditId'))); ?>)">

    
    <div class="mb-4 grid grid-cols-1 md:grid-cols-6 gap-3">
      <input type="text" x-model="search"
             placeholder="<?php echo e(__('Buscar por cliente/email/ID/importe…')); ?>"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"/>

      <select x-model="status"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($v); ?>" <?php if((string)$status === (string)$v): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <input type="date" x-model="desde"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"/>
      <input type="date" x-model="hasta"
             class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600"/>

      <select x-model="orden"
              class="px-3 py-2 border rounded-md bg-white dark:bg-gray-700 dark:text-gray-200 dark:border-gray-600">
        <option value="recientes"><?php echo e(__('Más recientes')); ?></option>
        <option value="antiguos"><?php echo e(__('Más antiguos')); ?></option>
        <option value="monto_desc"><?php echo e(__('Monto ↓')); ?></option>
        <option value="monto_asc"><?php echo e(__('Monto ↑')); ?></option>
      </select>

      <button
        @click="aplicarFiltros()"
        class="px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-md">
        <?php echo e(__('Filtrar')); ?>

      </button>
    </div>

    
    <div class="bg-white dark:bg-gray-800 shadow-sm sm:rounded-lg overflow-x-auto">
      <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700 table-auto whitespace-nowrap">
        <thead class="bg-green-700 dark:bg-green-900">
          <tr>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase">#</th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('Cliente')); ?></th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('Préstamo')); ?></th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('# Pago')); ?></th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('Cantidad')); ?></th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('Fecha')); ?></th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('Vence')); ?></th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('Mora')); ?></th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('Saldo')); ?></th>
            <th class="px-4 py-3 text-left text-xs font-medium text-white uppercase"><?php echo e(__('Status')); ?></th>
            <th class="px-4 py-3 text-right text-xs font-medium text-white uppercase"><?php echo e(__('Acciones')); ?></th>
          </tr>
        </thead>
        <tbody class="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
          <?php $__empty_1 = true; $__currentLoopData = $abonos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $a): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
              // Relación correcta: userPrestamo -> cliente
              $cliente = optional(optional($a->userPrestamo)->cliente);
            ?>
            <tr>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200"><?php echo e($a->id); ?></td>

              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">
                <?php echo e($cliente?->nombre); ?> <?php echo e($cliente?->apellido); ?>

                <div class="text-xs text-gray-500 dark:text-gray-400"><?php echo e($cliente?->email); ?></div>
              </td>

              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">#<?php echo e($a->user_prestamo_id); ?></td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200"><?php echo e($a->num_pago); ?></td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">$<?php echo e(number_format((float)$a->cantidad, 2)); ?></td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200"><?php echo e(optional($a->fecha)->format('Y-m-d')); ?></td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200"><?php echo e(optional($a->fecha_vencimiento)->format('Y-m-d')); ?></td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">$<?php echo e(number_format((float)$a->mora_generada, 2)); ?></td>
              <td class="px-4 py-3 text-gray-700 dark:text-gray-200">$<?php echo e(number_format((float)$a->saldo_restante, 2)); ?></td>

              <td class="px-4 py-3">
                <form action="<?php echo e(route('adminuserabonos.abonos.updateStatus', $a->id)); ?>" method="POST">
                  <?php echo csrf_field(); ?>
                  <select name="status" onchange="this.form.submit()"
                          class="border-gray-300 rounded dark:bg-gray-700 dark:text-gray-200">
                    <option value="0" <?php if($a->status==0): echo 'selected'; endif; ?>>Pendiente</option>
                    <option value="1" <?php if($a->status==1): echo 'selected'; endif; ?>>Pagado</option>
                    <option value="2" <?php if($a->status==2): echo 'selected'; endif; ?>>Vencido</option>
                  </select>
                </form>
              </td>

              <td class="px-4 py-3 text-right">
                
                <a href="<?php echo e(route('adminuserabonos.abonos.edit', $a->id)); ?>"
                   @click.prevent="openEdit(<?php echo e($a->id); ?>)"
                   class="inline-flex items-center px-3 py-2 bg-indigo-500 hover:bg-indigo-600 text-white text-sm rounded-md">
                  <?php echo e(__('Editar')); ?>

                </a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="11" class="px-4 py-6 text-center text-gray-500 dark:text-gray-400">
                <?php echo e(__('No se encontraron abonos.')); ?>

              </td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>

      <div class="px-4 py-3 bg-gray-50 dark:bg-gray-700 text-right">
        <?php echo e($abonos->links()); ?>

      </div>
    </div>

    
    <div x-cloak x-show="showEdit" x-transition.opacity
         class="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
         @keydown.escape.window="closeModal()">
      <div class="w-full max-w-3xl bg-white dark:bg-gray-800 rounded-2xl shadow-2xl overflow-hidden relative flex flex-col">
        <button @click="closeModal()"
                class="absolute top-3 right-3 inline-flex items-center justify-center w-9 h-9 rounded-full bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600"
                aria-label="Cerrar">✕</button>

        <div class="p-6 max-h-[80vh] overflow-y-auto" x-html="editHtml"></div>
      </div>
    </div>

  </div>

  
  <script>
    function page() {
      return {
        // Estado de filtros desde servidor
        search: <?php echo json_encode($search ?? '', 15, 512) ?>,
        status: <?php echo json_encode((string)($status ?? ''), 15, 512) ?>,
        desde:  <?php echo json_encode($desde ?? '', 15, 512) ?>,
        hasta:  <?php echo json_encode($hasta ?? '', 15, 512) ?>,
        orden:  <?php echo json_encode($orden ?? 'recientes', 15, 512) ?>,

        // Estado modal
        showEdit: false,
        editHtml: '',

        aplicarFiltros() {
          const base = <?php echo json_encode(route('adminuserabonos.abonos.general'), 15, 512) ?>;
          const qs = new URLSearchParams({
            search: this.search ?? '',
            status: this.status ?? '',
            desde:  this.desde  ?? '',
            hasta:  this.hasta  ?? '',
            orden:  this.orden  ?? 'recientes',
          }).toString();
          window.location = `${base}?${qs}`;
        },

        async openEdit(id) {
          try {
            const url = <?php echo json_encode(route('adminuserabonos.abonos.edit', '__ID__'), 512) ?>.replace('__ID__', id);
            const res = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' }});
            if (!res.ok) throw new Error('HTTP ' + res.status);
            this.editHtml = await res.text();
            this.showEdit = true;
          } catch (err) {
            console.error(err);
            alert('No se pudo cargar el formulario de edición.');
          }
        },

        closeModal() {
          this.showEdit = false;
          this.editHtml = '';
        },

        onLoad(openId) {
          // Si venimos de /edit por navegación directa, abre aquí automáticamente
          if (openId) {
            this.openEdit(openId);
          }
        }
      }
    }
  </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/adminuserabonos/abonos/general_index.blade.php ENDPATH**/ ?>