<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
   <?php $__env->slot('header', null, []); ?> 
    <h2 class="font-semibold text-xl text-white leading-tight">
      <?php echo e(__('Crear Usuario')); ?>

    </h2>
   <?php $__env->endSlot(); ?>

  <div class="py-6 mx-auto max-w-4xl px-4 sm:px-6 lg:px-8"
       x-data='{
         roles: <?php echo json_encode($roles, 15, 512) ?>,
         newRole: "",
         showModal: false,
         selAllSuc: false,
         selAllCaj: false,
         toggleAllSuc() {
           const checks = document.querySelectorAll("input[name=\"sucursales[]\"]");
           checks.forEach(ch => ch.checked = this.selAllSuc);
         },
         toggleAllCaj() {
           const checks = document.querySelectorAll("input[name=\"cajas[]\"]");
           checks.forEach(ch => ch.checked = this.selAllCaj);
         },
         addRole() {
           if (! this.newRole.trim()) return;
           this.roles.push(this.newRole.trim());
           this.$refs.roleSelect.value = this.newRole.trim();
           this.newRole = "";
           this.showModal = false;
         }
       }'>

    <div class="bg-white dark:bg-gray-800 shadow sm:rounded-lg p-6">
      <?php if($errors->any()): ?>
        <div class="mb-4 text-red-600">
          <ul class="list-disc pl-5">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($e); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
        </div>
      <?php endif; ?>

      <form action="<?php echo e(route('usuarios.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        
        <div class="mb-4">
          <label class="block text-gray-700 dark:text-gray-200">Nombre</label>
          <input type="text" name="name" value="<?php echo e(old('name')); ?>"
                 class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-gray-200
                        focus:outline-none focus:ring-2 focus:ring-purple-500"/>
        </div>

        
        <div class="mb-4">
          <label class="block text-gray-700 dark:text-gray-200">Email</label>
          <input type="email" name="email" value="<?php echo e(old('email')); ?>"
                 class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-gray-200
                        focus:outline-none focus:ring-2 focus:ring-purple-500"/>
        </div>

        
        <div class="mb-4 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-gray-700 dark:text-gray-200">Contraseña</label>
            <input type="password" name="password"
                   class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-gray-200
                          focus:outline-none focus:ring-2 focus:ring-purple-500"/>
          </div>
          <div>
            <label class="block text-gray-700 dark:text-gray-200">Confirmar</label>
            <input type="password" name="password_confirmation"
                   class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-gray-200
                          focus:outline-none focus:ring-2 focus:ring-purple-500"/>
          </div>
        </div>

        
        <div class="mb-6">
          <label class="block text-gray-700 dark:text-gray-200">Rol</label>
          <div class="flex gap-2">
            <select x-ref="roleSelect" name="rol"
                    class="flex-1 mt-1 border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-gray-200
                           focus:outline-none focus:ring-2 focus:ring-purple-500">
              <option value="" disabled selected>-- Selecciona un rol --</option>
              <template x-for="r in roles" :key="r">
                <option :value="r" x-text="r"></option>
              </template>
            </select>
            <button type="button"
                    @click="showModal = true"
                    class="px-3 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded">
              + Rol
            </button>
          </div>
          <?php $__errorArgs = ['rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-1 text-red-600 text-sm"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label class="block text-gray-700 dark:text-gray-200">Activo</label>
            <select name="activo"
                    class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-gray-200
                           focus:outline-none focus:ring-2 focus:ring-purple-500">
              <option value="1" <?php echo e(old('activo','1')=='1'?'selected':''); ?>>Sí</option>
              <option value="0" <?php echo e(old('activo')=='0'?'selected':''); ?>>No</option>
            </select>
          </div>
          <div>
            <label class="block text-gray-700 dark:text-gray-200">Fecha de creación</label>
            <input type="datetime-local" name="fecha_creacion"
                   value="<?php echo e(old('fecha_creacion', now()->format('Y-m-d\TH:i'))); ?>"
                   class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-gray-200
                          focus:outline-none focus:ring-2 focus:ring-purple-500"/>
          </div>
        </div>

        
        <div class="mb-6">
          <label class="block text-gray-700 dark:text-gray-200">Sucursal principal (opcional)</label>
          <select name="sucursal_principal"
                  class="mt-1 w-full border rounded px-3 py-2 bg-white dark:bg-gray-700 dark:text-gray-200
                         focus:outline-none focus:ring-2 focus:ring-purple-500">
            <option value="">-- Ninguna --</option>
            <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($s->id_sucursal); ?>"><?php echo e($s->nombre); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        
        <div class="mb-6">
          <div class="flex items-center justify-between mb-2">
            <h3 class="font-semibold text-gray-800 dark:text-gray-100">Sucursales</h3>
            <label class="text-sm flex items-center gap-2">
              <input type="checkbox" x-model="selAllSuc" @change="toggleAllSuc()"
                     class="rounded border-gray-300">
              <span class="text-gray-700 dark:text-gray-300">Seleccionar todas</span>
            </label>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            <?php $__currentLoopData = $sucursales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <label class="flex items-center gap-2 px-3 py-2 rounded border
                            bg-white dark:bg-gray-700 dark:text-gray-200">
                <input type="checkbox" name="sucursales[]"
                       value="<?php echo e($s->id_sucursal); ?>"
                       class="rounded border-gray-300">
                <span><?php echo e($s->nombre); ?></span>
              </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <?php $__errorArgs = ['sucursales.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-1 text-red-600 text-sm"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="mb-8">
          <div class="flex items-center justify-between mb-2">
            <h3 class="font-semibold text-gray-800 dark:text-gray-100">Cajas</h3>
            <label class="text-sm flex items-center gap-2">
              <input type="checkbox" x-model="selAllCaj" @change="toggleAllCaj()"
                     class="rounded border-gray-300">
              <span class="text-gray-700 dark:text-gray-300">Seleccionar todas</span>
            </label>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2">
            <?php $__currentLoopData = $cajas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <label class="flex items-center gap-2 px-3 py-2 rounded border
                            bg-white dark:bg-gray-700 dark:text-gray-200">
                <input type="checkbox" name="cajas[]"
                       value="<?php echo e($c->id_caja); ?>"
                       class="rounded border-gray-300">
                <span><?php echo e($c->nombre); ?></span>
              </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
          <?php $__errorArgs = ['cajas.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-1 text-red-600 text-sm"><?php echo e($message); ?></p>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        
        <div class="flex justify-end gap-2">
          <a href="<?php echo e(route('usuarios.index')); ?>"
             class="px-4 py-2 bg-gray-300 hover:bg-gray-400 rounded">Cancelar</a>
          <button type="submit"
                  class="px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded">
            Guardar
          </button>
        </div>
      </form>
    </div>

    
    <div x-show="showModal" x-cloak
         class="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50">
      <div @click.away="showModal = false"
           class="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 w-full max-w-sm">
        <h3 class="text-lg font-semibold text-gray-800 dark:text-gray-200 mb-4">
          <?php echo e(__('Nuevo Rol')); ?>

        </h3>
        <input type="text"
               x-model="newRole"
               placeholder="Nombre del rol"
               class="w-full px-3 py-2 mb-4 border rounded bg-white dark:bg-gray-700 dark:text-gray-200
                      focus:outline-none focus:ring-2 focus:ring-purple-500"/>
        <div class="flex justify-end gap-2">
          <button @click="showModal = false"
                  class="px-4 py-2 bg-gray-200 rounded">Cancelar</button>
          <button @click="addRole()"
                  class="px-4 py-2 bg-blue-500 hover:bg-blue-600 text-white rounded">
            Agregar
          </button>
        </div>
      </div>
    </div>
    
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\caja-growcap\resources\views/usuarios/create.blade.php ENDPATH**/ ?>